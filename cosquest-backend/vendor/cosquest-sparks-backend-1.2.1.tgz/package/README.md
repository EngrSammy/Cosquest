# @cosquest/sparks-backend

The server side of CosQuest Sparks, as one package you mount in your Node backend. It holds every Sparks rule: the trigger gate, job leasing to phones, HPKE encryption of job inputs, Spark state (create, attach, dormancy, revival with seams, merge, pin, delete), calls (consented segments, scribe, leader commands, engagement) and post-call outlines.

It never touches your database or your socket. You give it a small set of functions ("ports") and call it from four places in your code. All AI runs on the phones; this package decides what to ask them, checks what they answer and stores the result through your ports.

- ESM, Node 20 or newer. Ships compiled JavaScript and `.d.ts` types; no TypeScript tooling needed to use it.
- Runtime dependencies: `@hpke/core`, `@hpke/dhkem-x25519`, `ajv`. The wire types and the JSON schemas are bundled, so this is the only Sparks package your backend installs.

## Install

```sh
npm install @cosquest/sparks-backend
# or from a tarball we hand you:
npm install ./cosquest-sparks-backend-1.2.0.tgz
```

## Mount it

```js
import { createSparksBackend } from '@cosquest/sparks-backend';

const sparks = createSparksBackend(ports, { /* optional config overrides */ });
sparks.start();                                  // sweepers: dormancy, summaries, lease expiry
process.on('SIGTERM', () => sparks.stop());
```

## The four hook points

```js
// 1. Your socket: every message a device sends on the "sparks" channel.
//    Bind the socket to its deviceId BEFORE handling device.register: the reply
//    (device.registered) goes out through ports.send(deviceId) during handle().
const r = await sparks.handle({ userId, deviceId: socketDeviceId }, msg);   // -> { deviceId, error? }

// 2. Your message insert path, after the per-chat seq is assigned (every chat, DMs included).
await sparks.onChatMessage({ ...row, hintState: 'none' });

// 3. Your call layer.
await sparks.onCallStarted(call);
await sparks.onCallMembership(callId, attendeeUserIds);
await sparks.onCallEnded(callId);

// 4. Your admin routes (the module checks isAdmin itself).
await sparks.admin.pin(userId, sparkId, pinned);
await sparks.admin.merge(userId, sourceSparkId, targetSparkId);
await sparks.admin.remove(userId, sparkId);
```

`sparks.sparksOfChat(chatId)` returns the live Sparks of a chat for a REST read; `sparks.tick()` runs one sweeper pass (useful in tests with a fake clock).

## Ports

```ts
import type { SparksPorts, SparksStore } from '@cosquest/sparks-backend';
```

| Port | What you provide |
|---|---|
| `store` | `SparksStore`: about 40 small persistence methods (devices, your messages table plus four Sparks columns, Sparks, sessions, seams, jobs with an atomic conditional `updateJob`, calls, segments, topics, outlines, consent log) |
| `send(deviceId, msg)` | One device over your socket, `sparks` channel |
| `broadcastToChat(chatId, msg)` | Devices of every chat member |
| `broadcastToCall(callId, msg, exceptUserId?)` | Devices of the call's current attendees |
| `sendToUsers(userIds, msg)` | Specific users' devices |
| `chatMembers(chatId)` | `ChatMember[]`: userId, displayName, rank, roles, isAdmin |
| `canRead(userId, chatId, seq)` | History visibility; every message sealed to a phone is filtered through it |
| `isAdmin(userId, chatId)` | Admin check for pin, merge, delete |
| `canIssueTargetedCall(userId, callId)` | Who may ring a subset of the call ("calling all sergeants") |
| `now()` | The clock (inject a fake one in tests) |
| `onTargetedCall?`, `onRolePing?`, `log?` | Optional hooks |

Every port and row type is documented in the shipped `dist/ports.d.ts`. A complete SQLite implementation of the store (about 200 lines) is `apps/backend-reference/src/host/store.ts` in the cosquest-sparks repo; port it table by table.

## What the package exports

| Export | Kind |
|---|---|
| `createSparksBackend(ports, overrides?)`, `SparksBackend` | The module |
| `defaultConfig`, `demoOverrides`, `SparksBackendConfig` | Every tunable number; production uses `defaultConfig`, `demoOverrides` shortens timers for demos and QA |
| `SparksPorts`, `SparksStore`, `DeviceRow`, `MessageRow`, `SparkRow`, `SparkRowState`, `SessionRow`, `SeamRow`, `JobRow`, `JobStatus`, `CallRow`, `SegmentRow`, `ConsentRow` | Port and row types |
| `SdkToBackend`, `BackendToSdk`, `ChatMessage`, `ChatMember`, `Spark`, `CallOutline`, `TopicShift`, `TranscriptSegment`, ... | Wire types (every SDK and backend message), generated from the SDK spec |
| `envelope(type, payload, now?)` | Builds a `BackendToSdk` envelope |
| `validateSdkToBackend`, `validateBackendToSdk` | Compiled JSON Schema validators (ajv) for the wire messages |
| `@cosquest/sparks-backend/schemas/<name>.json` | The JSON schemas themselves |

Inbound messages are validated against the bundled schemas in `dist/schemas`. Set `SPARKS_SCHEMA_DIR` to load them from somewhere else.

## Guides

In the cosquest-sparks repo:

- `docs/guides/BACKEND_INTEGRATION.md`: start here. Mounting, ports, the Postgres schema, model downloads, testing, build order.
- `docs/BACKEND_REFERENCE.md`: the rules and algorithms, configuration defaults.
- `docs/DATA_CONTRACT.md` and `schemas/`: every wire message.
- `docs/DEMO_HOST.md`: the demo host (Express + WebSocket + SQLite) and the integration traps it hit.

## Developing this package (cosquest-sparks repo)

```sh
pnpm --filter @cosquest/sparks-backend build       # tsc -> dist/, copies schemas/*.json -> dist/schemas
pnpm --filter @cosquest/sparks-backend typecheck   # also checks src/wire.ts is in step with the SDK spec
pnpm --filter @cosquest/sparks-backend test        # shared rule vectors (test/vectors/*.json)
pnpm --filter @cosquest/sparks-backend smoke       # plain-Node consumer check against dist/
pnpm --filter @cosquest/sparks-backend sync-wire-types   # regenerate src/wire.ts after an SDK spec change
pnpm --filter @cosquest/sparks-backend pack        # cosquest-sparks-backend-1.2.0.tgz
```

The end-to-end protocol tests (the module inside the demo host, five mock phones, real sockets and HPKE) live in `apps/backend-reference`.
