/* sparks_engine.c: priority scheduler over one model file and two mote handles.
 *
 * Rules (ARCHITECTURE.md 2.1, 2.2):
 *  - one generation at a time on one engine thread;
 *  - P0 Warden > P1 interactive > P2 background;
 *  - a higher-priority submit stops the running request at the next token or
 *    prefill chunk; the stopped request goes back to the FRONT of its queue
 *    and resumes by re-submitting prompt + partial output, which mote's prefix
 *    KV cache turns into about one forward pass (constrained requests restart,
 *    because a grammar cannot resume mid-document);
 *  - mote reads a prompt one token at a time and cannot be interrupted while it
 *    does, so long prompts are prefilled in chunks (a short generate per chunk,
 *    stopped after its first token): a Warden line waits at most one chunk.
 */
#define _POSIX_C_SOURCE 200809L
#include "sparks_core.h"
#include "mote_lib.h"
#include "quant.h"

#include <pthread.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <time.h>

/* ------------------------------------------------------------- utilities */
static double now_ms(void) {
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return ts.tv_sec * 1000.0 + ts.tv_nsec / 1e6;
}

static char *dup_or_null(const char *s) {
    if (!s) return NULL;
    size_t n = strlen(s) + 1;
    char *d = malloc(n);
    if (d) memcpy(d, s, n);
    return d;
}

typedef struct { char *p; size_t len, cap; } sbuf;
static int sb_append(sbuf *b, const char *s) {
    size_t n = strlen(s);
    if (b->len + n + 1 > b->cap) {
        size_t nc = b->cap ? b->cap * 2 : 256;
        while (nc < b->len + n + 1) nc *= 2;
        char *np = realloc(b->p, nc);
        if (!np) return -1;
        b->p = np; b->cap = nc;
    }
    memcpy(b->p + b->len, s, n);
    b->len += n;
    b->p[b->len] = '\0';
    return 0;
}

/* ---------------------------------------------------------------- request */
enum { STOP_NONE = 0, STOP_PREEMPT = 1, STOP_PAUSE = 2, STOP_CANCEL = 3 };

typedef struct node {
    struct node *next;
    int64_t id;
    int priority;
    char *prompt, *schema, *stop;
    spk_gen_params params;
    int embed;
    int (*on_piece)(const char *, void *);
    void (*on_done)(const spk_stats *, const char *, const float *, int, void *);
    void *user;
    /* progress */
    sbuf out;
    int generated;
    int preemptions;
    double submitted, run_started, first_token;
    double run_ms;
} node;

static void node_free(node *n) {
    if (!n) return;
    free(n->prompt); free(n->schema); free(n->stop); free(n->out.p);
    free(n);
}

struct spk_engine {
    pthread_mutex_t mu;
    pthread_cond_t  cv;      /* work available / state changed */
    pthread_t       thread;
    int             quit;
    spk_backend     be;
    int             has_be;
    void           *h[SPK_H_COUNT];
    int             unload_pending[SPK_H_COUNT];
    node           *head[SPK_P_COUNT], *tail[SPK_P_COUNT];
    int             count[SPK_P_COUNT];
    node           *running;
    volatile int    stop_reason;   /* for the running request */
    unsigned        paused;
    int             queue_limit;
    int             chunk;
    int64_t         next_id;
    void (*observer)(const spk_engine_state *, void *);
    void *observer_user;
};

/* ------------------------------------------------------------- callbacks */
static void finish(node *n, int status, const float *vec, int dim) {
    spk_stats st;
    memset(&st, 0, sizeof st);
    st.status = status;
    st.tokens_out = n->generated;
    st.tokens_in_est = n->prompt ? (int)(strlen(n->prompt) / 3.6 + 0.5) : 0;
    st.first_token_ms = n->first_token > 0 ? n->first_token - n->run_started : -1;
    st.wall_ms = now_ms() - n->submitted;
    st.run_ms = n->run_ms;
    st.preemptions = n->preemptions;
    if (n->on_done)
        n->on_done(&st, status == SPK_OK && !n->embed ? (n->out.p ? n->out.p : "") : NULL, vec, dim, n->user);
    node_free(n);
}

static void snapshot_locked(spk_engine *e, spk_engine_state *s) {
    s->running = e->running ? e->running->priority : -1;
    for (int p = 0; p < SPK_P_COUNT; p++) s->queued[p] = e->count[p];
    s->paused_mask = e->paused;
    for (int h = 0; h < SPK_H_COUNT; h++) s->loaded[h] = e->h[h] != NULL;
}

static void notify(spk_engine *e) {
    if (!e->observer) return;
    spk_engine_state s;
    pthread_mutex_lock(&e->mu);
    snapshot_locked(e, &s);
    pthread_mutex_unlock(&e->mu);
    e->observer(&s, e->observer_user);
}

/* ---------------------------------------------------------------- queues */
static void push_back(spk_engine *e, node *n) {
    int p = n->priority;
    n->next = NULL;
    if (e->tail[p]) e->tail[p]->next = n; else e->head[p] = n;
    e->tail[p] = n;
    e->count[p]++;
}
static void push_front(spk_engine *e, node *n) {
    int p = n->priority;
    n->next = e->head[p];
    e->head[p] = n;
    if (!e->tail[p]) e->tail[p] = n;
    e->count[p]++;
}
static node *pop_front(spk_engine *e, int p) {
    node *n = e->head[p];
    if (!n) return NULL;
    e->head[p] = n->next;
    if (!e->head[p]) e->tail[p] = NULL;
    e->count[p]--;
    n->next = NULL;
    return n;
}
/* Detach every queued request of priorities in mask; returns a list. */
static node *drain_locked(spk_engine *e, unsigned mask) {
    node *list = NULL;
    for (int p = 0; p < SPK_P_COUNT; p++) {
        if (!(mask & SPK_PAUSE_BIT(p))) continue;
        node *n;
        while ((n = pop_front(e, p))) { n->next = list; list = n; }
    }
    return list;
}
static void finish_list(node *list, int status) {
    while (list) { node *nx = list->next; finish(list, status, NULL, 0); list = nx; }
}

/* ------------------------------------------------------------ the worker */
typedef struct { spk_engine *e; node *n; } run_ctx;

static int on_token_run(const char *piece, void *user) {
    run_ctx *rc = user;
    node *n = rc->n;
    if (rc->e->stop_reason) return 0;
    if (n->first_token <= 0) n->first_token = now_ms();
    n->generated++;
    sb_append(&n->out, piece);
    if (n->on_piece && !n->on_piece(piece, n->user)) return 0;
    if (n->schema) return 1;   /* mote owns the budget and the close-out */
    if (n->stop && n->out.p && strstr(n->out.p, n->stop)) return 0;
    if (n->params.max_tokens > 0 && n->generated >= n->params.max_tokens) return 0;
    return 1;
}
static int on_token_prefill(const char *piece, void *user) { (void)piece; (void)user; return 0; }

/* Cut points for chunked prefill: about every `chunk` bytes, at a newline or
 * space so the BPE split at the boundary matches the full prompt's. */
static size_t next_cut(const char *s, size_t from, size_t len, int chunk) {
    size_t target = from + (size_t)chunk;
    if (target >= len) return len;
    for (size_t i = target; i > from + (size_t)chunk / 2; i--)
        if (s[i] == '\n' || s[i] == ' ') return i;
    return target;
}

static int ensure_handle(spk_engine *e, int which, char *err, size_t err_len) {
    if (e->h[which]) return SPK_OK;
    if (!e->has_be) { snprintf(err, err_len, "no model attached"); return SPK_E_NOT_READY; }
    if (e->be.memory_ok && !e->be.memory_ok(e->be.ctx, which)) {
        snprintf(err, err_len, "memory budget check refused loading handle %d", which);
        return SPK_E_MEMORY;
    }
    void *h = e->be.open(e->be.ctx, which, err, err_len);
    if (!h) return SPK_E_ENGINE;
    pthread_mutex_lock(&e->mu);
    if (e->h[which]) e->be.close(e->be.ctx, h);   /* lost a race with preload */
    else e->h[which] = h;
    pthread_mutex_unlock(&e->mu);
    return SPK_OK;
}

static void run_one(spk_engine *e, node *n) {
    int which = n->priority == SPK_P_WARDEN ? SPK_H_WARDEN : SPK_H_SPARKS;
    char err[256] = {0};
    double t0 = now_ms();
    if (n->run_started <= 0) n->run_started = t0;
    int rc = ensure_handle(e, which, err, sizeof err);
    if (rc != SPK_OK) { finish(n, rc, NULL, 0); return; }
    void *h = e->h[which];

    if (n->embed) {
        int cap = e->be.dim ? e->be.dim(e->be.ctx, h) : 0;
        if (cap <= 0) cap = 4096;
        float *vec = malloc(sizeof(float) * (size_t)cap);
        int d = vec ? e->be.embed(e->be.ctx, h, n->prompt, vec, cap) : 0;
        n->run_ms += now_ms() - t0;
        finish(n, d > 0 ? SPK_OK : SPK_E_ENGINE, vec, d);
        free(vec);
        return;
    }

    /* A constrained document cannot resume mid-way: restart it. */
    if (n->schema && n->out.len) { n->out.len = 0; n->out.p[0] = '\0'; n->generated = 0; }

    sbuf full = {0};
    sb_append(&full, n->prompt);
    if (n->out.len) sb_append(&full, n->out.p);

    run_ctx ctx = { e, n };
    /* chunked prefill */
    if (e->chunk > 0 && full.len > (size_t)e->chunk * 3 / 2) {
        spk_gen_params gp = { 0.0f, 0.0f, 0.0f, 1, 0 };
        size_t at = 0;
        for (;;) {
            size_t cut = next_cut(full.p, at, full.len, e->chunk);
            if (cut >= full.len) break;
            char saved = full.p[cut];
            full.p[cut] = '\0';
            e->be.generate(e->be.ctx, h, full.p, &gp, NULL, on_token_prefill, NULL);
            full.p[cut] = saved;
            at = cut;
            if (e->stop_reason) break;
        }
    }

    int ret = 0;
    if (!e->stop_reason) {
        spk_gen_params gp = n->params;
        if (gp.max_tokens > 0) {
            gp.max_tokens -= n->generated;
            if (gp.max_tokens <= 0) gp.max_tokens = 1;
        }
        /* on_token_run enforces max_tokens across resumes; give mote slack. */
        ret = e->be.generate(e->be.ctx, h, full.p, &gp, n->schema, on_token_run, &ctx);
    }
    free(full.p);
    n->run_ms += now_ms() - t0;

    int reason = e->stop_reason;
    if (reason == STOP_CANCEL) { finish(n, SPK_E_CANCELLED, NULL, 0); return; }
    if (reason == STOP_PAUSE)  { finish(n, SPK_E_PAUSED, NULL, 0); return; }
    if (reason == STOP_PREEMPT) {
        n->preemptions++;
        pthread_mutex_lock(&e->mu);
        push_front(e, n);
        pthread_mutex_unlock(&e->mu);
        return;
    }
    if (ret < 0) {
        finish(n, ret == MOTE_ERR_GRAMMAR_UNSTARTED || ret == SPK_E_GRAMMAR ? SPK_E_GRAMMAR : SPK_E_ENGINE, NULL, 0);
        return;
    }
    /* trim at the stop string */
    if (n->stop && n->out.p) {
        char *s = strstr(n->out.p, n->stop);
        if (s) { *s = '\0'; n->out.len = (size_t)(s - n->out.p); }
    }
    finish(n, SPK_OK, NULL, 0);
}

static void *worker(void *arg) {
    spk_engine *e = arg;
    pthread_mutex_lock(&e->mu);
    for (;;) {
        node *n = NULL;
        while (!e->quit) {
            for (int p = 0; p < SPK_P_COUNT && !n; p++)
                if (!(e->paused & SPK_PAUSE_BIT(p))) n = pop_front(e, p);
            if (n) break;
            /* idle: honour deferred unloads */
            for (int h = 0; h < SPK_H_COUNT; h++)
                if (e->unload_pending[h] && e->h[h]) {
                    e->be.close(e->be.ctx, e->h[h]);
                    e->h[h] = NULL;
                    e->unload_pending[h] = 0;
                }
            pthread_cond_broadcast(&e->cv);
            pthread_cond_wait(&e->cv, &e->mu);
        }
        if (e->quit) {
            if (n) push_front(e, n);
            break;
        }
        e->running = n;
        e->stop_reason = STOP_NONE;
        pthread_mutex_unlock(&e->mu);
        notify(e);
        run_one(e, n);
        pthread_mutex_lock(&e->mu);
        e->running = NULL;
        e->stop_reason = STOP_NONE;
        for (int h = 0; h < SPK_H_COUNT; h++)
            if (e->unload_pending[h] && e->h[h]) {
                e->be.close(e->be.ctx, e->h[h]);
                e->h[h] = NULL;
                e->unload_pending[h] = 0;
            }
        pthread_cond_broadcast(&e->cv);
        pthread_mutex_unlock(&e->mu);
        notify(e);
        pthread_mutex_lock(&e->mu);
    }
    pthread_mutex_unlock(&e->mu);
    return NULL;
}

/* ------------------------------------------------------------ public API */
spk_engine *spk_engine_create(spk_backend backend) {
    spk_engine *e = calloc(1, sizeof *e);
    if (!e) return NULL;
    pthread_mutex_init(&e->mu, NULL);
    pthread_cond_init(&e->cv, NULL);
    e->be = backend;
    e->has_be = backend.generate != NULL;
    e->queue_limit = 16;
    e->chunk = 640;
    e->next_id = 1;
    if (pthread_create(&e->thread, NULL, worker, e) != 0) {
        free(e);
        return NULL;
    }
    return e;
}

static void close_handles_locked(spk_engine *e) {
    for (int h = 0; h < SPK_H_COUNT; h++) {
        if (e->h[h] && e->has_be) e->be.close(e->be.ctx, e->h[h]);
        e->h[h] = NULL;
        e->unload_pending[h] = 0;
    }
}

void spk_engine_set_backend(spk_engine *e, spk_backend backend) {
    pthread_mutex_lock(&e->mu);
    node *list = drain_locked(e, 0x7);
    if (e->running) e->stop_reason = STOP_CANCEL;
    while (e->running) pthread_cond_wait(&e->cv, &e->mu);
    node *more = drain_locked(e, 0x7);           /* submitted while we waited */
    while (more) { node *nx = more->next; more->next = list; list = more; more = nx; }
    close_handles_locked(e);
    if (e->has_be && e->be.destroy) e->be.destroy(e->be.ctx);
    e->be = backend;
    e->has_be = backend.generate != NULL;
    pthread_mutex_unlock(&e->mu);
    finish_list(list, SPK_E_CANCELLED);
    notify(e);
}

int spk_engine_has_backend(spk_engine *e) {
    pthread_mutex_lock(&e->mu);
    int r = e->has_be;
    pthread_mutex_unlock(&e->mu);
    return r;
}

void spk_engine_free(spk_engine *e) {
    if (!e) return;
    pthread_mutex_lock(&e->mu);
    e->quit = 1;
    if (e->running) e->stop_reason = STOP_CANCEL;
    pthread_cond_broadcast(&e->cv);
    pthread_mutex_unlock(&e->mu);
    pthread_join(e->thread, NULL);
    pthread_mutex_lock(&e->mu);
    node *list = drain_locked(e, 0x7);
    close_handles_locked(e);
    if (e->has_be && e->be.destroy) e->be.destroy(e->be.ctx);
    pthread_mutex_unlock(&e->mu);
    finish_list(list, SPK_E_CANCELLED);
    pthread_mutex_destroy(&e->mu);
    pthread_cond_destroy(&e->cv);
    free(e);
}

int64_t spk_submit(spk_engine *e, const spk_request *r) {
    if (!r || r->priority < 0 || r->priority >= SPK_P_COUNT || !r->prompt) return SPK_E_INVALID;
    node *n = calloc(1, sizeof *n);
    if (!n) return SPK_E_ENGINE;
    n->priority = r->priority;
    n->prompt = dup_or_null(r->prompt);
    n->schema = dup_or_null(r->schema);
    n->stop = (r->stop && *r->stop) ? dup_or_null(r->stop) : NULL;
    n->params = r->params;
    n->embed = r->embed;
    n->on_piece = r->on_piece;
    n->on_done = r->on_done;
    n->user = r->user;
    n->submitted = now_ms();

    pthread_mutex_lock(&e->mu);
    if (!e->has_be) { pthread_mutex_unlock(&e->mu); node_free(n); return SPK_E_NOT_READY; }
    if (e->paused & SPK_PAUSE_BIT(r->priority)) { pthread_mutex_unlock(&e->mu); node_free(n); return SPK_E_PAUSED; }
    if (e->count[r->priority] >= e->queue_limit) { pthread_mutex_unlock(&e->mu); node_free(n); return SPK_E_BUSY; }
    n->id = e->next_id++;
    int64_t id = n->id;
    push_back(e, n);
    if (e->running && r->priority < e->running->priority && e->stop_reason == STOP_NONE)
        e->stop_reason = STOP_PREEMPT;
    pthread_cond_broadcast(&e->cv);
    pthread_mutex_unlock(&e->mu);
    notify(e);
    return id;
}

int spk_cancel(spk_engine *e, int64_t id) {
    pthread_mutex_lock(&e->mu);
    if (e->running && e->running->id == id) {
        e->stop_reason = STOP_CANCEL;
        pthread_mutex_unlock(&e->mu);
        return 1;
    }
    for (int p = 0; p < SPK_P_COUNT; p++) {
        node *prev = NULL;
        for (node *n = e->head[p]; n; prev = n, n = n->next) {
            if (n->id != id) continue;
            if (prev) prev->next = n->next; else e->head[p] = n->next;
            if (e->tail[p] == n) e->tail[p] = prev;
            e->count[p]--;
            pthread_mutex_unlock(&e->mu);
            finish(n, SPK_E_CANCELLED, NULL, 0);
            notify(e);
            return 1;
        }
    }
    pthread_mutex_unlock(&e->mu);
    return 0;
}

void spk_set_paused(spk_engine *e, unsigned mask) {
    pthread_mutex_lock(&e->mu);
    unsigned newly = mask & ~e->paused;
    e->paused = mask;
    node *list = drain_locked(e, newly);
    if (e->running && (mask & SPK_PAUSE_BIT(e->running->priority)))
        e->stop_reason = STOP_PAUSE;
    pthread_cond_broadcast(&e->cv);
    pthread_mutex_unlock(&e->mu);
    finish_list(list, SPK_E_PAUSED);
    notify(e);
}

int spk_preload(spk_engine *e, int which, char *err, size_t err_len) {
    if (which < 0 || which >= SPK_H_COUNT) return SPK_E_INVALID;
    /* Loading on the caller's thread is fine: the worker only touches h[]
     * under the lock or while running, and open() is not shared state. */
    pthread_mutex_lock(&e->mu);
    while (e->running) pthread_cond_wait(&e->cv, &e->mu);
    int loaded = e->h[which] != NULL;
    pthread_mutex_unlock(&e->mu);
    if (loaded) return SPK_OK;
    char tmp[256];
    return ensure_handle(e, which, err ? err : tmp, err ? err_len : sizeof tmp);
}

int spk_unload(spk_engine *e, int which) {
    if (which < 0 || which >= SPK_H_COUNT) return 0;
    pthread_mutex_lock(&e->mu);
    int freed = 0;
    if (!e->h[which]) { pthread_mutex_unlock(&e->mu); return 1; }
    int busy = e->running && ((e->running->priority == SPK_P_WARDEN) == (which == SPK_H_WARDEN));
    if (busy) {
        e->unload_pending[which] = 1;
    } else {
        e->be.close(e->be.ctx, e->h[which]);
        e->h[which] = NULL;
        freed = 1;
    }
    pthread_mutex_unlock(&e->mu);
    notify(e);
    return freed;
}

void spk_engine_get_state(spk_engine *e, spk_engine_state *out) {
    pthread_mutex_lock(&e->mu);
    snapshot_locked(e, out);
    pthread_mutex_unlock(&e->mu);
}

int spk_engine_info(spk_engine *e, int which, int *out, char *err, size_t err_len) {
    if (which < 0 || which >= SPK_H_COUNT || !out) return SPK_E_INVALID;
    for (int i = 0; i < SPK_INFO_COUNT; i++) out[i] = 0;
    int rc = spk_preload(e, which, err, err_len);
    if (rc != SPK_OK) return rc;
    pthread_mutex_lock(&e->mu);
    if (e->h[which] && e->be.info) e->be.info(e->be.ctx, e->h[which], out);
    else if (e->h[which] && e->be.dim) out[SPK_INFO_DIM] = e->be.dim(e->be.ctx, e->h[which]);
    pthread_mutex_unlock(&e->mu);
    return SPK_OK;
}

void spk_set_queue_limit(spk_engine *e, int limit) {
    pthread_mutex_lock(&e->mu);
    e->queue_limit = limit > 0 ? limit : 16;
    pthread_mutex_unlock(&e->mu);
}

void spk_set_prefill_chunk(spk_engine *e, int bytes) {
    pthread_mutex_lock(&e->mu);
    e->chunk = bytes > 0 ? bytes : 0;
    pthread_mutex_unlock(&e->mu);
}

void spk_set_observer(spk_engine *e, void (*cb)(const spk_engine_state *, void *), void *user) {
    pthread_mutex_lock(&e->mu);
    e->observer = cb;
    e->observer_user = user;
    pthread_mutex_unlock(&e->mu);
}

/* ------------------------------------------------------- mote backend */
#define GRAMMAR_CACHE 8
typedef struct {
    char *model_path, *tok_path;
    int (*memory_ok)(void *, int);
    void *memory_user;
    struct { mote *m; char *schema; mote_grammar *g; } cache[GRAMMAR_CACHE];
    int cache_next;
} mote_ctx;

static void *mb_open(void *ctx, int which, char *err, size_t err_len) {
    (void)which;
    mote_ctx *c = ctx;
    mote *m = mote_create_from_files(c->model_path, c->tok_path);
    if (!m) {
        const char *why = mote_last_error();
        snprintf(err, err_len, "%s", why ? why : "mote_create_from_files failed");
    }
    return m;
}

static void mb_close(void *ctx, void *h) {
    mote_ctx *c = ctx;
    for (int i = 0; i < GRAMMAR_CACHE; i++)
        if (c->cache[i].m == h) {
            mote_grammar_free(c->cache[i].g);
            free(c->cache[i].schema);
            memset(&c->cache[i], 0, sizeof c->cache[i]);
        }
    mote_free(h);
}

static mote_grammar *mb_grammar(mote_ctx *c, mote *m, const char *schema) {
    for (int i = 0; i < GRAMMAR_CACHE; i++)
        if (c->cache[i].m == m && c->cache[i].schema && strcmp(c->cache[i].schema, schema) == 0)
            return c->cache[i].g;
    char err[256];
    mote_grammar *g = mote_grammar_compile(m, schema, err, sizeof err);
    if (!g) return NULL;
    int slot = c->cache_next++ % GRAMMAR_CACHE;
    if (c->cache[slot].g) { mote_grammar_free(c->cache[slot].g); free(c->cache[slot].schema); }
    c->cache[slot].m = m;
    c->cache[slot].schema = dup_or_null(schema);
    c->cache[slot].g = g;
    return g;
}

static int mb_generate(void *ctx, void *h, const char *prompt, const spk_gen_params *p,
                       const char *schema, int (*on_token)(const char *, void *), void *user) {
    mote_ctx *c = ctx;
    mote_params mp = { p->temperature, p->topp, p->repeat_penalty, p->seed, p->max_tokens };
    if (schema) {
        mote_grammar *g = mb_grammar(c, h, schema);
        if (!g) return SPK_E_INVALID;
        int r = mote_generate_constrained(h, prompt, &mp, g, on_token, user);
        return r == MOTE_ERR_GRAMMAR_UNSTARTED ? SPK_E_GRAMMAR : r;
    }
    return mote_generate(h, prompt, &mp, on_token, user);
}

static int mb_embed(void *ctx, void *h, const char *text, float *out, int cap) {
    (void)ctx;
    mote_info_t info;
    mote_get_info(h, &info);
    if (info.dim > cap) return 0;
    return mote_embed(h, text, out);
}

static int mb_dim(void *ctx, void *h) {
    (void)ctx;
    mote_info_t info;
    mote_get_info(h, &info);
    return info.dim;
}

static void mb_info(void *ctx, void *h, int *out) {
    (void)ctx;
    mote_info_t info;
    mote_get_info(h, &info);
    out[SPK_INFO_DIM] = info.dim;
    out[SPK_INFO_LAYERS] = info.n_layers;
    out[SPK_INFO_VOCAB] = info.vocab_size;
    out[SPK_INFO_SEQ_LEN] = info.seq_len;
    out[SPK_INFO_QBITS] = info.quantized ? info.qbits : 32;
}

static int mb_memory_ok(void *ctx, int which) {
    mote_ctx *c = ctx;
    return c->memory_ok ? c->memory_ok(c->memory_user, which) : 1;
}

static void mb_destroy(void *ctx) {
    mote_ctx *c = ctx;
    for (int i = 0; i < GRAMMAR_CACHE; i++)
        if (c->cache[i].g) { mote_grammar_free(c->cache[i].g); free(c->cache[i].schema); }
    free(c->model_path); free(c->tok_path);
    free(c);
}

spk_backend spk_mote_backend(const char *model_path, const char *tokenizer_path,
                             int (*memory_ok)(void *, int), void *memory_user) {
    spk_backend b;
    memset(&b, 0, sizeof b);
    mote_ctx *c = calloc(1, sizeof *c);
    if (!c) return b;
    c->model_path = dup_or_null(model_path);
    c->tok_path = dup_or_null(tokenizer_path);
    c->memory_ok = memory_ok;
    c->memory_user = memory_user;
    b.ctx = c;
    b.open = mb_open;
    b.close = mb_close;
    b.generate = mb_generate;
    b.embed = mb_embed;
    b.dim = mb_dim;
    b.memory_ok = mb_memory_ok;
    b.destroy = mb_destroy;
    b.info = mb_info;
    return b;
}

/* ------------------------------------------------------------- cpu info */
#if defined(__ANDROID__)
/* The Android build's matmul pool (android/src/main/cpp/sparks_parallel.c). */
int spk_pool_threads(void);
#endif

void spk_cpu_info(int out[SPK_CPU_COUNT]) {
    out[SPK_CPU_KERNEL] = mote_quant_kernel();
#if defined(__ANDROID__)
    out[SPK_CPU_THREADS] = spk_pool_threads();
#else
    out[SPK_CPU_THREADS] = 0;   /* GCD on Apple sizes each call itself */
#endif
    out[SPK_CPU_BUILD] = SPK_NATIVE_BUILD;
}
