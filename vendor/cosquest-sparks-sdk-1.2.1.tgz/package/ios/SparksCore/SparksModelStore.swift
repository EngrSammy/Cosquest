import CryptoKit
import Foundation

/// Model files on disk (ARCHITECTURE §6): resumable download with HTTP Range,
/// SHA-256 streamed while downloading, verify against the manifest, atomic
/// rename from `.part`, a receipt, excluded from backup.
///
/// Layout: Application Support/CosQuestSparks/models/<sha256>.<ext> (mq, mtok, asr)
///         (+ .part while downloading, + .receipt once verified).
///
/// Pending: an iOS background URLSession. Background sessions only run
/// download tasks, which cannot stream-hash, so this uses a foreground data
/// task that resumes from the `.part` file (re-hashing it first) whenever
/// the app is back in front. That keeps the integrity rule exact.
public final class SparksModelStore: NSObject, URLSessionDataDelegate {
    public static let shared = SparksModelStore()

    /// Free space required beyond the file itself (ARCHITECTURE §6).
    public static let headroomBytes: Int64 = 500 << 20

    public enum Phase: String { case downloading, paused, verifying, done, error }

    public struct Failure: Error {
        public let code: String      // a SparksErrorCode
        public let message: String
    }

    public typealias Progress = (_ phase: Phase, _ done: Int64, _ total: Int64) -> Void
    public typealias Completion = (Result<URL, Failure>) -> Void

    private final class Job {
        let sha256: String
        let expectedBytes: Int64
        let part: URL
        let final: URL
        let progress: Progress
        var completions: [Completion]
        var hasher = SHA256()
        var handle: FileHandle?
        var received: Int64 = 0
        var lastReport = Date.distantPast
        var failure: Failure?
        init(sha256: String, expectedBytes: Int64, part: URL, final: URL, progress: @escaping Progress, completion: @escaping Completion) {
            self.sha256 = sha256; self.expectedBytes = expectedBytes; self.part = part; self.final = final
            self.progress = progress; self.completions = [completion]
        }
    }

    private let queue: OperationQueue = {
        let q = OperationQueue()
        q.maxConcurrentOperationCount = 1
        q.name = "net.cosquest.sparks.download"
        return q
    }()
    private let lock = NSLock()
    private var jobs: [Int: Job] = [:]             // by task identifier
    private var sessions: [URLSession] = []

    public var directory: URL {
        let d = SparksPaths.root.appendingPathComponent("models", isDirectory: true)
        try? FileManager.default.createDirectory(at: d, withIntermediateDirectories: true)
        return d
    }

    /// On-disk extension by kind. "asr" files (Moonshine Base, Silero) keep no
    /// format extension: the runtime tells ORT from ONNX by the file's bytes.
    static func ext(kind: String) -> String {
        switch kind {
        case "tokenizer": return "mtok"
        case "asr": return "asr"
        default: return "mq"
        }
    }

    public func fileURL(sha256: String, kind: String) -> URL {
        directory.appendingPathComponent("\(sha256.lowercased()).\(Self.ext(kind: kind))")
    }

    /// A verified file with this hash, or nil.
    public func verifiedPath(sha256: String, kind: String) -> URL? {
        let url = fileURL(sha256: sha256, kind: kind)
        let receipt = url.appendingPathExtension("receipt")
        guard FileManager.default.fileExists(atPath: url.path),
              let data = try? Data(contentsOf: receipt),
              let obj = try? JSONSerialization.jsonObject(with: data) as? [String: Any],
              (obj["sha256"] as? String) == sha256.lowercased(),
              let bytes = (obj["bytes"] as? NSNumber)?.int64Value,
              let size = (try? FileManager.default.attributesOfItem(atPath: url.path)[.size] as? NSNumber)?.int64Value,
              size == bytes else { return nil }
        return url
    }

    /// Download (or resume) one file. Concurrent calls for the same hash share one transfer.
    public func download(url: URL, sha256: String, bytes: Int64, kind: String, allowCellular: Bool,
                         authToken: String?, progress: @escaping Progress, completion: @escaping Completion) {
        let sha = sha256.lowercased()
        if let done = verifiedPath(sha256: sha, kind: kind) { completion(.success(done)); return }

        lock.lock()
        if let existing = jobs.values.first(where: { $0.sha256 == sha }) {
            existing.completions.append(completion)
            lock.unlock()
            return
        }
        lock.unlock()

        let final = fileURL(sha256: sha, kind: kind)
        let part = final.appendingPathExtension("part")
        let partBytes = (try? FileManager.default.attributesOfItem(atPath: part.path)[.size] as? NSNumber)?.int64Value ?? 0
        if SparksDevice.shared.freeDiskBytes < bytes - partBytes + Self.headroomBytes {
            completion(.failure(Failure(code: "E_INSUFFICIENT_STORAGE",
                                        message: "need \(bytes - partBytes + Self.headroomBytes) bytes free")))
            return
        }

        let job = Job(sha256: sha, expectedBytes: bytes, part: part, final: final, progress: progress, completion: completion)
        queue.addOperation { [self] in
            // Resume: hash what is already on disk so the digest covers the whole file.
            if partBytes > 0, partBytes <= bytes, let fh = try? FileHandle(forReadingFrom: part) {
                while let chunk = try? fh.read(upToCount: 4 << 20), !chunk.isEmpty {
                    job.hasher.update(data: chunk)
                    job.received += Int64(chunk.count)
                }
                try? fh.close()
            } else {
                try? FileManager.default.removeItem(at: part)
            }
            if !FileManager.default.fileExists(atPath: part.path) {
                FileManager.default.createFile(atPath: part.path, contents: nil,
                                               attributes: [.protectionKey: FileProtectionType.completeUntilFirstUserAuthentication])
            }
            job.handle = try? FileHandle(forWritingTo: part)
            _ = try? job.handle?.seekToEnd()

            let config = URLSessionConfiguration.default
            config.allowsCellularAccess = allowCellular
            config.waitsForConnectivity = true
            config.timeoutIntervalForRequest = 60
            config.timeoutIntervalForResource = 6 * 3600
            let session = URLSession(configuration: config, delegate: self, delegateQueue: queue)
            var req = URLRequest(url: url)
            if let authToken, !authToken.isEmpty { req.setValue("Bearer \(authToken)", forHTTPHeaderField: "Authorization") }
            if job.received > 0 { req.setValue("bytes=\(job.received)-", forHTTPHeaderField: "Range") }
            let task = session.dataTask(with: req)
            lock.lock(); jobs[task.taskIdentifier] = job; sessions.append(session); lock.unlock()
            job.progress(.downloading, job.received, bytes)
            task.resume()
        }
    }

    /// Stop every transfer; `.part` files stay for the next resume.
    public func cancelAll() {
        lock.lock(); let all = sessions; lock.unlock()
        for s in all { s.invalidateAndCancel() }
    }

    /// Delete model files (and their receipts and partial downloads) whose hash
    /// is not in `keep`. With an empty `keep` this is "delete everything" and
    /// also stops transfers. Files of a transfer in flight are left alone.
    public func deleteAll(keeping keep: Set<String>) {
        if keep.isEmpty { cancelAll() }
        lock.lock(); let busy = Set(jobs.values.map { $0.sha256 }); lock.unlock()
        let fm = FileManager.default
        guard let items = try? fm.contentsOfDirectory(at: directory, includingPropertiesForKeys: nil) else { return }
        for url in items {
            let sha = url.lastPathComponent.split(separator: ".").first.map(String.init) ?? ""
            if keep.contains(sha) || (!keep.isEmpty && busy.contains(sha)) { continue }
            try? fm.removeItem(at: url)
        }
    }

    // MARK: URLSessionDataDelegate (runs on `queue`)

    private func job(for task: URLSessionTask) -> Job? {
        lock.lock(); defer { lock.unlock() }
        return jobs[task.taskIdentifier]
    }

    public func urlSession(_ session: URLSession, dataTask: URLSessionDataTask, didReceive response: URLResponse,
                           completionHandler: @escaping (URLSession.ResponseDisposition) -> Void) {
        guard let job = job(for: dataTask), let http = response as? HTTPURLResponse else { completionHandler(.cancel); return }
        switch http.statusCode {
        case 206:
            completionHandler(.allow)
        case 200:
            // The server ignored Range (or this is a fresh start): start over.
            if job.received > 0 {
                job.hasher = SHA256()
                job.received = 0
                try? job.handle?.truncate(atOffset: 0)
            }
            completionHandler(.allow)
        case 416 where job.received == job.expectedBytes:
            completionHandler(.cancel)   // already complete on disk; verify in didComplete
        default:
            job.failure = Failure(code: "E_MODEL_DOWNLOAD_FAILED", message: "HTTP \(http.statusCode)")
            completionHandler(.cancel)
        }
    }

    public func urlSession(_ session: URLSession, dataTask: URLSessionDataTask, didReceive data: Data) {
        guard let job = job(for: dataTask) else { return }
        do { try job.handle?.write(contentsOf: data) } catch {
            job.failure = Failure(code: "E_INSUFFICIENT_STORAGE", message: "write failed: \(error.localizedDescription)")
            dataTask.cancel()
            return
        }
        job.hasher.update(data: data)
        job.received += Int64(data.count)
        if Date().timeIntervalSince(job.lastReport) > 0.25 {
            job.lastReport = Date()
            job.progress(.downloading, job.received, job.expectedBytes)
        }
    }

    public func urlSession(_ session: URLSession, task: URLSessionTask, didCompleteWithError error: Error?) {
        guard let job = job(for: task) else { return }
        lock.lock(); jobs[task.taskIdentifier] = nil; sessions.removeAll { $0 === session }; lock.unlock()
        session.finishTasksAndInvalidate()
        try? job.handle?.close()
        job.handle = nil

        let finish: (Result<URL, Failure>) -> Void = { r in
            if case .failure = r { job.progress(.error, job.received, job.expectedBytes) }
            for c in job.completions { c(r) }
        }
        if let f = job.failure { finish(.failure(f)); return }
        if let e = error as? URLError, e.code == .cancelled, job.received < job.expectedBytes {
            job.progress(.paused, job.received, job.expectedBytes)
            finish(.failure(Failure(code: "E_CANCELLED", message: "download cancelled; it resumes on the next ensure()")))
            return
        }
        if let error, job.received < job.expectedBytes {
            finish(.failure(Failure(code: "E_MODEL_DOWNLOAD_FAILED", message: error.localizedDescription)))
            return
        }

        job.progress(.verifying, job.received, job.expectedBytes)
        let digest = job.hasher.finalize().map { String(format: "%02x", $0) }.joined()
        guard digest == job.sha256, job.received == job.expectedBytes else {
            try? FileManager.default.removeItem(at: job.part)
            finish(.failure(Failure(code: "E_MODEL_CHECKSUM_MISMATCH",
                                    message: "got \(digest) (\(job.received) bytes), want \(job.sha256) (\(job.expectedBytes) bytes)")))
            return
        }
        do {
            let fm = FileManager.default
            if fm.fileExists(atPath: job.final.path) { try fm.removeItem(at: job.final) }
            try fm.moveItem(at: job.part, to: job.final)
            var final = job.final
            var rv = URLResourceValues(); rv.isExcludedFromBackup = true
            try? final.setResourceValues(rv)
            let receipt: [String: Any] = ["sha256": job.sha256, "bytes": job.received,
                                          "verifiedAt": ISO8601DateFormatter().string(from: Date())]
            try JSONSerialization.data(withJSONObject: receipt).write(to: job.final.appendingPathExtension("receipt"), options: .atomic)
            job.progress(.done, job.received, job.expectedBytes)
            finish(.success(job.final))
        } catch {
            finish(.failure(Failure(code: "E_INSUFFICIENT_STORAGE", message: "could not store the model: \(error.localizedDescription)")))
        }
    }
}
