/**
 * What the phone does with a leased job, a hint or a scribe check, given the
 * model: the composition of the tasks.ts calls (which task, over which lines,
 * which rule decides). sdk.ts runs these over the native engine; the
 * time-lapse simulator (apps/simulator/src/qlm.ts) runs the very same code
 * over the released model on a GPU, so its phones behave like this SDK.
 *
 * Pure: no native, no I/O. Callers pass a tasks.ts `Generate`.
 */
import type {
  ChatMember, JobInput, JobOutput, OutlineSpanSummary, SparkCatalogEntry, SparkId,
  TopicId, TopicShift, TranscriptSegment,
} from '../index';
import * as T from './tasks';
import { sparksError, trigramSimilarity } from './runtime';

/** Detect job: messages within this window before the tip form the burst (ARCHITECTURE §3.1). */
export const DETECT_WINDOW_MS = 120000;
/** match_existing confidence at or above which a burst or typed subject is the same as an existing Spark. */
export const MATCH_MIN_CONFIDENCE = 0.6;
/** Substantive new messages at or above which an unchanged summary counts as stuck rather than "nothing new". */
export const SUMMARY_STUCK_MIN_NEW = 3;
/** Lines in the stricter summary retry (the trained first-summary shape: up to 12 lines). */
const SUMMARY_RETRY_LINES = 12;

/** Lookups a job needs beyond its input. */
export interface JobContext {
  /** Members of a chat as this phone knows them (spark.assign and spark.rolepings name senders and role holders). */
  membersOf(chatId: string): Promise<ChatMember[]>;
}

/** Run one non-scribe job to its output. Throws (E_ENGINE) when no faithful summary came out. */
export async function runJob(input: JobInput, gen: T.Generate, ctx: JobContext): Promise<JobOutput> {
  switch (input.type) {
    case 'spark.detect': return jobDetect(input, gen);
    case 'spark.assign': {
      const assignments: { messageId: string; sparkId: SparkId | null; score: number }[] = [];
      const ordered = [...input.messages].sort((a, b) => a.seq - b.seq);
      const members = await ctx.membersOf(input.chatId);
      for (let i = 0; i < ordered.length; i++) {
        const m = ordered[i];
        const recent = ordered.slice(Math.max(0, i - 3), i).map((x) => ({ who: T.nameOf(members, x.senderId), text: x.text }));
        const active = rankCatalog(input.active, m.text, 6);
        const r = await T.assignMessage(gen, active, recent, { who: T.nameOf(members, m.senderId), text: m.text });
        assignments.push({ messageId: m.messageId, sparkId: r ?? null, score: r ? 0.9 : 0 });
      }
      return { type: 'spark.assign', assignments };
    }
    case 'spark.summarize': return summarizeJob(input, gen);
    case 'spark.rolepings': {
      const members = await ctx.membersOf(input.chatId);
      const roles = input.roles.map((r) => ({ ...r, names: r.userIds.map((u) => T.nameOf(members, u)) }));
      const pings = await T.rolePing(gen, input.subject, input.summary, roles);
      return { type: 'spark.rolepings', pings: pings ?? [] };
    }
    case 'call.outline.map':
      return { type: 'call.outline.map', span: await outlineSpan(gen, input.spanId, input.topicTitle, input.segments, input.participants) };
    case 'call.outline.reduce': {
      const r = await outlineReduce(gen, input.spans);
      return { type: 'call.outline.reduce', ...r };
    }
    default: throw sparksError('E_INVALID_ARGUMENT', `unsupported job ${(input as { type: string }).type}`, false);
  }
}

/**
 * spark.detect = subject_line over the burst, then the duplicate and revival
 * check (existingSpark) against active AND dormant Sparks before anything new
 * is proposed. The 3-messages/2-senders/120-s rule is re-checked here exactly
 * as the backend will.
 */
export async function jobDetect(input: Extract<JobInput, { type: 'spark.detect' }>, gen: T.Generate): Promise<JobOutput> {
  const none = (confidence: number): JobOutput => ({ type: 'spark.detect', verdict: 'none', subject: null, sparkId: null, memberMessageIds: [], confidence });
  const window = [...input.window].filter((m) => !m.deleted && m.kind === 'text' && m.text.trim()).sort((a, b) => a.seq - b.seq);
  const tip = window.find((m) => m.messageId === input.tipMessageId) ?? window[window.length - 1];
  if (!tip) return none(0.5);
  const tipAt = Date.parse(tip.sentAt);
  const burst = window.filter((m) => m.seq <= tip.seq && tipAt - Date.parse(m.sentAt) <= DETECT_WINDOW_MS).slice(-10);
  if (burst.length < 3 || new Set(burst.map((m) => m.senderId)).size < 2) return none(0.5);
  const lines = burst.map((m) => ({ who: T.nameOf(input.members, m.senderId), text: m.text }));
  const subject = await T.subjectLine(gen, lines);
  if (!subject) return none(0.7);
  const ids = burst.map((m) => m.messageId);
  const hit = await existingSpark(gen, subject, lines, input.catalog);
  if (hit) {
    return { type: 'spark.detect', verdict: hit.entry.state === 'active' ? 'attach' : 'revive', subject: null, sparkId: hit.entry.sparkId, memberMessageIds: ids, confidence: hit.confidence };
  }
  return { type: 'spark.detect', verdict: 'new', subject, sparkId: null, memberMessageIds: ids, confidence: 0.8 };
}

/**
 * The duplicate and revival check that runs before a NEW Spark is proposed,
 * over active and dormant Sparks (the six closest by subject and text), with
 * the trained match_existing task, on the phone already running the detect
 * job (model loaded, prompt prefix cached: one or two short generations, only
 * when a Spark would otherwise be created).
 *
 * 1. revival mode over the burst's messages (the trained revival check);
 * 2. if that finds nothing, manual mode over the proposed subject and the
 *    burst's most on-subject message. The subject sums up the whole burst, so
 *    this second look does not depend on which 3 to 10 messages happened to
 *    fall in the detection window.
 */
export async function existingSpark(gen: T.Generate, subject: string, lines: T.Line[], catalog: SparkCatalogEntry[]): Promise<{ entry: SparkCatalogEntry; confidence: number } | null> {
  if (!catalog.length) return null;
  const candidates = rankCatalog(catalog, `${subject} ${lines.map((l) => l.text).join(' ')}`, 6);
  const pick = (m: { sparkId: string | null; confidence: number } | null) => {
    if (!m?.sparkId || m.confidence < MATCH_MIN_CONFIDENCE) return null;
    const entry = candidates.find((c) => c.sparkId === m.sparkId);
    return entry ? { entry, confidence: m.confidence } : null;
  };
  const revival = pick(await T.matchExisting(gen, { mode: 'revival', messages: lines }, candidates));
  if (revival) return revival;
  const seed = [...lines].sort((a, b) => trigramSimilarity(subject, b.text) - trigramSimilarity(subject, a.text))[0] ?? null;
  return pick(await T.matchExisting(gen, { mode: 'manual', subject, seed }, candidates));
}

/**
 * spark.summarize. The model sees only the messages since the last summary
 * (the previous summary carries the rest). The trained answer to "nothing
 * new" is the previous summary unchanged, which is right for chatter but
 * froze big Sparks: when it comes back unchanged although at least
 * SUMMARY_STUCK_MIN_NEW substantive new messages exist, retry once with the
 * stricter framing of the task contract, a first summary (`summary: (none)`)
 * of the newest lines, preceded by the lines just before them for context.
 * If that is unchanged too (or not faithful), keep the old summary and
 * report it `stale`: the backend keeps it and retries in the next round.
 */
export async function summarizeJob(input: Extract<JobInput, { type: 'spark.summarize' }>, gen: T.Generate): Promise<Extract<JobOutput, { type: 'spark.summarize' }>> {
  const all = [...input.messages].sort((a, b) => a.seq - b.seq).filter((m) => !m.deleted && m.text.trim());
  const fresh = all.filter((m) => input.previousBasedOnSeq === null || m.seq > input.previousBasedOnSeq);
  const basedOnSeq = Math.max(input.previousBasedOnSeq ?? 0, ...input.messages.map((m) => m.seq));
  const names = input.members.map((m) => m.displayName);
  const line = (m: { senderId: string; text: string }) => ({ who: T.nameOf(input.members, m.senderId), text: m.text });
  const prev = input.previousSummary;
  const out = (summary: string, stale = false): Extract<JobOutput, { type: 'spark.summarize' }> =>
    ({ type: 'spark.summarize', summary: summary.slice(0, 600), basedOnSeq, ...(stale ? { stale: true } : {}) });
  const changed = (s: string | null): s is string => !!s && (prev === null || sameSummary(s, prev) === false);

  const first = fresh.length ? await T.runningSummary(gen, prev, fresh.map(line), names) : prev;
  if (changed(first)) return out(first);
  const nNew = fresh.filter((m) => T.substantive(m.text)).length;
  if (prev !== null && nNew < SUMMARY_STUCK_MIN_NEW) return out(prev);   // nothing new: the model is right
  const retryLines = summaryRetryLines(all, fresh);
  // With no previous summary and no extra context the retry would repeat the first prompt word for word (greedy: same answer).
  const repeat = prev === null && retryLines.length === fresh.length && retryLines.every((m, i) => m === fresh[i]);
  if (!fresh.length || repeat) return out(prev ?? '', true);
  const retry = await T.runningSummary(gen, null, retryLines.map(line), names);
  if (changed(retry)) return out(retry);
  return out(prev ?? '', true);
}

/** The stricter retry's lines: the newest messages (substantive ones when there are many), with earlier lines for context. */
export function summaryRetryLines<M extends { text: string }>(all: M[], fresh: M[]): M[] {
  if (fresh.length <= SUMMARY_RETRY_LINES) return all.slice(-SUMMARY_RETRY_LINES);
  const sub = fresh.filter((m) => T.substantive(m.text));
  return (sub.length >= SUMMARY_RETRY_LINES / 2 ? sub : fresh).slice(-SUMMARY_RETRY_LINES);
}

const normSummary = (s: string) => s.toLowerCase().replace(/\s+/g, ' ').replace(/[\s.!?]+$/, '').trim();
export const sameSummary = (a: string, b: string) => normSummary(a) === normSummary(b);

/** call.outline.map: call_outline over the span; decisions and action items quoted from the transcript. */
export async function outlineSpan(gen: T.Generate, spanId: string, topicTitle: string, segments: TranscriptSegment[], participants: ChatMember[]): Promise<OutlineSpanSummary> {
  const { sorted, rows } = T.segmentRows(segments.filter((s) => s.text.trim()), participants);
  const names = [...new Set(sorted.map((s) => T.nameOf(participants, s.userId)))];
  const source = rows.map((r) => `${r.who}: ${r.text}`).join('\n');
  const groups = sorted.length ? await T.callOutline(gen, rows) : null;
  const faithful = (groups ?? []).filter((x) => x.summary && T.looksEnglish(x.title) && !T.unsupported(x.summary, source, names).length);
  const title = faithful.length === 1 ? faithful[0].title : ((T.looksEnglish(topicTitle) && topicTitle) || faithful[0]?.title || 'Call');
  const summary = faithful.length
    ? T.clean(faithful.map((x) => x.summary).join(' '), 300)
    : `${names.join(', ')} talked about ${title.toLowerCase()}.`;
  const { decisions, actionItems } = T.decisionsAndActions(sorted);
  return {
    spanId, title: T.clean(title, 60), summary,
    points: faithful.length > 1 ? faithful.map((x) => T.clean(`${x.title}: ${x.summary}`, 200)) : [],
    decisions, actionItems,
    startMs: sorted[0]?.startMs ?? 0, endMs: sorted[sorted.length - 1]?.endMs ?? 0,
    speakerIds: [...new Set(sorted.map((s) => s.userId))],
  };
}

/**
 * call.outline.reduce: call_outline over span summaries (`[tN] Title: summary`),
 * then the backend's rule enforced locally: every span in exactly one topic.
 */
export async function outlineReduce(gen: T.Generate, spans: OutlineSpanSummary[]): Promise<Omit<Extract<JobOutput, { type: 'call.outline.reduce' }>, 'type'>> {
  const ordered = [...spans].sort((a, b) => a.startMs - b.startMs);
  const rows = ordered.map((s, i) => ({ id: `t${i + 1}`, who: s.title, text: s.summary }));
  const label = new Map(rows.map((r, i) => [r.id, ordered[i]]));
  const groups = ordered.length > 1 ? await T.callOutline(gen, rows) : null;
  const used = new Set<string>();
  const topics: { title: string; spanIds: string[]; summary: string; points: string[]; decisions: string[]; actionItems: { text: string; ownerUserId?: string }[] }[] = [];
  const source = ordered.map((s) => `${s.title}: ${s.summary} ${s.points.join(' ')}`).join('\n');
  const addTopic = (title: string, summary: string | null, members: OutlineSpanSummary[]) => {
    if (!members.length) return;
    for (const m of members) used.add(m.spanId);
    const ok = summary && !T.unsupported(summary, source).length ? summary : members.map((m) => m.summary).join(' ');
    topics.push({
      title: T.clean(title, 60), spanIds: members.map((m) => m.spanId), summary: T.clean(ok, 400),
      points: members.flatMap((m) => m.points).slice(0, 6),
      decisions: members.flatMap((m) => m.decisions).slice(0, 4),
      actionItems: members.flatMap((m) => m.actionItems).slice(0, 6),
    });
  };
  for (const grp of groups ?? []) {
    if (!T.looksEnglish(grp.title)) continue;   // its spans fall back to their own titles below
    const members = grp.spanIds.map((id) => label.get(id)).filter((s): s is OutlineSpanSummary => !!s && !used.has(s.spanId));
    addTopic(grp.title, grp.summary, [...new Set(members)]);
  }
  // Spans the model left out (or every span, if it failed): their own topics, same titles merged.
  for (const s of ordered) {
    if (used.has(s.spanId)) continue;
    const same = ordered.filter((x) => !used.has(x.spanId) && x.title.toLowerCase() === s.title.toLowerCase());
    addTopic(s.title, null, same);
  }
  const titles = topics.map((t) => t.title);
  const nDec = topics.reduce((n, t) => n + t.decisions.length, 0), nAct = topics.reduce((n, t) => n + t.actionItems.length, 0);
  const join = (n: string[]) => (n.length <= 1 ? n.join('') : `${n.slice(0, -1).join(', ')} and ${n[n.length - 1]}`);
  return {
    title: T.clean(titles.length > 2 ? `${titles[0]}, ${titles[1]} and more` : join(titles), 60) || 'Call',
    summary: `The call covered ${topics.length} topic${topics.length === 1 ? '' : 's'}: ${join(titles.map((t) => t.toLowerCase()))}. ${nDec} decision${nDec === 1 ? '' : 's'}, ${nAct} action item${nAct === 1 ? '' : 's'}.`,
    topics,
  };
}

/**
 * message.spark_hint for one of this user's own messages (method 'model'):
 * the trained assign_message task over the active Sparks (the six closest)
 * and the last three messages before it. Embedding similarity could not tell
 * related from unrelated messages (0.67 to 0.97 for both), so the model
 * decides. Null when the model's answer did not parse: send no hint, and the
 * backend sorts the message with spark.assign on another phone.
 */
export async function modelHint(gen: T.Generate, active: SparkCatalogEntry[], recent: T.Line[], message: T.Line): Promise<{ sparkId: SparkId | null; score: number } | null> {
  if (!active.length) return { sparkId: null, score: 0 };
  const context = `${message.text} ${recent.map((r) => r.text).join(' ')}`;
  const r = await T.assignMessage(gen, rankCatalog(active, context, 6), recent.slice(-3), message);
  if (r === undefined) return null;
  return { sparkId: r, score: r ? 1 : 0 };
}

export interface ScribeView {
  current: { topicId: TopicId; title: string } | null;
  topics: TopicShift[];
  segments: TranscriptSegment[];
  participants: ChatMember[];
}

/** One scribe check (ARCHITECTURE §4.2): subject_line for the first topic, then topic_shift. Null: nothing to propose. */
export async function scribeProposal(gen: T.Generate, st: ScribeView): Promise<{ title: string; returningToTopicId: TopicId | null; startedAtMs: number } | null> {
  const recent = st.segments.slice(-6);
  if (recent.length < 2) return null;
  let title: string | null = null;
  let returning: TopicShift | undefined;
  if (!st.current) {
    // The first topic: from what people say, not from greetings ("can you hear me?", "hi all").
    const said = st.segments.filter((s) => !T.isChatter(s.text)).slice(-6);
    if (said.length < 2) return null;
    title = await T.subjectLine(gen, said.map((s) => ({ who: T.nameOf(st.participants, s.userId), text: s.text })));
  } else {
    const { rows } = T.segmentRows(recent, st.participants);
    const r = await T.topicShift(gen, st.current.title, T.earlierTitles(st.topics, st.current.title), rows);
    if (r && r.shift && r.title !== st.current.title) {
      title = r.title;
      returning = r.returning ? st.topics.find((t) => t.title === r.title) : undefined;
    }
  }
  if (!title || !T.looksEnglish(title)) return null;
  return { title: returning?.title ?? title, returningToTopicId: returning?.topicId ?? null, startedAtMs: Math.round(recent[Math.max(0, recent.length - 4)].startMs) };
}

/** Catalog entries most lexically related to `text`, for short prompts. */
export function rankCatalog(entries: SparkCatalogEntry[], text: string, n: number): SparkCatalogEntry[] {
  if (entries.length <= n) return entries;
  return [...entries]
    .map((e) => ({ e, s: trigramSimilarity(text, `${e.subject} ${e.summary ?? ''}`) }))
    .sort((a, b) => b.s - a.s || Date.parse(b.e.lastMessageAt) - Date.parse(a.e.lastMessageAt))
    .slice(0, n).map((x) => x.e);
}

export function chunkByWords(segs: TranscriptSegment[], maxWords: number): TranscriptSegment[][] {
  const out: TranscriptSegment[][] = [];
  let cur: TranscriptSegment[] = [], n = 0;
  for (const s of [...segs].sort((a, b) => a.startMs - b.startMs)) {
    const w = s.text.split(/\s+/).length;
    if (cur.length && n + w > maxWords) { out.push(cur); cur = []; n = 0; }
    cur.push(s); n += w;
  }
  if (cur.length) out.push(cur);
  return out;
}

