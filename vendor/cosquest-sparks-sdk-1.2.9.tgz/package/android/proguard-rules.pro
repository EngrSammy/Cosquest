# Consumer rules for apps that minify.
# JNI: libcosquestsparks.so calls back into these by name.
-keep class com.cosquest.sparks.** { *; }
# BouncyCastle (bcprov-jdk18on) references JDK classes Android lacks; only the
# lightweight HPKE/X25519 classes are used, none of which touch them.
-dontwarn javax.naming.**
-dontwarn org.bouncycastle.**
