package com.cosquest.sparks.core

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import java.io.File
import java.security.KeyStore
import java.util.UUID
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/** Files under noBackupFilesDir/CosQuestSparks: never in Auto Backup or device transfer. */
object SparksPaths {
  fun root(context: Context): File =
    File(context.noBackupFilesDir, "CosQuestSparks").also { it.mkdirs() }
}

/**
 * The device key (DATA_CONTRACT §7) and the AES keys of the local store, in
 * the Android Keystore.
 *
 * The X25519 device key: Android Keystore has no X25519 key agreement on most
 * devices (and none at all before API 31), so the key is generated in
 * software and stored wrapped: AES-256-GCM under a non-exportable Keystore key
 * (hardware-backed where the phone has a TEE or StrongBox). The wrapped blob
 * is `keys/device-key.<safeName(scope)>` = nonce(12) | ciphertext | tag(16)
 * over sk(32) | kid(8 ASCII), the same 40 bytes the iOS Keychain item holds.
 * The private key is in app memory only while a payload is being opened.
 *
 * Keystore keys are created without user authentication and without
 * setUnlockedDeviceRequired, so background jobs can use them once the phone
 * has been unlocked after boot: the iOS AfterFirstUnlockThisDeviceOnly
 * behaviour. They never leave the device and are not backed up.
 */
object SparksKeystore {
  private const val PROVIDER = "AndroidKeyStore"
  private const val ALIAS_PREFIX = "net.cosquest.sparks."
  private const val GCM_TAG_BITS = 128

  class DeviceKey(val privateKey: ByteArray, val kid: String) {
    val publicKeyB64url: String get() = SparksCrypto.b64url(SparksCrypto.publicKey(privateKey))
  }

  private val lock = Any()

  private fun keyStore(): KeyStore = KeyStore.getInstance(PROVIDER).apply { load(null) }

  /** A non-exportable AES-256-GCM key, created on first use. */
  internal fun aesKey(alias: String): SecretKey {
    val ks = keyStore()
    (ks.getKey(alias, null) as? SecretKey)?.let { return it }
    val gen = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, PROVIDER)
    gen.init(
      KeyGenParameterSpec.Builder(alias, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
        .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
        .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
        .setKeySize(256)
        .build(),
    )
    return gen.generateKey()
  }

  internal fun deleteAlias(alias: String) {
    try {
      keyStore().deleteEntry(alias)
    } catch (_: Exception) {
    }
  }

  /** nonce(12) | ciphertext | tag(16). The Keystore picks the nonce. */
  internal fun seal(key: SecretKey, plain: ByteArray, aad: ByteArray?): ByteArray {
    val c = Cipher.getInstance("AES/GCM/NoPadding")
    c.init(Cipher.ENCRYPT_MODE, key)
    if (aad != null) c.updateAAD(aad)
    val body = c.doFinal(plain)
    val iv = c.iv
    check(iv.size == 12) { "unexpected GCM nonce size ${iv.size}" }
    return iv + body
  }

  /** null when the blob does not open (wrong key, tampered, truncated). */
  internal fun open(key: SecretKey, blob: ByteArray, aad: ByteArray?): ByteArray? {
    if (blob.size < 12 + 16) return null
    return try {
      val c = Cipher.getInstance("AES/GCM/NoPadding")
      c.init(Cipher.DECRYPT_MODE, key, GCMParameterSpec(GCM_TAG_BITS, blob, 0, 12))
      if (aad != null) c.updateAAD(aad)
      c.doFinal(blob, 12, blob.size - 12)
    } catch (_: Exception) {
      null
    }
  }

  private fun deviceKeyAlias(scope: String) = ALIAS_PREFIX + "device-key." + SparksCrypto.safeName(scope)
  private fun deviceKeyFile(context: Context, scope: String) =
    File(File(SparksPaths.root(context), "keys").also { it.mkdirs() }, "device-key." + SparksCrypto.safeName(scope))

  /** The device's X25519 key for this (user, session) scope, created on first use. */
  fun deviceKey(context: Context, scope: String): DeviceKey {
    synchronized(lock) {
      val file = deviceKeyFile(context, scope)
      val wrap = aesKey(deviceKeyAlias(scope))
      val aad = ("device-key." + scope).toByteArray(Charsets.UTF_8)
      if (file.exists()) {
        val plain = open(wrap, file.readBytes(), aad)
        if (plain != null && plain.size == 32 + 8) {
          return DeviceKey(plain.copyOfRange(0, 32), String(plain, 32, 8, Charsets.US_ASCII))
        }
        // Unreadable (Keystore key lost, e.g. after a restore to a new phone): a new key is a new device.
      }
      val sk = SparksCrypto.newPrivateKey()
      val kid = UUID.randomUUID().toString().replace("-", "").take(8).lowercase()
      writeAtomic(file, seal(wrap, sk + kid.toByteArray(Charsets.US_ASCII), aad))
      return DeviceKey(sk, kid)
    }
  }

  fun deleteDeviceKey(context: Context, scope: String) {
    synchronized(lock) {
      deviceKeyFile(context, scope).delete()
      deleteAlias(deviceKeyAlias(scope))
    }
  }

  internal fun writeAtomic(file: File, data: ByteArray) {
    val tmp = File(file.parentFile, file.name + ".tmp")
    tmp.outputStream().use { it.write(data); it.fd.sync() }
    if (!tmp.renameTo(file)) {
      file.delete()
      check(tmp.renameTo(file)) { "could not write ${file.name}" }
    }
  }
}

/**
 * The encrypted local store (PRIVACY §3): one AES-256-GCM sealed file per
 * name, scoped per (userId, sessionId). Same logical layout as iOS:
 *   CosQuestSparks/store/<safeName(scope)>/<safeName(name)>
 *   contents: nonce(12) | ciphertext | tag(16), aad = name (UTF-8)
 * The key is a per-scope AES-256-GCM key in the Android Keystore
 * ("net.cosquest.sparks.store.<safeName(scope)>"); encryption and decryption
 * run inside the Keystore, so the key never enters app memory. Files live
 * under noBackupFilesDir (app-private, excluded from backup).
 */
class SparksSecureStore(context: Context, private val scope: String) {
  private val dir = File(File(SparksPaths.root(context), "store"), SparksCrypto.safeName(scope)).also { it.mkdirs() }
  private val alias = "net.cosquest.sparks.store." + SparksCrypto.safeName(scope)
  private val key = SparksKeystore.aesKey(alias)
  private val lock = Any()

  private fun file(name: String) = File(dir, SparksCrypto.safeName(name))

  fun get(name: String): String? {
    synchronized(lock) {
      val f = file(name)
      if (!f.exists()) return null
      val plain = SparksKeystore.open(key, f.readBytes(), name.toByteArray(Charsets.UTF_8)) ?: return null
      return String(plain, Charsets.UTF_8)
    }
  }

  fun set(name: String, value: String?) {
    synchronized(lock) {
      val f = file(name)
      if (value == null) {
        f.delete()
        return
      }
      dir.mkdirs()
      SparksKeystore.writeAtomic(f, SparksKeystore.seal(key, value.toByteArray(Charsets.UTF_8), name.toByteArray(Charsets.UTF_8)))
    }
  }

  /** Delete everything in this scope, and its key. */
  fun wipe() {
    synchronized(lock) {
      dir.deleteRecursively()
      SparksKeystore.deleteAlias(alias)
    }
  }
}
