package com.cosquest.sparks

import java.util.concurrent.atomic.AtomicLong

/**
 * How the host's call stack hands this user's microphone audio to Sparks
 * transcription, native to native (AudioSource 'external'). Mirrors
 * SparksAudioSink on iOS.
 *
 *   // in the call stack's capture callback (any thread, real-time safe:
 *   // it copies into the transcriber's ring and returns; no lock, no allocation)
 *   SparksAudioSink.pushPCM16(samples, n, 48000)
 *
 * Audio is dropped unless a transcription session is running and unmuted
 * (calls.startTranscription in JS). Mono; any rate from 8 to 192 kHz
 * (resampled to 16 kHz in C).
 */
object SparksAudioSink {
  // The running transcriber (an AsrBox * from the JNI bridge), or 0. Set by
  // SparksModule; a transcriber outlives its detach by seconds, so a push
  // racing a stop is harmless (spk_asr drops audio once inactive).
  private val asr = AtomicLong(0)

  /** True while a transcription session is accepting audio. */
  @JvmStatic
  val isActive: Boolean get() = asr.get() != 0L

  /** Mono 16-bit PCM; the first `count` samples of `samples`. */
  @JvmStatic
  fun pushPCM16(samples: ShortArray, count: Int, sampleRate: Int) {
    val h = asr.get()
    if (h != 0L && count > 0) SparksNative.asrPushI16(h, samples, minOf(count, samples.size), sampleRate)
  }

  /** Mono float PCM in [-1, 1]; the first `count` samples of `samples`. */
  @JvmStatic
  fun pushFloat32(samples: FloatArray, count: Int, sampleRate: Int) {
    val h = asr.get()
    if (h != 0L && count > 0) SparksNative.asrPushF32(h, samples, minOf(count, samples.size), sampleRate)
  }

  internal fun attach(handle: Long) {
    asr.set(handle)
  }
}
