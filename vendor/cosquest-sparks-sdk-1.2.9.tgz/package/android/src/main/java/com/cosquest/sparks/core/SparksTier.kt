package com.cosquest.sparks.core

/**
 * What this phone can run (ARCHITECTURE §2.3, PERFORMANCE §5). Pure logic,
 * no Android types, so the module and the JVM unit tests share one copy.
 * A port of ios/SparksCore/SparksTier.swift: same constants, same decisions.
 */
enum class SparksTier(val wire: String) {
  FULL("full"), LITE("lite"), NONE("none");

  companion object {
    fun from(s: String?): SparksTier? = values().firstOrNull { it.wire == s }
  }
}

data class SparksTierDecision(
  val tier: SparksTier,
  /** null when nothing lowered it; else 'ram' | 'cpu' | 'os' | 'forced' | 'manifest'. */
  val reason: String?,
)

data class SparksTierVariant(val tier: SparksTier, val minRamBytes: Long)

object SparksTierPolicy {
  /** Phones report less than their marketed RAM. Same constant as SPK_RAM_TOLERANCE in sparks_core.h. */
  const val RAM_TOLERANCE = 0.85
  /** Default floors before a manifest is known (manifest min_ram_bytes refines them). */
  const val FULL_FLOOR_BYTES: Long = 6L shl 30
  const val LITE_FLOOR_BYTES: Long = 3L shl 30
  /** Minimum iOS major version (podspec deployment target). */
  const val MIN_IOS_MAJOR = 16
  /** Minimum Android API level (build.gradle minSdk). */
  const val MIN_ANDROID_API = 26
  /** The only ABI the model tiers run on. */
  const val MODEL_ABI = "arm64-v8a"

  fun meets(ramBytes: Long, minRamBytes: Long): Boolean =
    ramBytes.toDouble() >= RAM_TOLERANCE * minRamBytes.toDouble()

  /**
   * @param osMajor iOS major version, or the Android API level.
   * @param is64Bit on Android: the native library is arm64-v8a. Any other ABI is `none` ('cpu').
   * @param forced honoured only when [allowForce] (debug builds).
   * @param variants manifest variants, best first. When given, the tier is that
   *   of the first variant the phone meets, never higher than RAM/CPU/OS allow.
   */
  fun decide(
    ramBytes: Long,
    armDotProd: Boolean,
    platform: String = "android",
    osMajor: Int,
    is64Bit: Boolean = true,
    forced: SparksTier? = null,
    allowForce: Boolean = false,
    variants: List<SparksTierVariant>? = null,
  ): SparksTierDecision {
    if (forced != null && allowForce) return SparksTierDecision(forced, "forced")
    if (platform == "ios" && osMajor < MIN_IOS_MAJOR) return SparksTierDecision(SparksTier.NONE, "os")
    if (platform == "android" && osMajor < MIN_ANDROID_API) return SparksTierDecision(SparksTier.NONE, "os")
    if (!is64Bit) return SparksTierDecision(SparksTier.NONE, "cpu")

    val cap: SparksTier
    var reason: String? = null
    if (meets(ramBytes, FULL_FLOOR_BYTES)) {
      // Android needs SDOT for the 1.7B to be usable; every iOS 16 device runs it without.
      if (platform == "android" && !armDotProd) {
        cap = SparksTier.LITE
        reason = "cpu"
      } else {
        cap = SparksTier.FULL
      }
    } else if (meets(ramBytes, LITE_FLOOR_BYTES)) {
      cap = SparksTier.LITE
      reason = "ram"
    } else {
      return SparksTierDecision(SparksTier.NONE, "ram")
    }

    if (variants.isNullOrEmpty()) return SparksTierDecision(cap, reason)
    var blockedByRam = false
    for (v in variants) {
      if (v.tier == SparksTier.NONE || rank(v.tier) < rank(cap)) continue
      if (meets(ramBytes, v.minRamBytes)) {
        if (v.tier == cap) return SparksTierDecision(cap, reason)
        // Lower than the hardware allows: the manifest's floor or variant list decided it.
        return SparksTierDecision(v.tier, reason ?: if (blockedByRam) "ram" else "manifest")
      }
      blockedByRam = true
    }
    return SparksTierDecision(SparksTier.NONE, reason ?: if (blockedByRam) "ram" else "manifest")
  }

  /** Lower is better. */
  internal fun rank(t: SparksTier): Int = when (t) {
    SparksTier.FULL -> 0
    SparksTier.LITE -> 1
    SparksTier.NONE -> 2
  }

  /**
   * Memory budget for opening engine handle 0 (warden) or 1 (sparks)
   * (PERFORMANCE §2), same numbers as SparksDevice.memoryOK on iOS. The lite
   * 0.6B has the same KV per token as the 1.7B (224 KiB), so lite needs
   * 260 / 520 MiB (smaller activations only), not the old 0.5B's 100 / 140.
   * [availableBytes] < 0 means no limit is known.
   */
  fun memoryOK(tier: String, handle: Int, availableBytes: Long, memoryWarningAgeMs: Double): Boolean {
    val mib = if (tier == "full") (if (handle == 0) 280L else 560L) else (if (handle == 0) 260L else 520L)
    if (memoryWarningAgeMs in 0.0..60_000.0 && handle != 0) return false
    return availableBytes < 0 || availableBytes >= (mib shl 20)
  }
}
