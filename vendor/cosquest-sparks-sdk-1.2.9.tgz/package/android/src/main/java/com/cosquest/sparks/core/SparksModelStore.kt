package com.cosquest.sparks.core

import android.content.Context
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

/**
 * Model files on disk (ARCHITECTURE §6): resumable download with HTTP Range,
 * SHA-256 streamed while downloading, verify against the manifest, atomic
 * rename from `.part`, a receipt, excluded from backup (noBackupFilesDir).
 * The Android counterpart of ios/SparksCore/SparksModelStore.swift; same
 * layout, phases and error codes:
 *
 *   CosQuestSparks/models/<sha256>.<ext> (mq, mtok, asr)
 *     (+ .part while downloading, + .receipt once verified)
 *
 * Foreground transfers over HttpURLConnection on a small thread pool. A
 * cancelled or interrupted download keeps its `.part` and resumes (re-hashing
 * the part first) on the next ensure(), as on iOS. Background transfer
 * (WorkManager) is not used in v1.
 */
class SparksModelStore private constructor(private val app: Context) {
  companion object {
    /** Free space required beyond the file itself (ARCHITECTURE §6). */
    const val HEADROOM_BYTES: Long = 500L shl 20

    @Volatile private var instance: SparksModelStore? = null

    fun get(context: Context): SparksModelStore =
      instance ?: synchronized(this) { instance ?: SparksModelStore(context.applicationContext).also { instance = it } }

    /** On-disk extension by kind. "asr" files keep no format extension: the runtime tells ORT from ONNX by the bytes. */
    fun ext(kind: String) = when (kind) {
      "tokenizer" -> "mtok"
      "asr" -> "asr"
      else -> "mq"
    }
  }

  class Failure(val code: String, message: String) : Exception(message)

  /** phase: downloading | paused | verifying | done | error */
  fun interface Progress {
    fun report(phase: String, done: Long, total: Long)
  }

  interface Completion {
    fun success(path: String)
    fun failure(code: String, message: String)
  }

  private class Job(val sha256: String, val expectedBytes: Long, val part: File, val final: File, val progress: Progress) {
    val completions = mutableListOf<Completion>()
    @Volatile var connection: HttpURLConnection? = null
    @Volatile var cancelled = false
  }

  private val pool: ExecutorService = Executors.newFixedThreadPool(3) { r -> Thread(r, "sparks-download").apply { isDaemon = true } }
  private val lock = Any()
  private val jobs = mutableMapOf<String, Job>()   // by sha256

  val directory: File get() = File(SparksPaths.root(app), "models").also { it.mkdirs() }

  fun file(sha256: String, kind: String) = File(directory, "${sha256.lowercase()}.${ext(kind)}")

  /** A verified file with this hash, or null. */
  fun verifiedPath(sha256: String, kind: String): File? {
    val f = file(sha256, kind)
    val receipt = File(f.path + ".receipt")
    if (!f.exists() || !receipt.exists()) return null
    return try {
      val o = JSONObject(receipt.readText())
      if (o.optString("sha256") == sha256.lowercase() && o.optLong("bytes", -1) == f.length()) f else null
    } catch (_: Exception) {
      null
    }
  }

  /** Download (or resume) one file. Concurrent calls for the same hash share one transfer. */
  fun download(
    url: String, sha256: String, bytes: Long, kind: String, allowCellular: Boolean, authToken: String?,
    progress: Progress, completion: Completion,
  ) {
    val sha = sha256.lowercase()
    verifiedPath(sha, kind)?.let { completion.success(it.path); return }

    val final = file(sha, kind)
    val part = File(final.path + ".part")
    val job: Job
    synchronized(lock) {
      jobs[sha]?.let { it.completions.add(completion); return }
      val partBytes = if (part.exists()) part.length() else 0L
      val free = SparksDevice.get(app).freeDiskBytes
      if (free < bytes - partBytes + HEADROOM_BYTES) {
        completion.failure("E_INSUFFICIENT_STORAGE", "need ${bytes - partBytes + HEADROOM_BYTES} bytes free")
        return
      }
      job = Job(sha, bytes, part, final, progress)
      job.completions.add(completion)
      jobs[sha] = job
    }
    pool.execute { run(job, url, allowCellular, authToken) }
  }

  /** Stop every transfer; `.part` files stay for the next resume. */
  fun cancelAll() {
    val all = synchronized(lock) { jobs.values.toList() }
    for (j in all) {
      j.cancelled = true
      try { j.connection?.disconnect() } catch (_: Exception) {}
    }
  }

  /**
   * Delete model files (and their receipts and partial downloads) whose hash
   * is not in `keep`. With an empty `keep` this is "delete everything" and
   * also stops transfers. Files of a transfer in flight are left alone.
   */
  fun deleteAll(keep: Set<String>) {
    if (keep.isEmpty()) cancelAll()
    val busy = synchronized(lock) { jobs.keys.toSet() }
    for (f in directory.listFiles() ?: emptyArray()) {
      val sha = f.name.substringBefore('.')
      if (keep.contains(sha) || (keep.isNotEmpty() && busy.contains(sha))) continue
      f.delete()
    }
  }

  private fun finish(job: Job, path: String?, code: String?, message: String?) {
    val cs = synchronized(lock) {
      jobs.remove(job.sha256)
      job.completions.toList()
    }
    for (c in cs) if (path != null) c.success(path) else c.failure(code ?: "E_MODEL_DOWNLOAD_FAILED", message ?: "download failed")
  }

  /** A network a download may use: any when cellular is allowed, else a non-cellular one. */
  private fun network(allowCellular: Boolean): Network? {
    val cm = app.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
    val active = cm.activeNetwork
    if (allowCellular) return active
    @Suppress("DEPRECATION")
    val candidates = listOfNotNull(active) + cm.allNetworks.filter { it != active }
    return candidates.firstOrNull { n ->
      val caps = cm.getNetworkCapabilities(n) ?: return@firstOrNull false
      caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) &&
        !caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR)
    }
  }

  private fun run(job: Job, url: String, allowCellular: Boolean, authToken: String?) {
    val md = MessageDigest.getInstance("SHA-256")
    var received = 0L
    try {
      // Resume: hash what is already on disk so the digest covers the whole file.
      if (job.part.exists() && job.part.length() in 1..job.expectedBytes) {
        job.part.inputStream().use { input ->
          val buf = ByteArray(4 shl 20)
          while (true) {
            val n = input.read(buf)
            if (n < 0) break
            md.update(buf, 0, n)
            received += n
          }
        }
      } else {
        job.part.delete()
      }

      val net = network(allowCellular)
      if (net == null) {
        job.progress.report("paused", received, job.expectedBytes)
        finish(job, null, "E_MODEL_DOWNLOAD_FAILED",
          if (allowCellular) "no network connection" else "no Wi-Fi connection (cellular download not allowed)")
        return
      }
      job.progress.report("downloading", received, job.expectedBytes)

      val conn = net.openConnection(URL(url)) as HttpURLConnection
      job.connection = conn
      conn.connectTimeout = 60_000
      conn.readTimeout = 60_000
      conn.instanceFollowRedirects = true
      if (!authToken.isNullOrEmpty()) conn.setRequestProperty("Authorization", "Bearer $authToken")
      if (received > 0) conn.setRequestProperty("Range", "bytes=$received-")
      if (job.cancelled) throw IOException("cancelled")

      val status = conn.responseCode
      var append = true
      when {
        status == 206 -> {}
        status == 200 -> {
          // The server ignored Range (or this is a fresh start): start over.
          if (received > 0) { md.reset(); received = 0 }
          append = false
        }
        status == 416 && received == job.expectedBytes -> {
          conn.disconnect()   // already complete on disk; verify below
          return verify(job, md, received)
        }
        else -> {
          conn.disconnect()
          job.progress.report("error", received, job.expectedBytes)
          finish(job, null, "E_MODEL_DOWNLOAD_FAILED", "HTTP $status")
          return
        }
      }

      var lastReport = 0L
      conn.inputStream.use { input ->
        FileOutputStream(job.part, append).use { out ->
          val buf = ByteArray(256 shl 10)
          while (true) {
            if (job.cancelled) throw IOException("cancelled")
            val n = input.read(buf)
            if (n < 0) break
            try {
              out.write(buf, 0, n)
            } catch (e: IOException) {
              job.progress.report("error", received, job.expectedBytes)
              finish(job, null, "E_INSUFFICIENT_STORAGE", "write failed: ${e.message}")
              return
            }
            md.update(buf, 0, n)
            received += n
            val now = System.currentTimeMillis()
            if (now - lastReport > 250) {
              lastReport = now
              job.progress.report("downloading", received, job.expectedBytes)
            }
          }
          out.fd.sync()
        }
      }
      conn.disconnect()
      verify(job, md, received)
    } catch (e: Exception) {
      if (job.cancelled && received < job.expectedBytes) {
        job.progress.report("paused", received, job.expectedBytes)
        finish(job, null, "E_CANCELLED", "download cancelled; it resumes on the next ensure()")
      } else {
        job.progress.report("error", received, job.expectedBytes)
        finish(job, null, "E_MODEL_DOWNLOAD_FAILED", e.message ?: e.javaClass.simpleName)
      }
    }
  }

  private fun verify(job: Job, md: MessageDigest, received: Long) {
    job.progress.report("verifying", received, job.expectedBytes)
    val digest = md.digest().joinToString("") { "%02x".format(it.toInt() and 0xff) }
    if (digest != job.sha256 || received != job.expectedBytes) {
      job.part.delete()
      job.progress.report("error", received, job.expectedBytes)
      finish(job, null, "E_MODEL_CHECKSUM_MISMATCH",
        "got $digest ($received bytes), want ${job.sha256} (${job.expectedBytes} bytes)")
      return
    }
    try {
      if (job.final.exists()) job.final.delete()
      if (!job.part.renameTo(job.final)) throw IOException("rename failed")
      val fmt = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.US).apply { timeZone = TimeZone.getTimeZone("UTC") }
      val receipt = JSONObject().put("sha256", job.sha256).put("bytes", received).put("verifiedAt", fmt.format(Date()))
      SparksKeystore.writeAtomic(File(job.final.path + ".receipt"), receipt.toString().toByteArray(Charsets.UTF_8))
      job.progress.report("done", received, job.expectedBytes)
      finish(job, job.final.path, null, null)
    } catch (e: Exception) {
      job.progress.report("error", received, job.expectedBytes)
      finish(job, null, "E_INSUFFICIENT_STORAGE", "could not store the model: ${e.message}")
    }
  }
}
