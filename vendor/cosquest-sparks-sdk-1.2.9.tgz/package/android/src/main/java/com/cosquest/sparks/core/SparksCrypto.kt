package com.cosquest.sparks.core

import org.bouncycastle.crypto.AsymmetricCipherKeyPair
import org.bouncycastle.crypto.hpke.HPKE
import org.bouncycastle.crypto.params.X25519PrivateKeyParameters
import java.security.MessageDigest
import java.security.SecureRandom
import java.util.Base64

/**
 * The inbound "data handshake" (DATA_CONTRACT §7), pure JVM so the unit tests
 * run without a device. Keys at rest are SparksKeystore's job.
 *
 * HPKE base mode, DHKEM(X25519, HKDF-SHA256) / HKDF-SHA256 / AES-256-GCM,
 * single shot, through BouncyCastle's lightweight `org.bouncycastle.crypto.hpke.HPKE`
 * (no JCA provider is registered). Opens the same @hpke/core vectors as
 * ios/Tests/SparksCryptoTests.swift.
 *
 * Why not Tink: Tink's public HPKE (HybridDecrypt) binds a single
 * `contextInfo`, used as the HPKE info, and always opens with empty AAD. The
 * contract binds both an info ("cosquest-sparks/v1/<kind>") and an aad
 * ("<id>|<deviceId>"), which only Tink's internal (unstable) classes expose.
 * Why not the platform: X25519 key agreement is not in Android's providers
 * at minSdk 26.
 */
object SparksCrypto {
  class OpenFailed(message: String) : Exception(message)

  private fun hpke() = HPKE(HPKE.mode_base, HPKE.kem_X25519_SHA256, HPKE.kdf_HKDF_SHA256, HPKE.aead_AES_GCM256)

  /** A new random X25519 private key (32 bytes, RFC 7748 encoding). */
  fun newPrivateKey(random: SecureRandom = SecureRandom()): ByteArray =
    X25519PrivateKeyParameters(random).encoded

  /** The X25519 public key (32 bytes) of a private key. */
  fun publicKey(privateKey: ByteArray): ByteArray {
    require(privateKey.size == 32) { "X25519 private key must be 32 bytes" }
    return X25519PrivateKeyParameters(privateKey, 0).generatePublicKey().encoded
  }

  private fun keyPair(h: HPKE, sk: ByteArray): AsymmetricCipherKeyPair = h.deserializePrivateKey(sk, publicKey(sk))

  /**
   * Open a sealed payload. `info` and `aad` per DATA_CONTRACT §7:
   * info = "cosquest-sparks/v1/" + ("job.offer" | "context.bundle"),
   * aad = envelope id ("jobId" or "bundleId") + "|" + deviceId.
   * @throws OpenFailed for a bad encoding, the wrong key, info or aad, or a tampered ciphertext.
   */
  fun open(enc: ByteArray, ct: ByteArray, info: ByteArray, aad: ByteArray, recipient: ByteArray): ByteArray {
    if (enc.size != 32 || ct.size < 16) throw OpenFailed("bad encoding")
    val h = hpke()
    return try {
      h.open(enc, keyPair(h, recipient), info, aad, ct, null, null, null)
    } catch (e: Exception) {
      throw OpenFailed("open failed")
    }
  }

  /**
   * Seal to a recipient (what the backend does with @hpke/core). The SDK
   * itself never seals: outbound results are plain JSON (DATA_CONTRACT §7).
   * For the tests. `ephemeral` (a private key) is for deterministic vectors only.
   * Returns (enc, ct) where ct carries the 16-byte tag at its end.
   */
  fun seal(
    plaintext: ByteArray, info: ByteArray, aad: ByteArray, recipientPublic: ByteArray, ephemeral: ByteArray? = null,
  ): Pair<ByteArray, ByteArray> {
    val h = hpke()
    val pkR = h.deserializePublicKey(recipientPublic)
    val ctx = if (ephemeral != null) h.setupBaseS(pkR, info, keyPair(h, ephemeral)) else h.setupBaseS(pkR, info)
    return Pair(ctx.encapsulation, ctx.seal(aad, plaintext))
  }

  /** The info string for a sealed payload kind ("job.offer" | "context.bundle"). */
  fun info(kind: String): ByteArray = "cosquest-sparks/v1/$kind".toByteArray(Charsets.UTF_8)

  /** The aad for an envelope id (jobId or bundleId) and this device. */
  fun aad(id: String, deviceId: String): ByteArray = "$id|$deviceId".toByteArray(Charsets.UTF_8)

  // base64url, unpadded (DATA_CONTRACT §7). java.util.Base64 is API 26+.

  fun b64url(d: ByteArray): String = Base64.getUrlEncoder().withoutPadding().encodeToString(d)

  /** null when the text is not base64 (url or standard alphabet, padded or not), as on iOS. */
  fun fromB64url(s: String): ByteArray? =
    try {
      Base64.getUrlDecoder().decode(s.replace('+', '-').replace('/', '_').trimEnd('='))
    } catch (e: IllegalArgumentException) {
      null
    }

  /** Same naming as SparksSecureStore.safeName on iOS: hex of the first 12 bytes of SHA-256. */
  fun safeName(s: String): String =
    MessageDigest.getInstance("SHA-256").digest(s.toByteArray(Charsets.UTF_8))
      .take(12).joinToString("") { "%02x".format(it.toInt() and 0xff) }
}
