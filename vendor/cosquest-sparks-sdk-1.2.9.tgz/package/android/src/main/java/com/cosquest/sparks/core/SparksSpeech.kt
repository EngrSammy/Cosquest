package com.cosquest.sparks.core

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.Locale
import java.util.concurrent.atomic.AtomicLong

/**
 * On-device TTS for the Warden (WardenApi.speak): android.speech.tts.TextToSpeech
 * with the phone's installed engine, so nothing leaves the phone as long as
 * that engine is on-device (Google's is, for en-US voices it has downloaded;
 * we request a non-network voice). The counterpart of SparksSpeech.swift.
 *
 * Ducking: transient audio focus with "may duck", requested only when no call
 * owns the audio (AudioManager mode is not IN_CALL / IN_COMMUNICATION), and
 * abandoned once nothing is left to say.
 */
class SparksSpeech private constructor(private val app: Context) {
  companion object {
    @Volatile private var instance: SparksSpeech? = null

    fun get(context: Context): SparksSpeech =
      instance ?: synchronized(this) { instance ?: SparksSpeech(context.applicationContext).also { instance = it } }
  }

  private val main = Handler(Looper.getMainLooper())
  private var tts: TextToSpeech? = null
  private var ready = false
  private var failed = false
  private val waiting = mutableListOf<() -> Unit>()
  private val pending = mutableMapOf<String, (Boolean) -> Unit>()
  private val ids = AtomicLong()
  private var focus: AudioFocusRequest? = null
  private val attributes = AudioAttributes.Builder()
    .setUsage(AudioAttributes.USAGE_ASSISTANT)
    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
    .build()

  private val audio get() = app.getSystemService(Context.AUDIO_SERVICE) as AudioManager

  /** Runs `then` on the main thread once the engine is up (or failed to start). */
  private fun withEngine(then: () -> Unit) {
    if (ready || failed) { then(); return }
    waiting.add(then)
    if (tts != null) return
    tts = TextToSpeech(app) { status ->
      main.post {
        if (status == TextToSpeech.SUCCESS) {
          ready = true
          tts?.let { t ->
            t.setAudioAttributes(attributes)
            if (t.isLanguageAvailable(Locale.US) >= TextToSpeech.LANG_AVAILABLE) t.setLanguage(Locale.US)
            t.voices?.filter { it.locale == Locale.US && !it.isNetworkConnectionRequired }
              ?.minByOrNull { it.latency }
              ?.let { t.setVoice(it) }
            t.setOnUtteranceProgressListener(listener)
          }
        } else {
          failed = true
        }
        val run = waiting.toList()
        waiting.clear()
        run.forEach { it() }
      }
    }
  }

  private val listener = object : UtteranceProgressListener() {
    override fun onStart(utteranceId: String) {}
    override fun onDone(utteranceId: String) {
      main.post { finish(utteranceId, true) }
    }

    @Deprecated("Deprecated in Java")
    override fun onError(utteranceId: String) {
      main.post { finish(utteranceId, false) }
    }

    override fun onError(utteranceId: String, errorCode: Int) {
      main.post { finish(utteranceId, false) }
    }

    override fun onStop(utteranceId: String, interrupted: Boolean) {
      main.post { finish(utteranceId, false) }
    }
  }

  /** rate and pitch: 0.5 to 2.0, 1.0 = default. completion(false) when stopped or failed. */
  fun speak(text: String, rate: Double, pitch: Double, duckOthers: Boolean, completion: (Boolean) -> Unit) {
    main.post {
      withEngine {
        val t = tts
        if (!ready || t == null) { completion(false); return@withEngine }
        t.setSpeechRate(rate.coerceIn(0.5, 2.0).toFloat())
        t.setPitch(pitch.coerceIn(0.5, 2.0).toFloat())
        if (duckOthers) duck(true)
        val id = "sparks-" + ids.incrementAndGet()
        pending[id] = completion
        // QUEUE_ADD: lines play in order, as AVSpeechSynthesizer queues them.
        if (t.speak(text, TextToSpeech.QUEUE_ADD, Bundle(), id) != TextToSpeech.SUCCESS) finish(id, false)
      }
    }
  }

  fun stop() {
    main.post {
      tts?.stop()
      // stop() does not always report onStop for queued utterances: settle them here.
      for (id in pending.keys.toList()) finish(id, false)
    }
  }

  private fun finish(id: String, ok: Boolean) {
    val c = pending.remove(id) ?: return
    if (pending.isEmpty()) duck(false)
    c(ok)
  }

  private fun duck(on: Boolean) {
    val am = audio
    if (on) {
      if (focus != null) return
      val mode = am.mode
      if (mode == AudioManager.MODE_IN_CALL || mode == AudioManager.MODE_IN_COMMUNICATION) return   // a call owns the audio
      val req = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK)
        .setAudioAttributes(attributes)
        .build()
      if (am.requestAudioFocus(req) == AudioManager.AUDIOFOCUS_REQUEST_GRANTED) focus = req
    } else {
      focus?.let { am.abandonAudioFocusRequest(it) }
      focus = null
    }
  }
}
