package com.cosquest.sparks.core

import android.app.ActivityManager
import android.content.BroadcastReceiver
import android.content.ComponentCallbacks2
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ApplicationInfo
import android.content.res.Configuration
import android.os.BatteryManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.os.StatFs
import android.os.storage.StorageManager
import com.cosquest.sparks.SparksNative

/**
 * What this phone is and what state it is in: tier inputs, and the gates
 * background work needs (ARCHITECTURE §2.2). The Android counterpart of
 * ios/SparksCore/SparksDevice.swift.
 *
 *  - RAM: ActivityManager.MemoryInfo.totalMem (below the marketed size, like
 *    iOS's physicalMemory; the 0.85 tolerance covers it).
 *  - Available memory: Android has no os_proc_available_memory(). We use
 *    MemoryInfo.availMem - MemoryInfo.threshold: what the system can still
 *    hand out before the low-memory killer starts on cached processes.
 *  - Battery: the sticky ACTION_BATTERY_CHANGED intent.
 *  - Low power: PowerManager.isPowerSaveMode.
 *  - Thermal: PowerManager.currentThermalStatus (API 29+; "nominal" below).
 *  - Memory warnings: onTrimMemory at RUNNING_MODERATE/LOW/CRITICAL, MODERATE
 *    or COMPLETE, and onLowMemory. UI_HIDDEN and BACKGROUND are not warnings.
 *  - Foreground: set by the module from React Native's host lifecycle.
 */
class SparksDevice private constructor(private val app: Context) {
  companion object {
    @Volatile private var instance: SparksDevice? = null

    fun get(context: Context): SparksDevice =
      instance ?: synchronized(this) { instance ?: SparksDevice(context.applicationContext).also { instance = it } }
  }

  data class Gates(
    val foreground: Boolean,
    /** 0 to 1, or -1 when unknown. */
    val batteryLevel: Double,
    val charging: Boolean,
    val lowPowerMode: Boolean,
    /** nominal | fair | serious | critical */
    val thermal: String,
    /** System.currentTimeMillis() of the last memory warning, or 0. */
    val lastMemoryWarningAt: Long,
  )

  /** (gates, isMemoryWarning). Called on the main thread. */
  @Volatile var onChange: ((Gates, Boolean) -> Unit)? = null

  private val lock = Any()
  private var gates = Gates(true, -1.0, false, false, "nominal", 0)
  private var observing = false
  private val main = Handler(Looper.getMainLooper())

  private val activityManager get() = app.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
  private val powerManager get() = app.getSystemService(Context.POWER_SERVICE) as PowerManager

  fun currentGates(): Gates = synchronized(lock) { gates }

  val ramBytes: Long
    get() = ActivityManager.MemoryInfo().also { activityManager.getMemoryInfo(it) }.totalMem

  /** Bytes the process may still allocate before memory pressure kills apps; -1 if unknown. */
  val availableMemoryBytes: Long
    get() {
      val mi = ActivityManager.MemoryInfo().also { activityManager.getMemoryInfo(it) }
      if (mi.availMem <= 0) return -1
      return maxOf(0L, mi.availMem - mi.threshold)
    }

  val osVersion: String get() = Build.VERSION.RELEASE ?: Build.VERSION.SDK_INT.toString()
  val apiLevel: Int get() = Build.VERSION.SDK_INT
  val deviceModel: String
    get() {
      val m = Build.MODEL ?: "unknown"
      val maker = Build.MANUFACTURER ?: ""
      return if (maker.isEmpty() || m.startsWith(maker, ignoreCase = true)) m else "$maker $m"
    }

  /** The ABI the native library was built for ("" when it did not load). */
  val nativeAbi: String get() = if (SparksNative.loaded) SparksNative.abi() else ""

  /** ARMv8.2 dot product (SDOT), from the kernel's hwcaps. */
  val armDotProd: Boolean get() = SparksNative.loaded && SparksNative.armDotProd()

  /** Bytes a model download may use: allocatable space (free + clearable cache). */
  val freeDiskBytes: Long
    get() = try {
      val sm = app.getSystemService(Context.STORAGE_SERVICE) as StorageManager
      sm.getAllocatableBytes(StorageManager.UUID_DEFAULT)
    } catch (_: Exception) {
      StatFs(app.noBackupFilesDir.path).availableBytes
    }

  val appVersion: String
    get() = try {
      app.packageManager.getPackageInfo(app.packageName, 0).versionName ?: "0"
    } catch (_: Exception) {
      "0"
    }

  /** The host app is debuggable (the analogue of an iOS DEBUG build). */
  val debugBuild: Boolean get() = (app.applicationInfo.flags and ApplicationInfo.FLAG_DEBUGGABLE) != 0

  fun tier(forced: SparksTier?, allowForce: Boolean): SparksTierDecision =
    SparksTierPolicy.decide(
      ramBytes = ramBytes,
      armDotProd = armDotProd,
      platform = "android",
      osMajor = apiLevel,
      is64Bit = nativeAbi == SparksTierPolicy.MODEL_ABI,
      forced = forced,
      allowForce = allowForce,
    )

  /** Milliseconds since the last memory warning, or -1. */
  fun memoryWarningAgeMs(): Double {
    val at = currentGates().lastMemoryWarningAt
    return if (at == 0L) -1.0 else (System.currentTimeMillis() - at).toDouble()
  }

  /** Memory budget for opening engine handle 0 (warden) or 1 (sparks). */
  fun memoryOK(tier: String, handle: Int): Boolean =
    SparksTierPolicy.memoryOK(tier, handle, availableMemoryBytes, memoryWarningAgeMs())

  fun setForeground(fg: Boolean) {
    update { it.copy(foreground = fg) }
  }

  fun startObserving() {
    synchronized(lock) {
      if (observing) return
      observing = true
    }
    main.post {
      val filter = IntentFilter().apply {
        addAction(Intent.ACTION_BATTERY_CHANGED)
        addAction(Intent.ACTION_POWER_CONNECTED)
        addAction(Intent.ACTION_POWER_DISCONNECTED)
        addAction(PowerManager.ACTION_POWER_SAVE_MODE_CHANGED)
      }
      val receiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) = refresh(if (i.action == Intent.ACTION_BATTERY_CHANGED) i else null)
      }
      // System broadcasts only; exported flag required from API 33 for dynamic receivers.
      if (Build.VERSION.SDK_INT >= 33) {
        app.registerReceiver(receiver, filter, Context.RECEIVER_NOT_EXPORTED)
      } else {
        app.registerReceiver(receiver, filter)
      }
      if (Build.VERSION.SDK_INT >= 29) {
        powerManager.addThermalStatusListener(app.mainExecutor) { refresh(null) }
      }
      app.registerComponentCallbacks(object : ComponentCallbacks2 {
        @Suppress("DEPRECATION")
        override fun onTrimMemory(level: Int) {
          val warning = when (level) {
            ComponentCallbacks2.TRIM_MEMORY_RUNNING_MODERATE,
            ComponentCallbacks2.TRIM_MEMORY_RUNNING_LOW,
            ComponentCallbacks2.TRIM_MEMORY_RUNNING_CRITICAL,
            ComponentCallbacks2.TRIM_MEMORY_MODERATE,
            ComponentCallbacks2.TRIM_MEMORY_COMPLETE -> true
            else -> false
          }
          if (warning) memoryWarning()
        }

        override fun onLowMemory() = memoryWarning()
        override fun onConfigurationChanged(newConfig: Configuration) {}
      })
      refresh(null)
    }
  }

  private fun memoryWarning() {
    val g = update(notify = false) { it.copy(lastMemoryWarningAt = System.currentTimeMillis()) }
    onChange?.invoke(g, true)
  }

  /** Re-read battery, power save and thermal state. */
  fun refresh(batteryIntent: Intent?) {
    val battery = batteryIntent ?: try {
      app.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
    } catch (_: Exception) {
      null
    }
    var level = -1.0
    var charging = false
    if (battery != null) {
      val l = battery.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
      val scale = battery.getIntExtra(BatteryManager.EXTRA_SCALE, -1)
      if (l >= 0 && scale > 0) level = l.toDouble() / scale
      val status = battery.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
      charging = status == BatteryManager.BATTERY_STATUS_CHARGING || status == BatteryManager.BATTERY_STATUS_FULL
    }
    val thermal = if (Build.VERSION.SDK_INT >= 29) thermalName(powerManager.currentThermalStatus) else "nominal"
    val lowPower = powerManager.isPowerSaveMode
    update { it.copy(batteryLevel = level, charging = charging, lowPowerMode = lowPower, thermal = thermal) }
  }

  private fun update(notify: Boolean = true, change: (Gates) -> Gates): Gates {
    val before: Gates
    val after: Gates
    synchronized(lock) {
      before = gates
      gates = change(gates)
      after = gates
    }
    if (notify && before != after) onChange?.invoke(after, false)
    return after
  }

  private fun thermalName(status: Int): String = when (status) {
    PowerManager.THERMAL_STATUS_NONE, PowerManager.THERMAL_STATUS_LIGHT -> "nominal"
    PowerManager.THERMAL_STATUS_MODERATE -> "fair"
    PowerManager.THERMAL_STATUS_SEVERE -> "serious"
    else -> "critical"   // CRITICAL, EMERGENCY, SHUTDOWN
  }
}
