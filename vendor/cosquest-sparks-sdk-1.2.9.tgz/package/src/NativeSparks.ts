/**
 * Codegen spec for the Sparks TurboModule (React Native New Architecture).
 *
 * These are the native PRIMITIVES the JS layer (src/impl) builds the public
 * API from: the engine (load, generate under a grammar, embed, cancel,
 * pause), the C text utilities, Moonshine transcription, the device key and
 * HPKE open, the encrypted store, model file download/verify, TTS, and device
 * gates. Protocol, prompts, scheduling policy and validation live in JS.
 *
 * iOS: ios/RN/SparksModule.mm conforms to the generated NativeSparksSpec.
 * Codegen reads this file (package.json codegenConfig.jsSrcsDir = "src").
 * Keep it codegen-friendly: object type aliases, string instead of literal
 * unions, number for all numerics.
 */
import type { TurboModule, CodegenTypes } from 'react-native';
import { TurboModuleRegistry } from 'react-native';

export type NativeDeviceInfo = {
  platform: string;
  osVersion: string;
  deviceModel: string;
  /** ProcessInfo.physicalMemory. */
  ramBytes: number;
  /** os_proc_available_memory(); -1 when the OS enforces no limit (simulator). */
  availableMemoryBytes: number;
  armDotProd: boolean;
  /**
   * The speech runtime is linked (built with SPARKS_WITH_MOONSHINE) and
   * asrSetModel has been given verified files. False at start until JS has
   * restored or downloaded them.
   */
  transcription: boolean;
  freeDiskBytes: number;
  appVersion: string;
  /** Release builds ignore SparksConfig.forceTier. */
  debugBuild: boolean;
  /** full | lite | none, from RAM, CPU and OS (SparksTierPolicy.swift). The manifest can lower it. */
  tier: string;
  /** '' | ram | cpu | os | forced */
  tierReason: string;
};

export type NativeGates = {
  foreground: boolean;
  /** 0 to 1, or -1 when unknown (simulator). */
  batteryLevel: number;
  charging: boolean;
  lowPowerMode: boolean;
  /** nominal | fair | serious | critical */
  thermal: string;
  /** Milliseconds since the last OS memory warning, -1 if none. */
  memoryWarningAgeMs: number;
};

export type NativeDeviceKey = {
  /** base64url X25519 public key (32 bytes). */
  publicKey: string;
  kid: string;
};

export type NativeDownloadRequest = {
  url: string;
  /** Lowercase hex sha256 the file must hash to. */
  sha256: string;
  bytes: number;
  /** 'model' | 'tokenizer' | 'asr' (decides the on-disk name). */
  kind: string;
  allowCellular: boolean;
  /** Bearer token for the request, empty for none. */
  authToken: string;
};

export type NativeModelInfo = {
  dim: number;
  nLayers: number;
  vocabSize: number;
  seqLen: number;
  qbits: number;
  /** SDK 1.2.7 native: the int8 kernel (0 plain C, 1 SIMD, 2 ARM dot product). */
  kernel?: number;
  /** SDK 1.2.7 native: matmul threads (Android pool; 0 on iOS, where GCD sizes each call). */
  threads?: number;
  /** SDK 1.2.7 native: major * 10000 + minor * 100 + patch of the native code the app was built with. */
  nativeBuild?: number;
};

export type NativeGenerateRequest = {
  /** JS-chosen id (> 0) used by cancel() and onToken. */
  requestId: number;
  /** 0 warden, 1 interactive, 2 background. */
  priority: number;
  prompt: string;
  /** Flat JSON schema for mote_grammar; empty = unconstrained. */
  schema: string;
  /** Stop string; empty = none. */
  stop: string;
  temperature: number;
  topP: number;
  repeatPenalty: number;
  maxTokens: number;
  /** 0 = leave the engine's seed. */
  seed: number;
  /** Emit onToken for each piece. */
  stream: boolean;
};

export type NativeGenerateResult = {
  text: string;
  tokensOut: number;
  tokensInEstimate: number;
  firstTokenMs: number;
  wallMs: number;
  runMs: number;
  preemptions: number;
};

export type NativeEngineState = {
  /** -1 idle, else the running priority. */
  running: number;
  queuedWarden: number;
  queuedInteractive: number;
  queuedBackground: number;
  pausedMask: number;
  wardenLoaded: boolean;
  sparksLoaded: boolean;
  modelAttached: boolean;
};

export type NativeTokenEvent = { requestId: number; piece: string };

export type NativeAsrLineEvent = {
  callId: string;
  /** Moonshine line id (uint64) as a decimal string. */
  lineId: string;
  text: string;
  /** Speech start, seconds since asrStart on the capture clock. */
  startS: number;
  /** To the end of speech (final) or of the audio so far (partial). */
  durationS: number;
  final: boolean;
  /** 0..1 from the decoder (geometric mean of its token probabilities); absent or <0 = unknown (native before 10209). */
  confidence?: number;
};

/** Verified Moonshine Base + Silero files (manifest `asr`), as downloaded paths. */
export type NativeAsrModel = {
  encoder: string;
  decoder: string;
  tokenizer: string;
  vad: string;
};

export type NativeDownloadEvent = {
  sha256: string;
  /** downloading | paused | verifying | done | error */
  phase: string;
  bytesDownloaded: number;
  bytesTotal: number;
  error: string;
};

export type NativeGatesEvent = {
  gates: NativeGates;
  /** True when this event is an OS memory warning. */
  memoryWarning: boolean;
};

export interface Spec extends TurboModule {
  // device
  /** forceTier: '' or a DeviceTier; honoured in debug builds only. */
  getDeviceInfo(forceTier: string): Promise<NativeDeviceInfo>;
  getGates(): Promise<NativeGates>;
  startObserving(): void;

  // device key and HPKE open (DATA_CONTRACT §7)
  deviceKey(scope: string): Promise<NativeDeviceKey>;
  deleteDeviceKey(scope: string): Promise<void>;
  /** Resolves the UTF-8 plaintext; rejects E_DECRYPT_FAILED. */
  openSealed(scope: string, enc: string, ct: string, info: string, aad: string): Promise<string>;

  // encrypted local store (PRIVACY §3)
  storeGet(scope: string, name: string): Promise<string | null>;
  storeSet(scope: string, name: string, value: string | null): Promise<void>;
  storeWipe(scope: string): Promise<void>;

  // model files
  /** Path of a verified file with this sha256, or null. */
  modelFilePath(sha256: string, kind: string): Promise<string | null>;
  /** Resumable download with streaming sha256; resolves the verified path. */
  downloadFile(request: NativeDownloadRequest): Promise<string>;
  cancelDownloads(): void;
  /** Delete model files except the listed sha256s. */
  deleteModelFiles(keepSha256s: string[]): Promise<void>;

  // engine (mote under the C scheduler, sparks_engine.c)
  loadModel(modelPath: string, tokenizerPath: string, tier: string, preloadSparks: boolean): Promise<NativeModelInfo>;
  /** 0 warden handle, 1 sparks handle, -1 everything (detaches the model). */
  unloadModel(handle: number): Promise<void>;
  generate(request: NativeGenerateRequest): Promise<NativeGenerateResult>;
  embed(requestId: number, priority: number, text: string): Promise<number[]>;
  cancel(requestId: number): void;
  setPaused(mask: number): void;
  getEngineState(): Promise<NativeEngineState>;

  // C text utilities (synchronous, cheap)
  /** Repaired JSON object, or '' when the text holds none. */
  jsonRepair(raw: string): string;
  wardenClean(raw: string): string;
  /** '' when the line may be said, else why not. */
  wardenCheck(text: string, moment: string, input: string, place: string, maxWords: number): string;

  // transcription (Moonshine Base + Silero VAD over ONNX Runtime, cpp/sparks/sparks_asr.c)
  /**
   * Point the transcriber at verified files (empty strings clear them).
   * Resolves true when this build links the runtime and the files exist;
   * the models load on asrStart, not here.
   */
  asrSetModel(model: NativeAsrModel): Promise<boolean>;
  /** Loads the models (about 0.3 s on a Mac); rejects E_TRANSCRIPTION_UNAVAILABLE. */
  asrStart(callId: string, partials: boolean): Promise<void>;
  /**
   * Words the next and the running transcription should lean towards (names on the call,
   * CosQuest's words). Kept across calls until replaced; [] clears. Resolves to the number
   * kept. Native build 10209+; older builds lack it (the JS checks before calling).
   */
  asrSetVocabulary(phrases: string[]): Promise<number>;
  /** Testing path: 16 kHz mono PCM16LE, base64; startMs = capture time of the first sample, ms since asrStart. */
  asrPush(callId: string, pcm16Base64: string, startMs: number): void;
  asrSetMuted(callId: string, muted: boolean): void;
  /** Delivers the open utterance as final, then releases the models. */
  asrStop(callId: string): Promise<void>;

  // TTS
  speak(text: string, rate: number, pitch: number, duckOthers: boolean): Promise<void>;
  stopSpeaking(): void;

  readonly onToken: CodegenTypes.EventEmitter<NativeTokenEvent>;
  readonly onAsrLine: CodegenTypes.EventEmitter<NativeAsrLineEvent>;
  readonly onDownload: CodegenTypes.EventEmitter<NativeDownloadEvent>;
  readonly onGates: CodegenTypes.EventEmitter<NativeGatesEvent>;
  readonly onEngineState: CodegenTypes.EventEmitter<NativeEngineState>;
}

/** Null when the native module is not linked (Expo Go, web, a stale build). */
export default TurboModuleRegistry.get<Spec>('Sparks');
