/**
 * How fast this phone runs the model, measured from its own generations, so a
 * job can tell whether another model step still fits before its deadline.
 *
 * Two rates, each a moving average: prompt reading (ms per prompt token, from
 * the time to the first token) and writing (ms per generated token after the
 * first). A budget phone can read 10 to 50 times slower than an iPhone, so a
 * fixed timetable fails one or the other; a measured one fits both.
 *
 * The prompt rate is on the optimistic side: mote reuses the KV cache for a
 * prompt prefix it has already read (the system prompt), so the first token
 * comes sooner than a cold read of every token would. Callers add slack
 * (fits() uses 1.5x).
 *
 * Pure: no native, no clock of its own.
 */

/** Characters per token for the estimate (the engine's tokensInEstimate uses the same 3.6). */
export const CHARS_PER_TOKEN = 3.6;
/** Weight of a new sample in the moving averages. */
const ALPHA = 0.35;
/** Generations with fewer prompt tokens than this say little about reading speed. */
const MIN_PROMPT_TOKENS = 24;
/** Margin fits() keeps over the estimate. */
export const FIT_SLACK = 1.5;
/** Fixed cost per generation fits() adds (bridge round trips, JSON parse, scheduling). */
export const FIT_FIXED_MS = 1500;

export interface GenTiming {
  tokensInEstimate: number;
  tokensOut: number;
  /** ms from the start of the run to the first token, < 0 when none came. */
  firstTokenMs: number;
  runMs: number;
  preemptions?: number;
}

export interface PaceSnapshot {
  /** Prompt reading, ms per token. */
  readMsPerToken: number;
  /** Writing, ms per generated token. */
  writeMsPerToken: number;
  samples: number;
}

export class Pace {
  private read: number | null = null;
  private write: number | null = null;
  private n = 0;

  /** Forget every sample (a different model was loaded). */
  reset(): void { this.read = null; this.write = null; this.n = 0; }

  /** Learn from one finished generation. Preempted runs (paused for a Warden line) are skipped: their timing is not the model's. */
  record(r: GenTiming): void {
    if ((r.preemptions ?? 0) > 0 || !(r.firstTokenMs >= 0) || !(r.runMs > 0)) return;
    if (r.tokensInEstimate >= MIN_PROMPT_TOKENS) {
      const v = r.firstTokenMs / r.tokensInEstimate;
      this.read = this.read === null ? v : this.read + ALPHA * (v - this.read);
    }
    if (r.tokensOut > 1 && r.runMs > r.firstTokenMs) {
      const v = (r.runMs - r.firstTokenMs) / (r.tokensOut - 1);
      this.write = this.write === null ? v : this.write + ALPHA * (v - this.write);
    }
    this.n++;
  }

  /** Measured rates, or null before the first useful sample. */
  snapshot(): PaceSnapshot | null {
    if (this.read === null) return null;
    return { readMsPerToken: this.read, writeMsPerToken: this.write ?? this.read, samples: this.n };
  }

  /** Expected ms for a generation over `promptChars` that writes about `tokensOut` tokens; null when not measured yet. */
  estimateMs(promptChars: number, tokensOut: number): number | null {
    const s = this.snapshot();
    if (!s) return null;
    return (promptChars / CHARS_PER_TOKEN) * s.readMsPerToken + Math.max(0, tokensOut) * s.writeMsPerToken;
  }

  /**
   * Whether such a generation is expected to finish within `remainingMs`,
   * with FIT_SLACK and FIT_FIXED_MS of margin. Unmeasured: true (nothing to
   * go on; the job's own deadline still stops it).
   */
  fits(promptChars: number, tokensOut: number, remainingMs: number): boolean {
    const est = this.estimateMs(promptChars, tokensOut);
    if (est === null) return true;
    return est * FIT_SLACK + FIT_FIXED_MS <= remainingMs;
  }
}
