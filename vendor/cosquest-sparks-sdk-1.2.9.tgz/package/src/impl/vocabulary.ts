/**
 * The words a call is likely to contain, for the speech model to lean towards (vocabulary
 * biasing, cpp/sparks/sparks_vocab.c). An off-the-shelf English model has never heard
 * "CosQuest" ("Course Quests") or most Nigerian names ("Wemida" -> "Wimmy dog"); telling it
 * the people on the call and the game's own words fixes many of those.
 *
 * Measured offline (cpp/test/asr-eval/ACCENT.md): Nigerian English, names heard right
 * 26% -> 65% with the right names in a list of ~30, word error rate 13.4% -> 12.0%. Long
 * lists hurt (100+ phrases: no gain), so the list is kept short: the app's own words first,
 * then the people on the call (as they are heard, so a 1,000-member Community still gets
 * the names that matter), the members of a small chat, then CosQuest's terms.
 */

/** CosQuest's own words: product and feature names a general English model mishears. */
export const COSQUEST_TERMS: readonly string[] = ['CosQuest', 'Sparks', 'Orchestrator', 'Game Warden', 'Forge', 'Proctor'];

/** At most this many phrases go to the speech model. */
export const MAX_VOCABULARY = 48;

/** A chat with more members than this contributes no names by default (a big group's list would be too long to help). */
export const MAX_MEMBERS_FOR_NAMES = 24;

const SKIP = new Set(['the', 'and', 'mr', 'mrs', 'ms', 'dr', 'sir', 'pastor', 'bro', 'sis', 'admin', 'official', 'real', 'its', 'not']);

/** "Emmanuel_Wemida 🔥" -> "Emmanuel Wemida": letters, digits, apostrophes and hyphens; the rest are spaces. */
export function cleanPhrase(raw: string): string {
  return (raw ?? '')
    .normalize('NFC')
    .replace(/[_.]+/g, ' ')
    .replace(/[^\p{L}\p{N}' -]+/gu, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}

/** A display name as phrases: the whole name (up to 3 words) and each name in it of 3+ letters. */
export function namePhrases(displayName: string): string[] {
  const clean = cleanPhrase(displayName);
  if (!clean) return [];
  const words = clean.split(' ').filter((w) => w.replace(/[^\p{L}]/gu, '').length >= 3 && !SKIP.has(w.toLowerCase()));
  const out: string[] = [];
  const all = clean.split(' ');
  if (all.length >= 2 && all.length <= 3) out.push(clean);
  out.push(...words);
  return out;
}

export interface VocabularyInput {
  /** The app's own words for this call (group or faction names, places, game words): first in the list. */
  extra?: readonly string[];
  /** People heard on this call so far (and this user): their names go in even in a big group. */
  speakers?: readonly { displayName: string }[];
  /** The chat's members (display names); used only for chats up to MAX_MEMBERS_FOR_NAMES. */
  members?: readonly { displayName: string }[];
  /** CosQuest's words; default COSQUEST_TERMS. */
  base?: readonly string[];
  max?: number;
}

/** The phrase list for a call, deduplicated (case-insensitive), at most `max` (default MAX_VOCABULARY). */
export function callVocabulary(o: VocabularyInput): string[] {
  const max = o.max ?? MAX_VOCABULARY;
  const out: string[] = [];
  const seen = new Set<string>();
  const add = (p: string) => {
    const c = cleanPhrase(p);
    if (c.replace(/[^\p{L}\p{N}]/gu, '').length < 2 || c.length > 48) return;
    const k = c.toLowerCase();
    if (seen.has(k) || out.length >= max) return;
    seen.add(k);
    out.push(c);
  };
  for (const p of o.extra ?? []) add(p);
  for (const m of o.speakers ?? []) for (const p of namePhrases(m.displayName)) add(p);
  const members = o.members ?? [];
  if (members.length <= MAX_MEMBERS_FOR_NAMES) for (const m of members) for (const p of namePhrases(m.displayName)) add(p);
  for (const p of o.base ?? COSQUEST_TERMS) add(p);
  return out;
}
