/**
 * Small runtime helpers shared by the SDK implementation. Globals are reached
 * through `globalThis` with local types so this package typechecks with or
 * without React Native's (or the DOM's) global declarations.
 */
import type { AbortSignalLike, SparksErrorCode, SparksErrorInfo, Unsubscribe } from '../index';

type Timer = unknown;
interface Globals {
  setTimeout(fn: () => void, ms: number): Timer;
  clearTimeout(t: Timer): void;
  setInterval(fn: () => void, ms: number): Timer;
  clearInterval(t: Timer): void;
  fetch(url: string, init?: { headers?: Record<string, string> }): Promise<{ ok: boolean; status: number; json(): Promise<unknown> }>;
  console: { log(...a: unknown[]): void; warn(...a: unknown[]): void; error(...a: unknown[]): void };
  crypto?: { getRandomValues?<T extends Uint8Array>(a: T): T };
}
export const g = globalThis as unknown as Globals;

export const sleep = (ms: number) => new Promise<void>((r) => { g.setTimeout(r, ms); });

// ------------------------------------------------------------------ errors

type ErrorCtor = new (info: SparksErrorInfo) => Error & SparksErrorInfo;
let ErrorClass: ErrorCtor | null = null;

/** index.ts registers its SparksError so errors here are `instanceof SparksError`. */
export function setErrorClass(c: ErrorCtor): void { ErrorClass = c; }

const RETRYABLE: SparksErrorCode[] = ['E_MODEL_DOWNLOAD_FAILED', 'E_BUSY', 'E_PREEMPTED', 'E_PAUSED', 'E_TIMEOUT', 'E_TRANSPORT', 'E_INSUFFICIENT_MEMORY'];

export function sparksError(code: SparksErrorCode, message: string, retryable = RETRYABLE.includes(code), details?: SparksErrorInfo['details']): Error & SparksErrorInfo {
  const info: SparksErrorInfo = { code, message, retryable, details };
  if (ErrorClass) return new ErrorClass(info);
  return Object.assign(new Error(message), info, { name: 'SparksError' });
}

const CODES = new Set<string>([
  'E_NOT_IMPLEMENTED', 'E_NOT_INITIALIZED', 'E_ALREADY_INITIALIZED', 'E_INVALID_ARGUMENT', 'E_DEVICE_UNSUPPORTED',
  'E_MODEL_NOT_READY', 'E_MODEL_DOWNLOAD_FAILED', 'E_MODEL_CHECKSUM_MISMATCH', 'E_MODEL_INCOMPATIBLE', 'E_INSUFFICIENT_STORAGE',
  'E_INSUFFICIENT_MEMORY', 'E_BUSY', 'E_PREEMPTED', 'E_PAUSED', 'E_CANCELLED', 'E_TIMEOUT', 'E_GRAMMAR_UNSTARTED', 'E_NO_MATCH',
  'E_TRANSCRIPTION_UNAVAILABLE', 'E_PERMISSION_DENIED', 'E_CONSENT_REQUIRED', 'E_LEASE_EXPIRED', 'E_LEASE_CONFLICT',
  'E_DECRYPT_FAILED', 'E_PAYLOAD_INVALID', 'E_TRANSPORT', 'E_ENGINE', 'E_INTERNAL',
]);

/** A native promise rejection (`code`, `message`) or anything else, as a SparksError. */
export function fromNative(e: unknown, fallback: SparksErrorCode = 'E_INTERNAL'): Error & SparksErrorInfo {
  const x = e as { code?: unknown; message?: unknown; retryable?: unknown } | null;
  if (x && typeof x.code === 'string' && typeof x.retryable === 'boolean' && CODES.has(x.code)) return x as Error & SparksErrorInfo;
  const code = x && typeof x.code === 'string' && CODES.has(x.code) ? (x.code as SparksErrorCode) : fallback;
  const message = x && typeof x.message === 'string' ? x.message : String(e);
  return sparksError(code, message, undefined, code === 'E_ENGINE' ? { engineMessage: message } : undefined);
}

export const infoOf = (e: unknown): SparksErrorInfo => {
  const s = fromNative(e);
  return { code: s.code, message: s.message, retryable: s.retryable, details: s.details };
};

/**
 * `p`, unless `signal` aborts first: then `onAbort` runs (e.g. cancel the
 * native request) and the result rejects at once with E_CANCELLED, without
 * waiting for `p`. A native call that never comes back (or comes back
 * minutes later on a slow phone) can then never hold a job: whoever aborts
 * gets control back immediately. `p` settling later is ignored.
 */
export function abortable<T>(p: Promise<T>, signal?: AbortSignalLike, onAbort?: () => void): Promise<T> {
  if (!signal) return p;
  return new Promise<T>((resolve, reject) => {
    const stop = () => {
      signal.removeEventListener('abort', stop);
      try { onAbort?.(); } catch { /* best effort */ }
      const why = (signal as { reason?: unknown }).reason;
      reject(sparksError('E_CANCELLED', `aborted${why ? ` (${String(why)})` : ''}`, false));
    };
    p.then((v) => { signal.removeEventListener('abort', stop); resolve(v); }, (e) => { signal.removeEventListener('abort', stop); reject(e); });
    if (signal.aborted) stop(); else signal.addEventListener('abort', stop);
  });
}

/** "1.2 s", "45 s", "3 min 5 s": for log lines. */
export function secs(ms: number): string {
  if (!Number.isFinite(ms)) return '?';
  if (ms < 10000) return `${(Math.max(0, ms) / 1000).toFixed(1)} s`;
  const s = Math.round(ms / 1000);
  return s < 120 ? `${s} s` : `${Math.floor(s / 60)} min ${s % 60} s`;
}

// ------------------------------------------------------------------ events

type Listener<T> = (v: T) => void;
export class Emitter {
  private map = new Map<string, Set<Listener<any>>>();
  on(ev: string, fn: Listener<any>): Unsubscribe {
    const s = this.map.get(ev) ?? new Set();
    s.add(fn);
    this.map.set(ev, s);
    return () => { s.delete(fn); };
  }
  emit(ev: string, v: unknown): void {
    for (const fn of [...(this.map.get(ev) ?? [])]) {
      try { fn(v); } catch (e) { g.console.warn('[sparks] listener threw', e); }
    }
  }
}

// ------------------------------------------------------------------- ids

function randomBytes(n: number): Uint8Array {
  const b = new Uint8Array(n);
  if (g.crypto?.getRandomValues) return g.crypto.getRandomValues(b);
  // Envelope and request ids only need uniqueness, not secrecy (keys are native).
  for (let i = 0; i < n; i++) b[i] = Math.floor(Math.random() * 256);
  return b;
}

export function uuidv4(): string {
  const b = randomBytes(16);
  b[6] = (b[6] & 0x0f) | 0x40;
  b[8] = (b[8] & 0x3f) | 0x80;
  const h = Array.from(b, (x) => x.toString(16).padStart(2, '0')).join('');
  return `${h.slice(0, 8)}-${h.slice(8, 12)}-${h.slice(12, 16)}-${h.slice(16, 20)}-${h.slice(20)}`;
}

/** FNV-1a, hex. For cache keys, never for security. */
export function hash32(s: string): string {
  let h = 2166136261;
  for (let i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 16777619); }
  return (h >>> 0).toString(16).padStart(8, '0');
}

// ------------------------------------------------------------- vectors

export function cosine(a: number[], b: number[]): number {
  let dot = 0, na = 0, nb = 0;
  for (let i = 0; i < a.length && i < b.length; i++) { dot += a[i] * b[i]; na += a[i] * a[i]; nb += b[i] * b[i]; }
  return na && nb ? dot / Math.sqrt(na * nb) : 0;
}

/** Character-trigram similarity, the backend's lexical fallback for phones without a model. */
export function trigramSimilarity(a: string, b: string): number {
  const grams = (s: string) => {
    const t = `  ${s.toLowerCase().replace(/[^a-z0-9 ]+/g, ' ').replace(/\s+/g, ' ').trim()} `;
    const set = new Set<string>();
    for (let i = 0; i + 3 <= t.length; i++) set.add(t.slice(i, i + 3));
    return set;
  };
  const A = grams(a), B = grams(b);
  if (!A.size || !B.size) return 0;
  let inter = 0;
  for (const x of A) if (B.has(x)) inter++;
  return inter / (A.size + B.size - inter);
}

/** A tiny LRU keyed by string. */
export class Lru<V> {
  private m = new Map<string, V>();
  constructor(private cap: number) {}
  get(k: string): V | undefined {
    const v = this.m.get(k);
    if (v !== undefined) { this.m.delete(k); this.m.set(k, v); }
    return v;
  }
  set(k: string, v: V): void {
    this.m.delete(k);
    this.m.set(k, v);
    while (this.m.size > this.cap) this.m.delete(this.m.keys().next().value as string);
  }
  clear(): void { this.m.clear(); }
  entries(): [string, V][] { return [...this.m.entries()]; }
}
