import XCTest
import SparksSDK

/// Device tiers (ARCHITECTURE §2.3, PERFORMANCE §5). RAM figures are what
/// ProcessInfo.physicalMemory reports, which is below the marketed size.
final class SparksTierTests: XCTestCase {
    private let GiB: UInt64 = 1 << 30
    private func gib(_ x: Double) -> UInt64 { UInt64(x * Double(1 << 30)) }

    private func ios(_ ram: UInt64, os: Int = 17, forced: SparksTier? = nil, debug: Bool = false,
                     variants: [(tier: SparksTier, minRamBytes: UInt64)]? = nil) -> SparksTierDecision {
        SparksTierPolicy.decide(ramBytes: ram, armDotProd: false, platform: "ios", osMajor: os,
                                forced: forced, allowForce: debug, variants: variants)
    }

    func testToleranceMatchesTheCCore() {
        XCTAssertEqual(SparksTierPolicy.ramTolerance, 0.85)   // SPK_RAM_TOLERANCE in sparks_core.h
        XCTAssertTrue(SparksTierPolicy.meets(ramBytes: gib(5.11), minRamBytes: 6 * GiB))
        XCTAssertFalse(SparksTierPolicy.meets(ramBytes: gib(5.09), minRamBytes: 6 * GiB))
    }

    func testReferenceIPhones() {
        // iPhone 12 Pro / 13 Pro / 14 / 15 Pro: 6 to 8 GB, report about 5.5 to 7.5 GiB.
        XCTAssertEqual(ios(gib(5.6)), SparksTierDecision(tier: .full, reason: nil))
        XCTAssertEqual(ios(gib(7.5)), SparksTierDecision(tier: .full, reason: nil))
        // iPhone 13 / 12 / 11: 4 GB.
        XCTAssertEqual(ios(gib(3.7)), SparksTierDecision(tier: .lite, reason: "ram"))
        // iPhone XS / XR / SE 2: 3 GB.
        XCTAssertEqual(ios(gib(2.8)), SparksTierDecision(tier: .lite, reason: "ram"))
        // iPhone 8 / X: 2 GB.
        XCTAssertEqual(ios(gib(1.9)), SparksTierDecision(tier: .none, reason: "ram"))
    }

    func testOldOSIsNone() {
        XCTAssertEqual(ios(gib(5.6), os: 15), SparksTierDecision(tier: .none, reason: "os"))
    }

    func testForceOnlyInDebugBuilds() {
        XCTAssertEqual(ios(gib(5.6), forced: .lite, debug: true), SparksTierDecision(tier: .lite, reason: "forced"))
        XCTAssertEqual(ios(gib(1.9), forced: .full, debug: true), SparksTierDecision(tier: .full, reason: "forced"))
        XCTAssertEqual(ios(gib(5.6), forced: SparksTier.none, debug: false), SparksTierDecision(tier: .full, reason: nil))
    }

    func testAndroidNeedsDotProductForFull() {
        let d = SparksTierPolicy.decide(ramBytes: 8 * GiB, armDotProd: false, platform: "android", osMajor: 14)
        XCTAssertEqual(d, SparksTierDecision(tier: .lite, reason: "cpu"))
        let e = SparksTierPolicy.decide(ramBytes: 8 * GiB, armDotProd: true, platform: "android", osMajor: 14)
        XCTAssertEqual(e.tier, .full)
        let x86 = SparksTierPolicy.decide(ramBytes: 8 * GiB, armDotProd: true, platform: "android", osMajor: 14, is64Bit: false)
        XCTAssertEqual(x86, SparksTierDecision(tier: .none, reason: "cpu"))
    }

    func testManifestVariantsPickFirstMet() {
        let manifest: [(tier: SparksTier, minRamBytes: UInt64)] = [(.full, 6 * GiB), (.lite, 3 * GiB)]
        XCTAssertEqual(ios(gib(5.6), variants: manifest).tier, .full)
        XCTAssertEqual(ios(gib(3.7), variants: manifest), SparksTierDecision(tier: .lite, reason: "ram"))
        XCTAssertEqual(ios(gib(1.9), variants: manifest), SparksTierDecision(tier: .none, reason: "ram"))
    }

    func testManifestCanLowerButNeverRaise() {
        // A stricter manifest floor for the 1.7B moves a 6 GB phone to lite.
        let strict: [(tier: SparksTier, minRamBytes: UInt64)] = [(.full, 8 * GiB), (.lite, 3 * GiB)]
        XCTAssertEqual(ios(gib(5.6), variants: strict), SparksTierDecision(tier: .lite, reason: "ram"))
        // A manifest that only ships the 0.5B: lite, because of the manifest.
        let liteOnly: [(tier: SparksTier, minRamBytes: UInt64)] = [(.lite, 3 * GiB)]
        XCTAssertEqual(ios(gib(5.6), variants: liteOnly), SparksTierDecision(tier: .lite, reason: "manifest"))
        // A lax manifest floor never lifts a 4 GB phone to full.
        let lax: [(tier: SparksTier, minRamBytes: UInt64)] = [(.full, 2 * GiB), (.lite, 1 * GiB)]
        XCTAssertEqual(ios(gib(3.7), variants: lax), SparksTierDecision(tier: .lite, reason: "ram"))
    }
}
