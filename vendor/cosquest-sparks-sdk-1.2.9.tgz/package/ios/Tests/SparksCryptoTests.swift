import CryptoKit
import XCTest
import SparksSDK

/// HPKE (RFC 9180) base mode, DHKEM(X25519, HKDF-SHA256) / HKDF-SHA256 /
/// AES-256-GCM, exactly as DATA_CONTRACT §7. The vectors below were produced
/// by the backend's sealer library (@hpke/core 1.9, as in
/// packages/sparks-backend/src/crypto/seal.ts) and also open with the
/// JS mock's opener (packages/sparks-sdk-mock/src/hpke.ts); the second one is
/// this file's sealer, checked to open with @hpke/core.
final class SparksCryptoTests: XCTestCase {

    // Recipient: @hpke/core deriveKeyPair(ikm = 32 x 0x07).
    static let skR = Data(hex: "896615161d5c4dab6be99bb69b180f22c86eb0ac1b8912e958ed5dd08813573b")
    static let pkR = "X9R2M7XkP8p7rRv75CT-rLF12dTUow8Wbb0wY28LRGs"

    // Sealed by @hpke/core with ephemeral deriveKeyPair(ikm = 32 x 0x09).
    static let backendVector = (
        enc: "3okjpnXQIYDN19AJe6QEueHikw1WZculjRdlAGNheTs",
        ct: "2Px6lYO2HBBRlAVLAebEp5vGgcjKvZJ0IHGZoCFX8nl0pB8U4z_38-Fxp8Mjqxh3J_N7MJXx6F2T8vbLOoIiutWbsfCu16Czy3QSSv1_u1xZNIHSZ09FwA",
        jobId: "job_01J9ZQ4T3K",
        deviceId: "dev_u_alice_abc123",
        plaintext: #"{"type":"spark.assign","chatId":"chat_barrio","messages":[],"active":[]}"#
    )

    var recipient: Curve25519.KeyAgreement.PrivateKey!

    override func setUpWithError() throws {
        recipient = try Curve25519.KeyAgreement.PrivateKey(rawRepresentation: Self.skR)
    }

    func testRecipientKeyMatchesVector() {
        XCTAssertEqual(SparksCrypto.b64url(recipient.publicKey.rawRepresentation), Self.pkR)
    }

    func testOpensBackendSealedJobInput() throws {
        let v = Self.backendVector
        let plain = try SparksCrypto.open(enc: XCTUnwrap(SparksCrypto.fromB64url(v.enc)),
                                          ct: XCTUnwrap(SparksCrypto.fromB64url(v.ct)),
                                          info: SparksCrypto.info(kind: "job.offer"),
                                          aad: SparksCrypto.aad(id: v.jobId, deviceId: v.deviceId),
                                          recipient: recipient)
        XCTAssertEqual(String(data: plain, encoding: .utf8), v.plaintext)
    }

    func testInfoAndAadAreTheContractStrings() {
        XCTAssertEqual(String(data: SparksCrypto.info(kind: "job.offer"), encoding: .utf8), "cosquest-sparks/v1/job.offer")
        XCTAssertEqual(String(data: SparksCrypto.info(kind: "context.bundle"), encoding: .utf8), "cosquest-sparks/v1/context.bundle")
        XCTAssertEqual(String(data: SparksCrypto.aad(id: "b_1", deviceId: "dev_x"), encoding: .utf8), "b_1|dev_x")
    }

    /// The aad binds a ciphertext to one job and one device; info binds it to the kind.
    func testRejectsWrongBindings() throws {
        let v = Self.backendVector
        let enc = try XCTUnwrap(SparksCrypto.fromB64url(v.enc))
        let ct = try XCTUnwrap(SparksCrypto.fromB64url(v.ct))
        let info = SparksCrypto.info(kind: "job.offer")
        let aad = SparksCrypto.aad(id: v.jobId, deviceId: v.deviceId)

        XCTAssertThrowsError(try SparksCrypto.open(enc: enc, ct: ct, info: info,
                                                   aad: SparksCrypto.aad(id: "job_other", deviceId: v.deviceId), recipient: recipient))
        XCTAssertThrowsError(try SparksCrypto.open(enc: enc, ct: ct, info: info,
                                                   aad: SparksCrypto.aad(id: v.jobId, deviceId: "dev_other"), recipient: recipient))
        XCTAssertThrowsError(try SparksCrypto.open(enc: enc, ct: ct, info: SparksCrypto.info(kind: "context.bundle"),
                                                   aad: aad, recipient: recipient))
        var tampered = ct
        tampered[tampered.startIndex + 3] ^= 0x01
        XCTAssertThrowsError(try SparksCrypto.open(enc: enc, ct: tampered, info: info, aad: aad, recipient: recipient))
        XCTAssertThrowsError(try SparksCrypto.open(enc: enc, ct: ct, info: info, aad: aad,
                                                   recipient: Curve25519.KeyAgreement.PrivateKey()))
        XCTAssertThrowsError(try SparksCrypto.open(enc: enc.prefix(31), ct: ct, info: info, aad: aad, recipient: recipient))
        XCTAssertThrowsError(try SparksCrypto.open(enc: enc, ct: ct.prefix(15), info: info, aad: aad, recipient: recipient))
    }

    /// Deterministic seal (ephemeral = 32 x 0x03); @hpke/core opens this exact ciphertext.
    func testSealMatchesVectorTheBackendOpens() throws {
        let eph = try Curve25519.KeyAgreement.PrivateKey(rawRepresentation: Data(repeating: 3, count: 32))
        let s = try SparksCrypto.seal(Data("hi".utf8), info: Data("i".utf8), aad: Data("a".utf8), to: recipient.publicKey, ephemeral: eph)
        XCTAssertEqual(SparksCrypto.b64url(s.enc), "Xf7dO2vUf2-ijuFdlp1bsOpTd01Ii9r53xxuASSz7yI")
        XCTAssertEqual(SparksCrypto.b64url(s.ct), "zPTPnYNPgpSoL-K55cWPZ25E")
    }

    func testRoundTripWithRandomKeys() throws {
        let device = Curve25519.KeyAgreement.PrivateKey()
        let body = Data(#"{"scope":"chat","messages":[]}"#.utf8)
        let info = SparksCrypto.info(kind: "context.bundle")
        let aad = SparksCrypto.aad(id: "bundle_9", deviceId: "dev_q")
        let s = try SparksCrypto.seal(body, info: info, aad: aad, to: device.publicKey)
        XCTAssertEqual(s.enc.count, 32)
        XCTAssertEqual(s.ct.count, body.count + 16)
        XCTAssertEqual(try SparksCrypto.open(enc: s.enc, ct: s.ct, info: info, aad: aad, recipient: device), body)
    }

    /// Our RFC 9180 implementation (iOS 16) agrees with CryptoKit's own HPKE (iOS 17+).
    func testAgreesWithCryptoKitHPKE() throws {
        guard #available(iOS 17.0, macOS 14.0, *) else { throw XCTSkip("CryptoKit HPKE needs iOS 17") }
        let suite = HPKE.Ciphersuite(kem: .Curve25519_HKDF_SHA256, kdf: .HKDF_SHA256, aead: .AES_GCM_256)
        let info = SparksCrypto.info(kind: "job.offer")
        let aad = SparksCrypto.aad(id: "job_ck", deviceId: "dev_ck")
        let msg = Data("sealed by CryptoKit".utf8)

        var sender = try HPKE.Sender(recipientKey: recipient.publicKey, ciphersuite: suite, info: info)
        let ct = try sender.seal(msg, authenticating: aad)
        XCTAssertEqual(try SparksCrypto.open(enc: sender.encapsulatedKey, ct: ct, info: info, aad: aad, recipient: recipient), msg)

        let mine = try SparksCrypto.seal(msg, info: info, aad: aad, to: recipient.publicKey)
        var receiver = try HPKE.Recipient(privateKey: recipient, ciphersuite: suite, info: info, encapsulatedKey: mine.enc)
        XCTAssertEqual(try receiver.open(mine.ct, authenticating: aad), msg)
    }

    func testBase64Url() {
        for n in 0..<8 {
            let d = Data((0..<n).map { UInt8(truncatingIfNeeded: $0 &* 77 &+ 250) })
            let s = SparksCrypto.b64url(d)
            XCTAssertFalse(s.contains("=") || s.contains("+") || s.contains("/"))
            XCTAssertEqual(SparksCrypto.fromB64url(s), d)
        }
        XCTAssertEqual(SparksCrypto.fromB64url("-_8"), Data([0xFB, 0xFF]))
    }
}

private extension Data {
    init(hex: String) {
        var bytes = [UInt8]()
        var i = hex.startIndex
        while i < hex.endIndex {
            let j = hex.index(i, offsetBy: 2)
            bytes.append(UInt8(hex[i..<j], radix: 16)!)
            i = j
        }
        self.init(bytes)
    }
}
