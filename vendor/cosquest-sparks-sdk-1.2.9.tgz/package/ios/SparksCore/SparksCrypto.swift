import CryptoKit
import Foundation
import Security

/// The device key and the inbound "data handshake" (DATA_CONTRACT §7).
///
/// HPKE base mode, DHKEM(X25519, HKDF-SHA256) / HKDF-SHA256 / AES-256-GCM,
/// implemented from RFC 9180 over CryptoKit primitives so it runs on iOS 16
/// (CryptoKit's own `HPKE` is iOS 17+; the tests check the two agree).
public enum SparksCrypto {
    static let keychainService = "net.cosquest.sparks"

    public struct DeviceKey {
        public let privateKey: Curve25519.KeyAgreement.PrivateKey
        public let kid: String
        public var publicKeyB64url: String { b64url(privateKey.publicKey.rawRepresentation) }
    }

    /// The device's X25519 key for this (user, session) scope, created on first use.
    /// Stored with kSecAttrAccessibleAfterFirstUnlockThisDeviceOnly: never in backups.
    public static func deviceKey(scope: String) throws -> DeviceKey {
        let account = "device-key." + scope
        if let data = keychainRead(account: account), data.count == 32 + 8 {
            let key = try Curve25519.KeyAgreement.PrivateKey(rawRepresentation: data.prefix(32))
            return DeviceKey(privateKey: key, kid: String(data: data.suffix(8), encoding: .utf8) ?? "k1")
        }
        let key = Curve25519.KeyAgreement.PrivateKey()
        let kid = String(UUID().uuidString.replacingOccurrences(of: "-", with: "").prefix(8)).lowercased()
        var blob = key.rawRepresentation
        blob.append(Data(kid.utf8))
        try keychainWrite(account: account, data: blob)
        return DeviceKey(privateKey: key, kid: kid)
    }

    public static func deleteDeviceKey(scope: String) {
        keychainDelete(account: "device-key." + scope)
    }

    /// A 32-byte random key for the local store, kept in the Keychain.
    static func storeKey(scope: String) throws -> SymmetricKey {
        let account = "store-key." + scope
        if let data = keychainRead(account: account), data.count == 32 { return SymmetricKey(data: data) }
        let key = SymmetricKey(size: .bits256)
        try keychainWrite(account: account, data: key.withUnsafeBytes { Data($0) })
        return key
    }

    static func deleteStoreKey(scope: String) { keychainDelete(account: "store-key." + scope) }

    // MARK: HPKE open (RFC 9180, base mode, single shot)

    public enum HPKEError: Error { case badEncoding, openFailed }

    private static let kemSuiteID = Data("KEM".utf8) + Data([0x00, 0x20])           // DHKEM(X25519, HKDF-SHA256)
    private static let hpkeSuiteID = Data("HPKE".utf8) + Data([0x00, 0x20, 0x00, 0x01, 0x00, 0x02]) // KDF 1, AEAD 2

    private static func labeledExtract(_ suite: Data, salt: Data, label: String, ikm: Data) -> Data {
        let labeled = Data("HPKE-v1".utf8) + suite + Data(label.utf8) + ikm
        let prk = HMAC<SHA256>.authenticationCode(for: labeled, using: SymmetricKey(data: salt.isEmpty ? Data(repeating: 0, count: 32) : salt))
        return Data(prk)
    }

    private static func labeledExpand(_ suite: Data, prk: Data, label: String, info: Data, length: Int) -> Data {
        var labeled = Data([UInt8(length >> 8), UInt8(length & 0xff)])
        labeled += Data("HPKE-v1".utf8) + suite + Data(label.utf8) + info
        // HKDF-Expand with SHA-256
        var out = Data(), t = Data(), i: UInt8 = 1
        let key = SymmetricKey(data: prk)
        while out.count < length {
            t = Data(HMAC<SHA256>.authenticationCode(for: t + labeled + Data([i]), using: key))
            out += t
            i += 1
        }
        return out.prefix(length)
    }

    /// DHKEM(X25519, HKDF-SHA256) shared secret, then the base-mode key
    /// schedule: the AES-256-GCM key and the sequence-0 nonce.
    private static func keySchedule(dh: Data, enc: Data, pkR: Data, info: Data) -> (key: SymmetricKey, nonce: Data) {
        let kemContext = enc + pkR
        let eaePrk = labeledExtract(kemSuiteID, salt: Data(), label: "eae_prk", ikm: dh)
        let sharedSecret = labeledExpand(kemSuiteID, prk: eaePrk, label: "shared_secret", info: kemContext, length: 32)
        // KeySchedule, mode_base (0x00), empty psk
        let pskIDHash = labeledExtract(hpkeSuiteID, salt: Data(), label: "psk_id_hash", ikm: Data())
        let infoHash = labeledExtract(hpkeSuiteID, salt: Data(), label: "info_hash", ikm: info)
        let context = Data([0x00]) + pskIDHash + infoHash
        let secret = labeledExtract(hpkeSuiteID, salt: sharedSecret, label: "secret", ikm: Data())
        let key = labeledExpand(hpkeSuiteID, prk: secret, label: "key", info: context, length: 32)
        // single shot: sequence 0, so nonce = base_nonce XOR 0 = base_nonce
        let baseNonce = labeledExpand(hpkeSuiteID, prk: secret, label: "base_nonce", info: context, length: 12)
        return (SymmetricKey(data: key), baseNonce)
    }

    /// Open a sealed payload. `info` and `aad` per DATA_CONTRACT §7:
    /// info = "cosquest-sparks/v1/" + ("job.offer" | "context.bundle"),
    /// aad = envelope id ("jobId" or "bundleId") + "|" + deviceId.
    public static func open(enc: Data, ct: Data, info: Data, aad: Data,
                            recipient: Curve25519.KeyAgreement.PrivateKey) throws -> Data {
        guard enc.count == 32, ct.count >= 16 else { throw HPKEError.badEncoding }
        let pkE: Curve25519.KeyAgreement.PublicKey
        do { pkE = try Curve25519.KeyAgreement.PublicKey(rawRepresentation: enc) } catch { throw HPKEError.badEncoding }
        let dh: Data
        do { dh = try recipient.sharedSecretFromKeyAgreement(with: pkE).withUnsafeBytes { Data($0) } }
        catch { throw HPKEError.openFailed }
        let ks = keySchedule(dh: dh, enc: enc, pkR: recipient.publicKey.rawRepresentation, info: info)
        do {
            let box = try AES.GCM.SealedBox(nonce: AES.GCM.Nonce(data: ks.nonce),
                                            ciphertext: ct.prefix(ct.count - 16), tag: ct.suffix(16))
            return try AES.GCM.open(box, using: ks.key, authenticating: aad)
        } catch { throw HPKEError.openFailed }
    }

    /// Seal to a recipient (what the backend does with @hpke/core). The SDK
    /// itself never seals: outbound results are plain JSON (DATA_CONTRACT §7).
    /// Here for the tests and for a desktop build acting as a fake backend.
    /// `ephemeral` is for deterministic test vectors only.
    public static func seal(_ plaintext: Data, info: Data, aad: Data,
                            to recipient: Curve25519.KeyAgreement.PublicKey,
                            ephemeral: Curve25519.KeyAgreement.PrivateKey = .init()) throws -> (enc: Data, ct: Data) {
        let enc = ephemeral.publicKey.rawRepresentation
        let dh = try ephemeral.sharedSecretFromKeyAgreement(with: recipient).withUnsafeBytes { Data($0) }
        let ks = keySchedule(dh: dh, enc: enc, pkR: recipient.rawRepresentation, info: info)
        let box = try AES.GCM.seal(plaintext, using: ks.key, nonce: AES.GCM.Nonce(data: ks.nonce), authenticating: aad)
        return (enc, box.ciphertext + box.tag)
    }

    /// The info string for a sealed payload kind ("job.offer" | "context.bundle").
    public static func info(kind: String) -> Data { Data("cosquest-sparks/v1/\(kind)".utf8) }
    /// The aad for an envelope id (jobId or bundleId) and this device.
    public static func aad(id: String, deviceId: String) -> Data { Data("\(id)|\(deviceId)".utf8) }

    // MARK: base64url

    public static func b64url(_ d: Data) -> String {
        d.base64EncodedString().replacingOccurrences(of: "+", with: "-")
            .replacingOccurrences(of: "/", with: "_").replacingOccurrences(of: "=", with: "")
    }

    public static func fromB64url(_ s: String) -> Data? {
        var t = s.replacingOccurrences(of: "-", with: "+").replacingOccurrences(of: "_", with: "/")
        while t.count % 4 != 0 { t += "=" }
        return Data(base64Encoded: t)
    }

    // MARK: Keychain

    static func keychainRead(account: String) -> Data? {
        let q: [String: Any] = [kSecClass as String: kSecClassGenericPassword,
                                kSecAttrService as String: keychainService,
                                kSecAttrAccount as String: account,
                                kSecReturnData as String: true]
        var out: CFTypeRef?
        return SecItemCopyMatching(q as CFDictionary, &out) == errSecSuccess ? out as? Data : nil
    }

    static func keychainWrite(account: String, data: Data) throws {
        keychainDelete(account: account)
        let q: [String: Any] = [kSecClass as String: kSecClassGenericPassword,
                                kSecAttrService as String: keychainService,
                                kSecAttrAccount as String: account,
                                kSecAttrAccessible as String: kSecAttrAccessibleAfterFirstUnlockThisDeviceOnly,
                                kSecValueData as String: data]
        let status = SecItemAdd(q as CFDictionary, nil)
        guard status == errSecSuccess else {
            throw NSError(domain: "SparksKeychain", code: Int(status))
        }
    }

    static func keychainDelete(account: String) {
        let q: [String: Any] = [kSecClass as String: kSecClassGenericPassword,
                                kSecAttrService as String: keychainService,
                                kSecAttrAccount as String: account]
        SecItemDelete(q as CFDictionary)
    }
}

/// The encrypted local store (PRIVACY §3): one AES-256-GCM sealed file per
/// key under Application Support, scoped per (userId, sessionId), excluded
/// from backup, Data Protection completeUntilFirstUserAuthentication so
/// background jobs can read it after first unlock.
public final class SparksSecureStore {
    private let dir: URL
    private let key: SymmetricKey
    private let scope: String
    private let lock = NSLock()

    public init(scope: String) throws {
        self.scope = scope
        let safe = SparksSecureStore.safeName(scope)
        dir = SparksPaths.root.appendingPathComponent("store/\(safe)", isDirectory: true)
        try FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true,
                                                attributes: [.protectionKey: FileProtectionType.completeUntilFirstUserAuthentication])
        key = try SparksCrypto.storeKey(scope: scope)
    }

    static func safeName(_ s: String) -> String {
        let h = SHA256.hash(data: Data(s.utf8)).prefix(12).map { String(format: "%02x", $0) }.joined()
        return h
    }

    public func get(_ name: String) -> String? {
        lock.lock(); defer { lock.unlock() }
        let url = dir.appendingPathComponent(SparksSecureStore.safeName(name))
        guard let data = try? Data(contentsOf: url),
              let box = try? AES.GCM.SealedBox(combined: data),
              let plain = try? AES.GCM.open(box, using: key, authenticating: Data(name.utf8)) else { return nil }
        return String(data: plain, encoding: .utf8)
    }

    public func set(_ name: String, _ value: String?) throws {
        lock.lock(); defer { lock.unlock() }
        let url = dir.appendingPathComponent(SparksSecureStore.safeName(name))
        guard let value else { try? FileManager.default.removeItem(at: url); return }
        let box = try AES.GCM.seal(Data(value.utf8), using: key, authenticating: Data(name.utf8))
        try box.combined!.write(to: url, options: [.atomic, .completeFileProtectionUntilFirstUserAuthentication])
    }

    /// Delete everything in this scope, and its key.
    public func wipe() {
        lock.lock(); defer { lock.unlock() }
        try? FileManager.default.removeItem(at: dir)
        SparksCrypto.deleteStoreKey(scope: scope)
    }
}

enum SparksPaths {
    static var root: URL {
        let base = FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0]
        var url = base.appendingPathComponent("CosQuestSparks", isDirectory: true)
        try? FileManager.default.createDirectory(at: url, withIntermediateDirectories: true)
        var v = URLResourceValues()
        v.isExcludedFromBackup = true
        try? url.setResourceValues(v)
        return url
    }
}
