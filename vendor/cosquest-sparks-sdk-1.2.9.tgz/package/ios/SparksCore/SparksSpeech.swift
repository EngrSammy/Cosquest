import AVFoundation
import Foundation

/// On-device TTS for the Warden (WardenApi.speak). AVSpeechSynthesizer, so
/// nothing leaves the phone. It never reconfigures an audio session that is
/// already in play-and-record (a call owns it); ducking applies only outside
/// calls.
public final class SparksSpeech: NSObject, AVSpeechSynthesizerDelegate, @unchecked Sendable {
    public static let shared = SparksSpeech()

    private let synth = AVSpeechSynthesizer()
    private var pending: [ObjectIdentifier: (Bool) -> Void] = [:]
    private var ducked = false
    private let lock = NSLock()

    override private init() {
        super.init()
        synth.delegate = self
    }

    /// rate and pitch: 0.5 to 2.0, 1.0 = default. Completion gets false when stopped.
    public func speak(_ text: String, rate: Double, pitch: Double, duckOthers: Bool, completion: @escaping (Bool) -> Void) {
        DispatchQueue.main.async { [self] in
            let u = AVSpeechUtterance(string: text)
            let r = Float(max(0.5, min(2.0, rate))) * AVSpeechUtteranceDefaultSpeechRate
            u.rate = max(AVSpeechUtteranceMinimumSpeechRate, min(AVSpeechUtteranceMaximumSpeechRate, r))
            u.pitchMultiplier = Float(max(0.5, min(2.0, pitch)))
            u.voice = AVSpeechSynthesisVoice(language: "en-US")
            if duckOthers { duck(true) }
            lock.lock(); pending[ObjectIdentifier(u)] = completion; lock.unlock()
            synth.speak(u)
        }
    }

    public func stop() {
        DispatchQueue.main.async { self.synth.stopSpeaking(at: .immediate) }
    }

    private func duck(_ on: Bool) {
        let session = AVAudioSession.sharedInstance()
        if session.category == .playAndRecord { return }   // a call owns the session
        if on {
            try? session.setCategory(.playback, mode: .spokenAudio, options: [.duckOthers])
            try? session.setActive(true)
            ducked = true
        } else if ducked {
            try? session.setActive(false, options: [.notifyOthersOnDeactivation])
            ducked = false
        }
    }

    private func finish(_ u: AVSpeechUtterance, _ ok: Bool) {
        lock.lock(); let c = pending.removeValue(forKey: ObjectIdentifier(u)); let idle = pending.isEmpty; lock.unlock()
        if idle { duck(false) }
        c?(ok)
    }

    public func speechSynthesizer(_ s: AVSpeechSynthesizer, didFinish u: AVSpeechUtterance) { finish(u, true) }
    public func speechSynthesizer(_ s: AVSpeechSynthesizer, didCancel u: AVSpeechUtterance) { finish(u, false) }
}
