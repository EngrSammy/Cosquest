import Foundation

/// What this phone can run (ARCHITECTURE §2.3, PERFORMANCE §5). Pure logic,
/// no UIKit, so the game, the RN module and the tests share one copy.
public enum SparksTier: String, CaseIterable {
    case full, lite, none
}

public struct SparksTierDecision: Equatable {
    public let tier: SparksTier
    /// nil when nothing lowered it; else 'ram' | 'cpu' | 'os' | 'forced' | 'manifest' (DeviceCapabilities.tierReason).
    public let reason: String?

    public init(tier: SparksTier, reason: String?) {
        self.tier = tier
        self.reason = reason
    }
}

public enum SparksTierPolicy {
    /// Phones report less than their marketed RAM (a 6 GB iPhone reports
    /// about 5.5 to 5.8 GiB). Same constant as SPK_RAM_TOLERANCE in sparks_core.h.
    public static let ramTolerance = 0.85
    /// Default floors before a manifest is known (manifest min_ram_bytes refines them).
    public static let fullFloorBytes: UInt64 = 6 << 30
    public static let liteFloorBytes: UInt64 = 3 << 30
    /// Minimum iOS major version (podspec deployment target).
    public static let minIOSMajor = 16

    public static func meets(ramBytes: UInt64, minRamBytes: UInt64) -> Bool {
        Double(ramBytes) >= ramTolerance * Double(minRamBytes)
    }

    /// - Parameters:
    ///   - forced: honoured only when `allowForce` (debug builds).
    ///   - variants: manifest variants, best first, as (tier, min_ram_bytes).
    ///     When given, the tier is that of the first variant the phone meets,
    ///     never higher than what RAM/CPU/OS allow.
    public static func decide(ramBytes: UInt64, armDotProd: Bool, platform: String = "ios",
                              osMajor: Int, is64Bit: Bool = true,
                              forced: SparksTier? = nil, allowForce: Bool = false,
                              variants: [(tier: SparksTier, minRamBytes: UInt64)]? = nil) -> SparksTierDecision {
        if let forced, allowForce { return SparksTierDecision(tier: forced, reason: "forced") }
        if platform == "ios" && osMajor < minIOSMajor { return SparksTierDecision(tier: .none, reason: "os") }
        if !is64Bit { return SparksTierDecision(tier: .none, reason: "cpu") }

        var cap: SparksTier
        var reason: String?
        if meets(ramBytes: ramBytes, minRamBytes: fullFloorBytes) {
            cap = .full
            // Android needs SDOT for the 1.7B to be usable; every iOS 16 device runs it without.
            if platform == "android" && !armDotProd { cap = .lite; reason = "cpu" }
        } else if meets(ramBytes: ramBytes, minRamBytes: liteFloorBytes) {
            cap = .lite; reason = "ram"
        } else {
            return SparksTierDecision(tier: .none, reason: "ram")
        }

        guard let variants, !variants.isEmpty else { return SparksTierDecision(tier: cap, reason: reason) }
        var blockedByRam = false
        for v in variants where v.tier != .none && rank(v.tier) >= rank(cap) {
            if meets(ramBytes: ramBytes, minRamBytes: v.minRamBytes) {
                if v.tier == cap { return SparksTierDecision(tier: cap, reason: reason) }
                // Lower than the hardware allows: the manifest's floor or variant list decided it.
                return SparksTierDecision(tier: v.tier, reason: reason ?? (blockedByRam ? "ram" : "manifest"))
            }
            blockedByRam = true
        }
        return SparksTierDecision(tier: .none, reason: reason ?? (blockedByRam ? "ram" : "manifest"))
    }

    /// Lower is better.
    static func rank(_ t: SparksTier) -> Int {
        switch t { case .full: return 0; case .lite: return 1; case .none: return 2 }
    }
}
