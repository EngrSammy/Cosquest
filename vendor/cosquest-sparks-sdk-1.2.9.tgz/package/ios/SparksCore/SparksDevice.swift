import Foundation
import UIKit
import os

/// What this phone is and what state it is in: tier inputs, and the gates
/// background work needs (ARCHITECTURE §2.2).
public final class SparksDevice {
    public static let shared = SparksDevice()

    public struct Gates: Equatable {
        public var foreground: Bool
        public var batteryLevel: Double?     // 0...1, nil when unknown (simulator)
        public var charging: Bool
        public var lowPowerMode: Bool
        public var thermal: String           // nominal | fair | serious | critical
        public var lastMemoryWarning: Date?

        public var json: [String: Any] {
            var d: [String: Any] = ["foreground": foreground, "charging": charging,
                                    "lowPowerMode": lowPowerMode, "thermal": thermal]
            d["batteryLevel"] = batteryLevel.map { $0 as Any } ?? NSNull()
            d["lastMemoryWarningMs"] = lastMemoryWarning.map { $0.timeIntervalSince1970 * 1000 as Any } ?? NSNull()
            return d
        }
    }

    public var onGatesChanged: ((Gates) -> Void)?
    public var onMemoryWarning: (() -> Void)?

    private let lock = NSLock()
    private var _gates: Gates
    private var observing = false

    private init() {
        _gates = Gates(foreground: true, batteryLevel: nil, charging: false, lowPowerMode: false,
                       thermal: "nominal", lastMemoryWarning: nil)
    }

    public var gates: Gates { lock.lock(); defer { lock.unlock() }; return _gates }

    public var ramBytes: UInt64 { ProcessInfo.processInfo.physicalMemory }
    public var osVersion: String { UIDevice.current.systemVersion }
    public var deviceModel: String {
        var info = utsname()
        uname(&info)
        let id = withUnsafeBytes(of: &info.machine) { raw in
            String(cString: raw.bindMemory(to: CChar.self).baseAddress!)
        }
        if id == "arm64" || id == "x86_64" { return "Simulator (\(ProcessInfo.processInfo.environment["SIMULATOR_MODEL_IDENTIFIER"] ?? id))" }
        return id
    }

    /// ARMv8.2 dot product (SDOT). A13 and later; not needed for any tier on iOS.
    public var armDotProd: Bool {
        var v: Int32 = 0
        var size = MemoryLayout<Int32>.size
        if sysctlbyname("hw.optional.arm.FEAT_DotProd", &v, &size, nil, 0) == 0 { return v != 0 }
        return false
    }

    /// Bytes free for "important" data (what a model download may use).
    public var freeDiskBytes: Int64 {
        let url = URL(fileURLWithPath: NSHomeDirectory())
        let v = try? url.resourceValues(forKeys: [.volumeAvailableCapacityForImportantUsageKey])
        return v?.volumeAvailableCapacityForImportantUsage ?? 0
    }

    public var osMajor: Int { ProcessInfo.processInfo.operatingSystemVersion.majorVersion }

    public func tier(forced: SparksTier?, allowForce: Bool) -> SparksTierDecision {
        SparksTierPolicy.decide(ramBytes: ramBytes, armDotProd: armDotProd, platform: "ios",
                                osMajor: osMajor, forced: forced, allowForce: allowForce)
    }

    /// Bytes this process may still allocate before iOS terminates it.
    public var availableMemory: UInt64 {
        let v = os_proc_available_memory()
        // 0 in the simulator and on macOS: no limit is enforced there.
        return v == 0 ? UInt64.max : UInt64(v)
    }

    /// Milliseconds since the last memory warning, or -1.
    public var memoryWarningAgeMs: Double {
        guard let w = gates.lastMemoryWarning else { return -1 }
        return Date().timeIntervalSince(w) * 1000
    }

    /// Memory budget for loading a model handle (PERFORMANCE §2): the KV for
    /// the handle's full context plus scratch. The lite 0.6B has the same KV
    /// shape as the 1.7B (224 KiB per token), only smaller activations, so
    /// its numbers are close to full: 260 / 520 MiB (the old 0.5B's 100 / 140
    /// would let a 2,048-token job outgrow the budget).
    public func memoryOK(forTier tier: String, handle: Int32) -> Bool {
        let need: UInt64 = tier == "full" ? (handle == 0 ? 280 : 560) << 20 : (handle == 0 ? 260 : 520) << 20
        if let w = gates.lastMemoryWarning, Date().timeIntervalSince(w) < 60, handle != 0 { return false }
        return availableMemory >= need
    }

    public func startObserving() {
        lock.lock()
        if observing { lock.unlock(); return }
        observing = true
        lock.unlock()
        DispatchQueue.main.async {
            UIDevice.current.isBatteryMonitoringEnabled = true
            self.refresh()
            let nc = NotificationCenter.default
            let names: [Notification.Name] = [
                UIDevice.batteryLevelDidChangeNotification, UIDevice.batteryStateDidChangeNotification,
                .NSProcessInfoPowerStateDidChange, ProcessInfo.thermalStateDidChangeNotification,
                UIApplication.didBecomeActiveNotification, UIApplication.didEnterBackgroundNotification,
                UIApplication.willEnterForegroundNotification,
            ]
            for n in names { nc.addObserver(self, selector: #selector(self.changed), name: n, object: nil) }
            nc.addObserver(self, selector: #selector(self.memoryWarning),
                           name: UIApplication.didReceiveMemoryWarningNotification, object: nil)
        }
    }

    @objc private func changed(_ n: Notification) {
        if n.name == UIApplication.didEnterBackgroundNotification { setForeground(false) }
        else if n.name == UIApplication.didBecomeActiveNotification || n.name == UIApplication.willEnterForegroundNotification { setForeground(true) }
        else { refresh() }
    }

    @objc private func memoryWarning() {
        lock.lock(); _gates.lastMemoryWarning = Date(); lock.unlock()
        onMemoryWarning?()
        onGatesChanged?(gates)
    }

    private func setForeground(_ fg: Bool) {
        lock.lock(); _gates.foreground = fg; lock.unlock()
        refresh()
    }

    private func refresh() {
        let device = UIDevice.current
        let level = device.batteryLevel
        let state = device.batteryState
        let thermal: String
        switch ProcessInfo.processInfo.thermalState {
        case .nominal: thermal = "nominal"
        case .fair: thermal = "fair"
        case .serious: thermal = "serious"
        case .critical: thermal = "critical"
        @unknown default: thermal = "nominal"
        }
        lock.lock()
        let before = _gates
        _gates.batteryLevel = level < 0 ? nil : Double(level)
        _gates.charging = state == .charging || state == .full
        _gates.lowPowerMode = ProcessInfo.processInfo.isLowPowerModeEnabled
        _gates.thermal = thermal
        let after = _gates
        lock.unlock()
        if before != after { onGatesChanged?(after) }
    }
}
