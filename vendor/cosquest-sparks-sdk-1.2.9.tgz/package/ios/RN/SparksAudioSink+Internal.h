// Private to the pod: SparksModule attaches the running transcriber.
#import "SparksAudioSink.h"

NS_ASSUME_NONNULL_BEGIN

@interface SPKAudioSink (Internal)
/// `asr` is a `spk_asr *` (void * keeps C types out of this header), or NULL to detach.
- (void)attach:(nullable void *)asr;
@end

NS_ASSUME_NONNULL_END
