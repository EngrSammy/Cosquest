import CryptoKit
import Foundation

/// The Objective-C face of SparksCore for SparksModule.mm. Every method takes
/// and returns Foundation types only. Errors carry a SparksErrorCode in
/// userInfo["code"] so the module can reject with it unchanged.
@objc(SPKBridge)
public final class SparksBridge: NSObject {
    static let errorDomain = "net.cosquest.sparks"

    static func error(_ code: String, _ message: String) -> NSError {
        NSError(domain: errorDomain, code: 1, userInfo: ["code": code, NSLocalizedDescriptionKey: message])
    }

    // MARK: device

    @objc(deviceInfoWithForceTier:allowForce:)
    public static func deviceInfo(forceTier: String, allowForce: Bool) -> [String: Any] {
        let d = SparksDevice.shared
        let decision = d.tier(forced: SparksTier(rawValue: forceTier), allowForce: allowForce)
        let avail = d.availableMemory
        return [
            "platform": "ios",
            "osVersion": d.osVersion,
            "deviceModel": d.deviceModel,
            "ramBytes": Double(d.ramBytes),
            "availableMemoryBytes": avail == UInt64.max ? -1.0 : Double(avail),
            "armDotProd": d.armDotProd,
            "transcription": false,            // the module fills this from spk_asr_available()
            "freeDiskBytes": Double(d.freeDiskBytes),
            "appVersion": (Bundle.main.object(forInfoDictionaryKey: "CFBundleShortVersionString") as? String) ?? "0",
            "debugBuild": allowForce,
            "tier": decision.tier.rawValue,
            "tierReason": decision.reason ?? "",
        ]
    }

    @objc(gates)
    public static func gates() -> [String: Any] {
        gatesDict(SparksDevice.shared.gates)
    }

    static func gatesDict(_ g: SparksDevice.Gates) -> [String: Any] {
        [
            "foreground": g.foreground,
            "batteryLevel": g.batteryLevel ?? -1.0,
            "charging": g.charging,
            "lowPowerMode": g.lowPowerMode,
            "thermal": g.thermal,
            "memoryWarningAgeMs": g.lastMemoryWarning.map { Date().timeIntervalSince($0) * 1000 } ?? -1.0,
        ]
    }

    /// onChange(gates, isMemoryWarning). Replaces any previous observer.
    @objc(startObserving:)
    public static func startObserving(_ onChange: @escaping ([String: Any], Bool) -> Void) {
        let d = SparksDevice.shared
        d.onGatesChanged = { g in onChange(gatesDict(g), false) }
        d.onMemoryWarning = { onChange(gatesDict(d.gates), true) }
        d.startObserving()
    }

    /// Memory budget for opening engine handle 0 (warden) or 1 (sparks).
    @objc(memoryOKForTier:handle:)
    public static func memoryOK(tier: String, handle: Int32) -> Bool {
        SparksDevice.shared.memoryOK(forTier: tier, handle: handle)
    }

    // MARK: device key and HPKE

    @objc(deviceKeyForScope:error:)
    public static func deviceKey(scope: String) throws -> [String: String] {
        do {
            let k = try SparksCrypto.deviceKey(scope: scope)
            return ["publicKey": k.publicKeyB64url, "kid": k.kid]
        } catch {
            throw Self.error("E_INTERNAL", "device key unavailable: \(error.localizedDescription)")
        }
    }

    @objc(deleteDeviceKeyForScope:)
    public static func deleteDeviceKey(scope: String) {
        SparksCrypto.deleteDeviceKey(scope: scope)
    }

    @objc(openSealedForScope:enc:ct:info:aad:error:)
    public static func openSealed(scope: String, enc: String, ct: String, info: String, aad: String) throws -> String {
        guard let e = SparksCrypto.fromB64url(enc), let c = SparksCrypto.fromB64url(ct) else {
            throw Self.error("E_DECRYPT_FAILED", "sealed payload is not base64url")
        }
        let key: SparksCrypto.DeviceKey
        do { key = try SparksCrypto.deviceKey(scope: scope) } catch {
            throw Self.error("E_DECRYPT_FAILED", "no device key")
        }
        do {
            let plain = try SparksCrypto.open(enc: e, ct: c, info: Data(info.utf8), aad: Data(aad.utf8), recipient: key.privateKey)
            guard let s = String(data: plain, encoding: .utf8) else { throw SparksCrypto.HPKEError.openFailed }
            return s
        } catch {
            throw Self.error("E_DECRYPT_FAILED", "sealed payload did not open with this device's key")
        }
    }

    // MARK: encrypted store

    private static let storeLock = NSLock()
    private static var stores: [String: SparksSecureStore] = [:]

    static func store(_ scope: String) throws -> SparksSecureStore {
        storeLock.lock(); defer { storeLock.unlock() }
        if let s = stores[scope] { return s }
        let s = try SparksSecureStore(scope: scope)
        stores[scope] = s
        return s
    }

    @objc(storeGetForScope:name:)
    public static func storeGet(scope: String, name: String) -> String? {
        (try? store(scope))?.get(name)
    }

    @objc(storeSetForScope:name:value:error:)
    public static func storeSet(scope: String, name: String, value: String?) throws {
        do { try store(scope).set(name, value) } catch {
            throw Self.error("E_INTERNAL", "store write failed: \(error.localizedDescription)")
        }
    }

    @objc(storeWipeForScope:)
    public static func storeWipe(scope: String) {
        storeLock.lock()
        let s = stores.removeValue(forKey: scope)
        storeLock.unlock()
        if let s { s.wipe() } else { (try? SparksSecureStore(scope: scope))?.wipe() }
    }

    // MARK: model files

    @objc(modelPathForSha256:kind:)
    public static func modelPath(sha256: String, kind: String) -> String? {
        SparksModelStore.shared.verifiedPath(sha256: sha256, kind: kind)?.path
    }

    /// progress(phase, done, total); completion(path, errorCode, message): path on success.
    @objc(downloadURL:sha256:bytes:kind:allowCellular:authToken:progress:completion:)
    public static func download(url: String, sha256: String, bytes: Double, kind: String, allowCellular: Bool,
                                authToken: String, progress: @escaping (String, Double, Double) -> Void,
                                completion: @escaping (String?, String?, String?) -> Void) {
        guard let u = URL(string: url) else {
            completion(nil, "E_INVALID_ARGUMENT", "bad model URL"); return
        }
        SparksModelStore.shared.download(url: u, sha256: sha256, bytes: Int64(bytes), kind: kind,
                                         allowCellular: allowCellular, authToken: authToken,
                                         progress: { phase, done, total in progress(phase.rawValue, Double(done), Double(total)) },
                                         completion: { r in
                                             switch r {
                                             case .success(let p): completion(p.path, nil, nil)
                                             case .failure(let f): completion(nil, f.code, f.message)
                                             }
                                         })
    }

    @objc(cancelDownloads)
    public static func cancelDownloads() { SparksModelStore.shared.cancelAll() }

    @objc(deleteModelFilesKeeping:)
    public static func deleteModelFiles(keeping: [String]) {
        SparksModelStore.shared.deleteAll(keeping: Set(keeping.map { $0.lowercased() }))
    }

    // MARK: speech

    @objc(speak:rate:pitch:duck:completion:)
    public static func speak(_ text: String, rate: Double, pitch: Double, duck: Bool, completion: @escaping (Bool) -> Void) {
        SparksSpeech.shared.speak(text, rate: rate, pitch: pitch, duckOthers: duck, completion: completion)
    }

    @objc(stopSpeaking)
    public static func stopSpeaking() { SparksSpeech.shared.stop() }
}
