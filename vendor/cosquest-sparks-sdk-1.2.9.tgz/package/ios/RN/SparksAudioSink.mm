#import "SparksAudioSink.h"
#import "SparksAudioSink+Internal.h"

#include "sparks_core.h"

#include <atomic>

@implementation SPKAudioSink {
  // The running transcriber, or null. Set by SparksModule; the transcriber
  // itself lives as long as the module, so a push racing a stop is harmless
  // (spk_asr drops audio once inactive).
  std::atomic<spk_asr *> _asr;
}

+ (SPKAudioSink *)shared
{
  static SPKAudioSink *sink;
  static dispatch_once_t once;
  dispatch_once(&once, ^{
    sink = [[SPKAudioSink alloc] initPrivate];
  });
  return sink;
}

- (instancetype)initPrivate
{
  if ((self = [super init])) {
    _asr.store(nullptr);
  }
  return self;
}

- (BOOL)isActive
{
  return _asr.load() != nullptr;
}

- (void)attach:(void *)asr
{
  _asr.store(static_cast<spk_asr *>(asr));
}

- (void)pushPCM16:(const int16_t *)samples count:(NSInteger)count sampleRate:(double)sampleRate
{
  spk_asr *a = _asr.load();
  if (a && samples && count > 0) spk_asr_push_i16(a, samples, (int)count, (int)sampleRate);
}

- (void)pushFloat32:(const float *)samples count:(NSInteger)count sampleRate:(double)sampleRate
{
  spk_asr *a = _asr.load();
  if (a && samples && count > 0) spk_asr_push_f32(a, samples, (int)count, (int)sampleRate);
}

@end
