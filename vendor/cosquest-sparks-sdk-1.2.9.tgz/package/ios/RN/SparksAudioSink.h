// SparksAudioSink.h: how the host's call stack hands this user's microphone
// audio to Sparks transcription, native to native (AudioSource 'external').
//
// Plain Objective-C on purpose: this is the pod's only public header, so it
// is what Swift host code sees as `SparksAudioSink.shared`.
//
//   // in the call stack's capture callback (any thread, real-time safe:
//   // it copies into the transcriber's buffer and returns)
//   SparksAudioSink.shared.pushPCM16(samples, count: n, sampleRate: 48000)
//
// Audio is dropped unless a transcription session is running and unmuted
// (calls.startTranscription in JS). Any sample rate; Moonshine resamples.
#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

NS_SWIFT_NAME(SparksAudioSink)
@interface SPKAudioSink : NSObject

@property (class, nonatomic, readonly) SPKAudioSink *shared;

/// True while a transcription session is accepting audio.
@property (nonatomic, readonly, getter=isActive) BOOL active;

/// Mono 16-bit PCM.
- (void)pushPCM16:(const int16_t *)samples count:(NSInteger)count sampleRate:(double)sampleRate
    NS_SWIFT_NAME(pushPCM16(_:count:sampleRate:));

/// Mono float PCM in [-1, 1].
- (void)pushFloat32:(const float *)samples count:(NSInteger)count sampleRate:(double)sampleRate
    NS_SWIFT_NAME(pushFloat32(_:count:sampleRate:));

- (instancetype)init NS_UNAVAILABLE;

@end

NS_ASSUME_NONNULL_END
