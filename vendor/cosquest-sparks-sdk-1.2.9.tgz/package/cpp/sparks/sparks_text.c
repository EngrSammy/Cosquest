/* sparks_text.c: JSON repair for model output, the Warden line check, and the
 * tolerant RAM tier comparison. Pure C, no allocation beyond the caller's
 * buffers, so the same file serves iOS, Android and the desktop build. */
#define _POSIX_C_SOURCE 200809L   /* strncasecmp under -std=c11 on glibc/bionic */
#include "sparks_core.h"

#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>   /* strncasecmp: POSIX, not C11; Android's bionic needs this */

/* ------------------------------------------------------------------ RAM */
int spk_ram_meets(uint64_t ram_bytes, uint64_t min_ram_bytes) {
    return (double)ram_bytes >= SPK_RAM_TOLERANCE * (double)min_ram_bytes;
}

/* --------------------------------------------------------------- base64 */
static int b64_val(unsigned char c) {
    if (c >= 'A' && c <= 'Z') return c - 'A';
    if (c >= 'a' && c <= 'z') return c - 'a' + 26;
    if (c >= '0' && c <= '9') return c - '0' + 52;
    if (c == '+' || c == '-') return 62;
    if (c == '/' || c == '_') return 63;
    return -1;
}

size_t spk_b64_decoded_max(size_t in_len) { return (in_len / 4 + 1) * 3; }

int spk_b64_decode(const char *in, size_t in_len, uint8_t *out, size_t cap) {
    if (!in || (!out && cap)) return -1;
    uint32_t acc = 0;
    int bits = 0;
    size_t n = 0;
    int pad = 0;
    for (size_t i = 0; i < in_len; i++) {
        unsigned char c = (unsigned char)in[i];
        if (c == '=') { pad = 1; continue; }
        if (isspace(c)) continue;
        if (pad) return -1;                 /* data after padding */
        int v = b64_val(c);
        if (v < 0) return -1;
        acc = (acc << 6) | (uint32_t)v;
        bits += 6;
        if (bits >= 8) {
            bits -= 8;
            if (n >= cap) return -1;
            out[n++] = (uint8_t)((acc >> bits) & 0xFF);
        }
    }
    return (int)n;
}

int spk_pcm16le_to_i16(const uint8_t *bytes, size_t len, int16_t *out, int cap) {
    if (!bytes || !out || cap <= 0) return 0;
    int n = (int)(len / 2);
    if (n > cap) n = cap;
    for (int i = 0; i < n; i++)
        out[i] = (int16_t)(uint16_t)(bytes[2 * i] | ((uint16_t)bytes[2 * i + 1] << 8));
    return n;
}

/* --------------------------------------------------------- JSON repair */
typedef struct { char *p; size_t len, cap; int overflow; } obuf;

static void put(obuf *o, char c) {
    if (o->len + 1 >= o->cap) { o->overflow = 1; return; }
    o->p[o->len++] = c;
    o->p[o->len] = '\0';
}
static void puts_(obuf *o, const char *s) { while (*s) put(o, *s++); }

static char last_sig(const obuf *o) {
    for (size_t i = o->len; i > 0; i--)
        if (!isspace((unsigned char)o->p[i - 1])) return o->p[i - 1];
    return 0;
}
static void drop_trailing_comma(obuf *o) {
    size_t i = o->len;
    while (i > 0 && isspace((unsigned char)o->p[i - 1])) i--;
    if (i > 0 && o->p[i - 1] == ',') { o->len = i - 1; o->p[o->len] = '\0'; }
}

/* Is the next significant character (from s) a colon? */
static int next_is_colon(const char *s) {
    while (*s && isspace((unsigned char)*s)) s++;
    return *s == ':';
}

/* UTF-8 smart quotes: returns the ASCII quote they stand for, sets *adv. */
static char smart_quote(const unsigned char *s, int *adv) {
    if (s[0] == 0xE2 && s[1] == 0x80) {
        if (s[2] == 0x9C || s[2] == 0x9D) { *adv = 3; return '"'; }
        if (s[2] == 0x98 || s[2] == 0x99) { *adv = 3; return '\''; }
    }
    *adv = 1;
    return 0;
}

static int is_bare(char c) {
    return isalnum((unsigned char)c) || c == '_' || c == '-' || c == '+' || c == '.';
}

static int looks_numeric(const char *w, size_t n) {
    if (n == 0) return 0;
    size_t i = 0;
    if (w[0] == '-' || w[0] == '+') i++;
    int digits = 0;
    for (; i < n; i++) {
        if (isdigit((unsigned char)w[i])) digits++;
        else if (w[i] != '.' && w[i] != 'e' && w[i] != 'E' && w[i] != '-' && w[i] != '+') return 0;
    }
    return digits > 0;
}

int spk_json_repair(const char *raw, char *out, size_t cap) {
    if (!raw || !out || cap < 3) return -2;
    out[0] = '\0';
    const char *s = raw;
    /* A closed think block: everything after it. An unclosed one: skip the tag. */
    const char *tc = strstr(s, "</think>");
    if (tc) s = tc + 8;
    const char *start = strchr(s, '{');
    if (!start) return -1;

    obuf o = { out, 0, cap, 0 };
    char stack[64];
    int depth = 0, changed = 0;
    /* where to cut a dangling key: out length before its comma, or -1 */
    long key_cut = -1;
    int expect_key = 0;   /* inside an object, a key may come next */

    const char *p = start;
    while (*p) {
        int adv = 1;
        char sq = smart_quote((const unsigned char *)p, &adv);
        char c = sq ? sq : *p;
        if (sq) changed = 1;

        if (c == '"' || c == '\'') {
            /* a string */
            char q = c;
            if (q == '\'') changed = 1;
            int at_key = expect_key && depth > 0 && stack[depth - 1] == '{';
            long before = (long)o.len;
            if (at_key) {
                /* cut back to before the preceding comma, if any */
                size_t i = o.len;
                while (i > 0 && isspace((unsigned char)o.p[i - 1])) i--;
                before = (i > 0 && o.p[i - 1] == ',') ? (long)(i - 1) : (long)o.len;
            }
            put(&o, '"');
            p += adv;
            int closed = 0;
            while (*p) {
                int a2 = 1;
                char sq2 = smart_quote((const unsigned char *)p, &a2);
                char d = sq2 ? sq2 : *p;
                if (d == '\\' && p[1]) {
                    if (q == '\'' && p[1] == '\'') { put(&o, '\''); p += 2; continue; }
                    put(&o, '\\'); put(&o, p[1]); p += 2; continue;
                }
                if (d == q) { p += a2; closed = 1; break; }
                if (q == '\'' && d == '"') { puts_(&o, "\\\""); p += a2; continue; }
                if (sq2 && sq2 == '"' && q == '"') { /* smart close inside a straight string */
                    p += a2; closed = 1; changed = 1; break;
                }
                if (*p == '\n') { puts_(&o, "\\n"); p++; changed = 1; continue; }
                if (*p == '\t') { puts_(&o, "\\t"); p++; changed = 1; continue; }
                if ((unsigned char)*p < 0x20) { p++; changed = 1; continue; }
                put(&o, *p); p++;
            }
            put(&o, '"');
            if (!closed) changed = 1;
            if (at_key) { key_cut = before; expect_key = 0; }
            else key_cut = -1;
            continue;
        }

        if (c == '{' || c == '[') {
            if (depth >= (int)sizeof stack) return -1;
            stack[depth++] = c;
            put(&o, c);
            expect_key = c == '{';
            key_cut = -1;
            p += adv;
            continue;
        }
        if (c == '}' || c == ']') {
            char want = c == '}' ? '{' : '[';
            if (depth == 0) { p += adv; changed = 1; continue; }
            if (key_cut >= 0) { o.len = (size_t)key_cut; o.p[o.len] = '\0'; key_cut = -1; changed = 1; }
            if (last_sig(&o) == ':') { puts_(&o, "null"); changed = 1; }
            if (last_sig(&o) == ',') { drop_trailing_comma(&o); changed = 1; }
            /* mismatched closer: close what is open until it matches */
            while (depth > 0 && stack[depth - 1] != want) {
                put(&o, stack[depth - 1] == '{' ? '}' : ']');
                depth--;
                changed = 1;
            }
            if (depth > 0) { put(&o, c); depth--; }
            p += adv;
            expect_key = 0;
            if (depth == 0) break;   /* the first object is complete */
            continue;
        }
        if (c == ',') {
            if (last_sig(&o) == ',' || last_sig(&o) == '{' || last_sig(&o) == '[') { changed = 1; p += adv; continue; }
            put(&o, ',');
            expect_key = depth > 0 && stack[depth - 1] == '{';
            p += adv;
            continue;
        }
        if (c == ':') {
            put(&o, ':');
            key_cut = -1;
            expect_key = 0;
            p += adv;
            continue;
        }
        if (isspace((unsigned char)c)) { p += adv; continue; }
        if (is_bare(c)) {
            const char *w = p;
            while (*p && is_bare(*p)) p++;
            size_t n = (size_t)(p - w);
            if (expect_key && depth > 0 && stack[depth - 1] == '{' && *p == '\0' && !next_is_colon(p)) {
                changed = 1;   /* a key cut off before its colon */
                continue;
            }
            int at_key = expect_key && depth > 0 && stack[depth - 1] == '{' && next_is_colon(p);
            if (at_key) {
                put(&o, '"');
                for (size_t i = 0; i < n; i++) put(&o, w[i]);
                put(&o, '"');
                changed = 1;
                expect_key = 0;
                continue;
            }
            int at_end = *p == '\0';
            if ((n == 4 && !strncmp(w, "true", 4)) || (n == 5 && !strncmp(w, "false", 5)) ||
                (n == 4 && !strncmp(w, "null", 4))) {
                for (size_t i = 0; i < n; i++) put(&o, w[i]);
            } else if ((n == 4 && !strncmp(w, "True", 4)) || (at_end && n < 4 && !strncmp("true", w, n))) {
                puts_(&o, "true"); changed = 1;
            } else if ((n == 5 && !strncmp(w, "False", 5)) || (at_end && n < 5 && !strncmp("false", w, n))) {
                puts_(&o, "false"); changed = 1;
            } else if ((n == 4 && (!strncmp(w, "None", 4) || !strncmp(w, "NULL", 4) || !strncmp(w, "Null", 4))) ||
                       (n == 9 && !strncmp(w, "undefined", 9)) || (at_end && n < 4 && !strncmp("null", w, n))) {
                puts_(&o, "null"); changed = 1;
            } else if (looks_numeric(w, n)) {
                for (size_t i = 0; i < n; i++) put(&o, w[i]);
                if (w[n - 1] == '.' || w[n - 1] == '-' || w[n - 1] == 'e' || w[n - 1] == 'E') { put(&o, '0'); changed = 1; }
            } else {
                /* a bare word where a value goes: keep it as a string */
                put(&o, '"');
                for (size_t i = 0; i < n; i++) put(&o, w[i]);
                put(&o, '"');
                changed = 1;
            }
            key_cut = -1;
            continue;
        }
        /* anything else outside a string is noise */
        p += adv;
        changed = 1;
    }

    if (depth > 0) {
        changed = 1;
        if (key_cut >= 0) { o.len = (size_t)key_cut; o.p[o.len] = '\0'; }
        if (last_sig(&o) == ':') puts_(&o, "null");
        drop_trailing_comma(&o);
        while (depth > 0) {
            put(&o, stack[depth - 1] == '{' ? '}' : ']');
            depth--;
        }
    }
    if (o.overflow) return -2;
    return changed ? 1 : 0;
}

/* ------------------------------------------------------- Warden check */
void spk_warden_clean(const char *raw, char *out, size_t cap) {
    if (!out || cap == 0) return;
    out[0] = '\0';
    if (!raw) return;
    size_t n = strlen(raw);
    const char *stops[] = { "<|im_end|>", "<|im_start|>", "\n" };
    for (int i = 0; i < 3; i++) {
        const char *f = strstr(raw, stops[i]);
        if (f && (size_t)(f - raw) < n) n = (size_t)(f - raw);
    }
    const char *b = raw, *e = raw + n;
    while (b < e && isspace((unsigned char)*b)) b++;
    while (e > b && isspace((unsigned char)e[-1])) e--;
    if (e - b > 2 && *b == '"' && e[-1] == '"') { b++; e--; }
    size_t len = (size_t)(e - b);
    if (len >= cap) len = cap - 1;
    memcpy(out, b, len);
    out[len] = '\0';
}

static const char *NUMWORDS[] = {
    "zero", "one", "two", "three", "four", "five", "six", "seven", "eight", "nine", "ten",
    "eleven", "twelve", "thirteen", "fourteen", "fifteen", "sixteen", "seventeen",
    "eighteen", "nineteen", "twenty"
};

/* Collect the numbers in text (digits with thousands commas removed, and
 * number words) into nums[]; returns the count. */
static int numbers_in(const char *text, long *nums, int max) {
    int k = 0;
    const char *p = text;
    while (*p && k < max) {
        if (isdigit((unsigned char)*p)) {
            long v = 0;
            while (*p && (isdigit((unsigned char)*p) || (*p == ',' && isdigit((unsigned char)p[1])))) {
                if (*p != ',') v = v * 10 + (*p - '0');
                p++;
            }
            nums[k++] = v;
            continue;
        }
        if (isalpha((unsigned char)*p)) {
            char w[24];
            int n = 0;
            while (*p && isalpha((unsigned char)*p)) {
                if (n < 23) w[n++] = (char)tolower((unsigned char)*p);
                p++;
            }
            w[n] = '\0';
            for (int i = 0; i <= 20; i++)
                if (!strcmp(w, NUMWORDS[i])) { nums[k++] = i; break; }
            if (!strcmp(w, "thirty")) nums[k++] = 30;
            else if (!strcmp(w, "forty")) nums[k++] = 40;
            else if (!strcmp(w, "fifty")) nums[k++] = 50;
            else if (!strcmp(w, "hundred")) nums[k++] = 100;
            continue;
        }
        p++;
    }
    return k;
}

static int ci_contains(const char *hay, const char *needle) {
    size_t n = strlen(needle);
    if (n == 0) return 1;
    for (const char *h = hay; *h; h++)
        if (strncasecmp(h, needle, n) == 0) return 1;
    return 0;
}

/* Decode one UTF-8 code point; returns bytes consumed (>= 1). */
static int utf8_next(const unsigned char *s, unsigned *cp) {
    if (s[0] < 0x80) { *cp = s[0]; return 1; }
    if ((s[0] & 0xE0) == 0xC0 && s[1]) { *cp = ((s[0] & 0x1F) << 6) | (s[1] & 0x3F); return 2; }
    if ((s[0] & 0xF0) == 0xE0 && s[1] && s[2]) { *cp = ((s[0] & 0x0F) << 12) | ((s[1] & 0x3F) << 6) | (s[2] & 0x3F); return 3; }
    if ((s[0] & 0xF8) == 0xF0 && s[1] && s[2] && s[3]) {
        *cp = ((s[0] & 0x07) << 18) | ((s[1] & 0x3F) << 12) | ((s[2] & 0x3F) << 6) | (s[3] & 0x3F);
        return 4;
    }
    *cp = 0xFFFD;
    return 1;
}

int spk_warden_check(const char *text, const char *moment, const char *input,
                     const char *place, int max_words, char *why, size_t why_len) {
#define FAIL(...) do { if (why && why_len) snprintf(why, why_len, __VA_ARGS__); return 1; } while (0)
    if (why && why_len) why[0] = '\0';
    if (!text) FAIL("empty");
    if (!moment) moment = "";
    int words = 0, in = 0;
    for (const char *p = text; *p; p++) {
        if (isspace((unsigned char)*p)) in = 0;
        else if (!in) { in = 1; words++; }
    }
    int limit = max_words > 0 ? max_words
              : (!strcmp(moment, "recap") ? 45 : (!strcmp(moment, "legend") ? 32 : 18));
    if (words < 4) FAIL("too short");
    if (words > limit) FAIL("too long (%d)", words);
    if (strchr(text, '"') || strchr(text, '#') || strchr(text, '*')) FAIL("markup");
    /* Qwen is bilingual underneath: anything beyond Latin letters and general
     * punctuation (this also catches emoji) is refused. */
    for (const unsigned char *u = (const unsigned char *)text; *u;) {
        unsigned cp;
        u += utf8_next(u, &cp);
        if (cp > 0x24F && !(cp >= 0x2000 && cp <= 0x206F)) FAIL("non-Latin script");
    }
    long allowed[128], got[64];
    int na = numbers_in(input ? input : "", allowed, 120);
    for (long v = 1; v <= 5; v++) allowed[na++] = v;
    int ng = numbers_in(text, got, 64);
    for (int i = 0; i < ng; i++) {
        int ok = 0;
        for (int j = 0; j < na && !ok; j++) ok = allowed[j] == got[i];
        if (!ok) FAIL("invented numbers [%ld]", got[i]);
    }
    const char *banned[] = { "prize", "money", "cash", "bet ", "$", "<think", "as an ai", "i'm an ai" };
    for (size_t i = 0; i < sizeof banned / sizeof *banned; i++)
        if (ci_contains(text, banned[i])) FAIL("banned: %s", banned[i]);
    if (!strcmp(moment, "arrive") && place && *place) {
        char head[64];
        size_t n = 0;
        while (place[n] && place[n] != ' ' && n < sizeof head - 1) { head[n] = place[n]; n++; }
        head[n] = '\0';
        if (!ci_contains(text, head)) FAIL("arrive without the place");
    }
    return 0;
#undef FAIL
}
