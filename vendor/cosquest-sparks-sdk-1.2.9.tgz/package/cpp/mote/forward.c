/* forward.c — one token through the network.
 *
 * This is the heart of mote: the Llama forward pass, written out by hand. Each
 * block is pre-norm: RMSNorm, attention, add to the residual; RMSNorm, a SwiGLU
 * feed-forward, add. Rotary embeddings go straight onto the query and key
 * vectors, and a KV cache means each new token only attends over history.
 *
 * Norms, attention, and the activations stay fp32 in both paths. Only the eight
 * big matmuls change: quantized checkpoints quantize the activation on the fly
 * and run integer arithmetic (int8 x int8, or int8 x int4 for the packed
 * format), which is where all the size and, on a chip, all the speed come from.
 */
#include "model.h"
#include "parallel.h"

#include <math.h>
#include <stdlib.h>
#include <string.h>

#if defined(__ARM_NEON)
#include <arm_neon.h>
#endif
#if defined(__wasm_simd128__)
#include <wasm_simd128.h>
#endif

static void rmsnorm(float *out, const float *x, const float *weight, int size, float eps)
{
    float ss = 0.0f;
    for (int i = 0; i < size; i++)
        ss += x[i] * x[i];
    ss = 1.0f / sqrtf(ss / size + eps);
    for (int i = 0; i < size; i++)
        out[i] = weight[i] * (ss * x[i]);
}

/* Qwen3 per-head QK-norm: RMSNorm each head of a q/k vector over head_size, in
 * place, sharing one gain across heads. The gain is stored in mote's interleaved
 * layout, matching the projected vector, so the element-wise multiply lines up
 * and the mean-of-squares is order-invariant. */
static void head_rmsnorm(float *vec, const float *gain, int n_heads, int head_size, float eps)
{
    for (int h = 0; h < n_heads; h++) {
        float *p = vec + (long)h * head_size;
        float ss = 0.0f;
        for (int i = 0; i < head_size; i++)
            ss += p[i] * p[i];
        ss = 1.0f / sqrtf(ss / head_size + eps);
        for (int i = 0; i < head_size; i++)
            p[i] = gain[i] * (ss * p[i]);
    }
}

static void softmax(float *x, int size)
{
    float max = x[0];
    for (int i = 1; i < size; i++)
        if (x[i] > max) max = x[i];
    float sum = 0.0f;
    for (int i = 0; i < size; i++) {
        x[i] = expf(x[i] - max);
        sum += x[i];
    }
    for (int i = 0; i < size; i++)
        x[i] /= sum;
}

static inline float dot_f32(const float *a, const float *b, int n)
{
#if defined(__ARM_NEON)
    float32x4_t acc = vdupq_n_f32(0.0f);
    int i = 0;
    for (; i + 4 <= n; i += 4)
        acc = vfmaq_f32(acc, vld1q_f32(a + i), vld1q_f32(b + i));
    float sum = vaddvq_f32(acc);
    for (; i < n; i++)
        sum += a[i] * b[i];
    return sum;
#elif defined(__wasm_simd128__)
    v128_t acc = wasm_f32x4_splat(0.0f);
    int i = 0;
    for (; i + 4 <= n; i += 4)
        acc = wasm_f32x4_add(acc, wasm_f32x4_mul(wasm_v128_load(a + i),
                                                 wasm_v128_load(b + i)));
    float sum = wasm_f32x4_extract_lane(acc, 0) + wasm_f32x4_extract_lane(acc, 1)
              + wasm_f32x4_extract_lane(acc, 2) + wasm_f32x4_extract_lane(acc, 3);
    for (; i < n; i++)
        sum += a[i] * b[i];
    return sum;
#else
    float sum = 0.0f;
    for (int i = 0; i < n; i++)
        sum += a[i] * b[i];
    return sum;
#endif
}

/* Largest head width the RoPE table covers (head_dim / 2 slots); mote's
 * models use 64 or 128. */
#define ROPE_MAX_HALF 256

typedef struct { float *out; const float *x, *w; int n; } MatmulF32;

static void matmul_f32_range(int begin, int end, void *vctx)
{
    const MatmulF32 *c = (const MatmulF32 *)vctx;
    for (int i = begin; i < end; i++)
        c->out[i] = dot_f32(c->x, c->w + (long)i * c->n, c->n);
}

static void matmul_f32(float *out, const float *x, const float *w, int n, int d)
{
    MatmulF32 ctx = { out, x, w, n };
    /* only thread when the work is worth the dispatch overhead (see quant.c) */
    if ((long)d * n >= (1 << 18))
        mote_parallel_for(d, matmul_f32_range, &ctx);
    else
        matmul_f32_range(0, d, &ctx);
}

/* out(d) = W(d, n) . in(n), taking the right path for this checkpoint. For fp32,
 * `wf` is the weight base and `off` selects this layer's row 0; for quantized,
 * the activation is quantized into scratch and int8 matmul runs at `off`. */
static void mm(Transformer *t, float *out, float *in, int n, int d,
               const float *wf, const QTensor *wq, long off)
{
    if (t->quantized) {
        quantize(&t->state.xq, in, n, t->gs);
        if (t->qbits == 4)
            matmul_q4(out, &t->state.xq, wq, off, n, d, t->gs);
        else
            matmul_q8(out, &t->state.xq, wq, off, n, d, t->gs);
    } else {
        matmul_f32(out, in, wf + off, n, d);
    }
}

/* seed a residual stream with a token's embedding */
static void embed_token(Transformer *t, int token, float *x)
{
    const Weights *w = &t->weights;
    int dim = t->config.dim;
    if (t->quantized) {
        long qoff = (long)token * dim;   /* element offset of this token's row */
        QTensor row = { .q = w->q_tokens.q + (t->qbits == 4 ? qoff / 2 : qoff),
                        .s = w->q_tokens.s + qoff / t->gs };
        if (t->qbits == 4)
            dequantize_q4(&row, x, dim, t->gs);
        else
            dequantize(&row, x, dim, t->gs);
    } else {
        memcpy(x, w->token_embedding + (long)token * dim, dim * sizeof(float));
    }
}

/* RoPE angles for one position: the same expressions the per-layer loop used
 * to evaluate for every element of every layer (28 x 1,024 powf, cosf and
 * sinf per token on Qwen3-0.6B), now once per pair slot of a head. */
static void rope_table(const Transformer *t, int pos, float *rc, float *rs)
{
    int head_size = t->head_dim;
    for (int hd = 0; hd < head_size && hd / 2 < ROPE_MAX_HALF; hd += 2) {
        float freq = 1.0f / powf(t->rope_theta, hd / (float)head_size);
        float val = pos * freq;
        rc[hd / 2] = cosf(val);
        rs[hd / 2] = sinf(val);
    }
}


typedef struct { RunState *s; const float *q_all; float *out; long loff; int pos, head_size, kv_dim, kv_mul, seq_len; } AttCtx;
static void softmax(float *x, int size);
static void attend_heads(int h0, int h1, void *vctx)
{
    AttCtx *c = vctx;
    for (int h = h0; h < h1; h++) {
        const float *q = c->q_all + h * c->head_size;
        float *att = c->s->att + (long)h * c->seq_len;
        for (int tt = 0; tt <= c->pos; tt++) {
            const float *kt = c->s->key_cache + c->loff + (long)tt * c->kv_dim + (h / c->kv_mul) * c->head_size;
            float score = 0.0f;
            for (int i = 0; i < c->head_size; i++) score += q[i] * kt[i];
            att[tt] = score / sqrtf((float)c->head_size);
        }
        softmax(att, c->pos + 1);
        float *xb = c->out + h * c->head_size;
        memset(xb, 0, c->head_size * sizeof(float));
        for (int tt = 0; tt <= c->pos; tt++) {
            const float *vt = c->s->value_cache + c->loff + (long)tt * c->kv_dim + (h / c->kv_mul) * c->head_size;
            float a = att[tt];
            for (int i = 0; i < c->head_size; i++) xb[i] += a * vt[i];
        }
    }
}

/* Layer l's attention for one token at `pos`, after its q, k, v projections:
 * bias, QK-norm, RoPE, then attention over positions [0, pos] of the KV cache
 * (k and v are this token's slots in it). Writes the n_heads x head_size
 * output to `out`. */
static void attend(Transformer *t, int l, int pos, float *q_all, float *k, float *v,
                   float *out, const float *rope_cos, const float *rope_sin)
{
    const Config *p = &t->config;
    const Weights *w = &t->weights;
    RunState *s = &t->state;
    int kv_mul = p->n_heads / p->n_kv_heads;
    /* A head is dim / n_heads wide unless the checkpoint says otherwise (.mq v5;
     * Qwen3-0.6B runs 16 heads of 128 over a 1024-wide stream). The query and
     * the attention output are n_heads heads wide, k and v n_kv_heads; wq maps
     * dim -> q_dim and wo maps q_dim back to dim. With the default head_size
     * every width below is the one this code always used. */
    int head_size = t->head_dim;
    int q_dim = p->n_heads * head_size;
    int kv_dim = p->n_kv_heads * head_size;
    long loff = (long)l * p->seq_len * kv_dim;

    /* Qwen-style attention bias, added to the projections before RoPE. The
     * converter permutes bq/bk to match mote's interleaved rotary layout. */
    if (t->has_qkv_bias) {
        const float *bq = w->bq + (long)l * q_dim;
        const float *bk = w->bk + (long)l * kv_dim;
        const float *bv = w->bv + (long)l * kv_dim;
        for (int i = 0; i < q_dim; i++)  q_all[i] += bq[i];
        for (int i = 0; i < kv_dim; i++) { k[i] += bk[i]; v[i] += bv[i]; }
    }

    /* Qwen3 QK-norm: normalize each query and key head before RoPE. v is
     * left untouched, exactly as in the reference implementation. */
    if (t->has_qk_norm) {
        head_rmsnorm(q_all, w->q_norm + (long)l * head_size, p->n_heads, head_size, t->rms_eps);
        head_rmsnorm(k,     w->k_norm + (long)l * head_size, p->n_kv_heads, head_size, t->rms_eps);
    }

    /* rotary position embedding on q and (within kv range) k */
    for (int i = 0; i < q_dim; i += 2) {
        int hd = i % head_size;           /* position within this head */
        float fcr, fci;
        if (hd / 2 < ROPE_MAX_HALF) {
            fcr = rope_cos[hd / 2];
            fci = rope_sin[hd / 2];
        } else {                          /* wider than any model today */
            float val = pos * (1.0f / powf(t->rope_theta, hd / (float)head_size));
            fcr = cosf(val);
            fci = sinf(val);
        }
        int rotn = i < kv_dim ? 2 : 1;
        for (int r = 0; r < rotn; r++) {
            float *vec = r == 0 ? q_all : k;
            float v0 = vec[i], v1 = vec[i + 1];
            vec[i]     = v0 * fcr - v1 * fci;
            vec[i + 1] = v0 * fci + v1 * fcr;
        }
    }

    AttCtx ac = { s, q_all, out, loff, pos, head_size, kv_dim, kv_mul, p->seq_len };
    mote_parallel_for(p->n_heads, attend_heads, &ac);   /* heads across the thread pool: phones have no OpenMP (2.1x faster first token at 2,048 tokens) */
}

static void silu_mul(float *hb, const float *hb2, int n)
{
    for (int i = 0; i < n; i++) {
        float val = hb[i];
        val *= 1.0f / (1.0f + expf(-val));   /* SiLU */
        val *= hb2[i];
        hb[i] = val;
    }
}

/* One token through every layer, writing its KV at `pos`; the residual
 * stream is left in state.x (before the final norm). */
static void forward_layers(Transformer *t, int token, int pos)
{
    const Config *p = &t->config;
    const Weights *w = &t->weights;
    RunState *s = &t->state;

    int dim = p->dim;
    int head_size = t->head_dim;
    int q_dim = p->n_heads * head_size;
    int kv_dim = p->n_kv_heads * head_size;
    int hidden_dim = p->hidden_dim;
    float *x = s->x;

    embed_token(t, token, x);
    float rope_cos[ROPE_MAX_HALF], rope_sin[ROPE_MAX_HALF];
    rope_table(t, pos, rope_cos, rope_sin);

    for (int l = 0; l < p->n_layers; l++) {
        /* ---- attention ---- */
        rmsnorm(s->xb, x, w->rms_att + (long)l * dim, dim, t->rms_eps);

        long loff = (long)l * p->seq_len * kv_dim;
        float *k = s->key_cache + loff + (long)pos * kv_dim;
        float *v = s->value_cache + loff + (long)pos * kv_dim;

        if (t->quantized) {
            /* q, k, v share the input: quantize it once, one dispatch */
            quantize(&s->xq, s->xb, dim, t->gs);
            QSeg seg[3] = {
                { s->q, &w->q_wq, (long)l * dim * q_dim,  q_dim },
                { k,    &w->q_wk, (long)l * dim * kv_dim, kv_dim },
                { v,    &w->q_wv, (long)l * dim * kv_dim, kv_dim },
            };
            matmul_q_multi(&s->xq, dim, t->gs, t->qbits, seg, 3);
        } else {
            mm(t, s->q, s->xb, dim, q_dim,   w->wq, &w->q_wq, (long)l * dim * q_dim);
            mm(t, k,    s->xb, dim, kv_dim,  w->wk, &w->q_wk, (long)l * dim * kv_dim);
            mm(t, v,    s->xb, dim, kv_dim,  w->wv, &w->q_wv, (long)l * dim * kv_dim);
        }

        attend(t, l, pos, s->q, k, v, s->xb, rope_cos, rope_sin);

        mm(t, s->xb2, s->xb, q_dim, dim, w->wo, &w->q_wo, (long)l * q_dim * dim);
        for (int i = 0; i < dim; i++)
            x[i] += s->xb2[i];

        /* ---- feed-forward: SwiGLU, w2( silu(w1 x) * (w3 x) ) ---- */
        rmsnorm(s->xb, x, w->rms_ffn + (long)l * dim, dim, t->rms_eps);
        if (t->quantized) {
            quantize(&s->xq, s->xb, dim, t->gs);
            QSeg seg[2] = {
                { s->hb,  &w->q_w1, (long)l * dim * hidden_dim, hidden_dim },
                { s->hb2, &w->q_w3, (long)l * dim * hidden_dim, hidden_dim },
            };
            matmul_q_multi(&s->xq, dim, t->gs, t->qbits, seg, 2);
        } else {
            mm(t, s->hb,  s->xb, dim, hidden_dim, w->w1, &w->q_w1, (long)l * dim * hidden_dim);
            mm(t, s->hb2, s->xb, dim, hidden_dim, w->w3, &w->q_w3, (long)l * dim * hidden_dim);
        }
        silu_mul(s->hb, s->hb2, hidden_dim);
        mm(t, s->xb, s->hb, hidden_dim, dim, w->w2, &w->q_w2, (long)l * hidden_dim * dim);
        for (int i = 0; i < dim; i++)
            x[i] += s->xb[i];
    }
}

float *forward(Transformer *t, int token, int pos)
{
    const Weights *w = &t->weights;
    RunState *s = &t->state;
    int dim = t->config.dim;
    forward_layers(t, token, pos);
    rmsnorm(s->x, s->x, w->rms_final, dim, t->rms_eps);
    mm(t, s->logits, s->x, dim, t->config.vocab_size, w->wcls, &w->q_wcls, 0);
    return s->logits;
}

/* A prompt token whose logits nobody reads (every prompt token but the
 * last): the layers and the KV cache only. Skips the classifier, which on a
 * Qwen3-0.6B (vocab 151,936 x 1,024) is about a quarter of each token's
 * work. state.x is NOT normalized afterwards; call forward() when the final
 * hidden state or the logits are needed. */
void forward_prefill(Transformer *t, int token, int pos)
{
    forward_layers(t, token, pos);
}

/* ---- batched prefill ----
 * Scratch for up to MOTE_PREFILL_BATCH tokens, allocated on first use. */
struct MoteBatch {
    int cap;
    float *x, *xb, *xb2, *q, *hb, *hb2;   /* cap rows each              */
    int8_t *xq;                            /* cap x widest activation    */
    float *xs;
    int xw;                                /* widest activation (row stride of xq) */
};

static struct MoteBatch *batch_scratch(Transformer *t)
{
    if (t->batch) return t->batch;
    const Config *p = &t->config;
    int q_dim = p->n_heads * t->head_dim;
    int xb_dim = q_dim > p->dim ? q_dim : p->dim;
    int xw = p->hidden_dim > xb_dim ? p->hidden_dim : xb_dim;
    int cap = MOTE_PREFILL_BATCH;
    struct MoteBatch *b = calloc(1, sizeof *b);
    if (!b) return NULL;
    b->cap = cap;
    b->xw = xw;
    b->x   = malloc(sizeof(float) * (size_t)cap * p->dim);
    b->xb  = malloc(sizeof(float) * (size_t)cap * xb_dim);
    b->xb2 = malloc(sizeof(float) * (size_t)cap * p->dim);
    b->q   = malloc(sizeof(float) * (size_t)cap * q_dim);
    b->hb  = malloc(sizeof(float) * (size_t)cap * p->hidden_dim);
    b->hb2 = malloc(sizeof(float) * (size_t)cap * p->hidden_dim);
    b->xq  = malloc((size_t)cap * xw);
    b->xs  = malloc(sizeof(float) * (size_t)cap * (xw / t->gs));
    if (!b->x || !b->xb || !b->xb2 || !b->q || !b->hb || !b->hb2 || !b->xq || !b->xs) {
        t->batch = b;
        forward_batch_free(t);
        return NULL;
    }
    t->batch = b;
    return b;
}

void forward_batch_free(Transformer *t)
{
    struct MoteBatch *b = t->batch;
    if (!b) return;
    free(b->x); free(b->xb); free(b->xb2); free(b->q);
    free(b->hb); free(b->hb2); free(b->xq); free(b->xs);
    free(b);
    t->batch = NULL;
}

/* quantize nb rows of width n (row stride `stride` floats) into the batch's
 * int8 scratch, row b at xq + b * n */
static void quantize_rows(struct MoteBatch *bs, const float *x, long stride, int nb, int n, int gs)
{
    for (int b = 0; b < nb; b++) {
        QTensor q = { bs->xq + (long)b * n, bs->xs + (long)b * (n / gs) };
        quantize(&q, x + b * stride, n, gs);
    }
}

void forward_prefill_batch(Transformer *t, const int *tokens, int nb, int pos0)
{
    struct MoteBatch *bs = (t->quantized && nb > 1) ? batch_scratch(t) : NULL;
    if (!bs) {   /* fp32 checkpoints, one token, or no memory: one at a time */
        for (int b = 0; b < nb; b++)
            forward_layers(t, tokens[b], pos0 + b);
        return;
    }
    while (nb > bs->cap) {   /* longer than the scratch: in pieces */
        forward_prefill_batch(t, tokens, bs->cap, pos0);
        tokens += bs->cap; pos0 += bs->cap; nb -= bs->cap;
    }

    const Config *p = &t->config;
    const Weights *w = &t->weights;
    RunState *s = &t->state;
    int dim = p->dim, gs = t->gs, qb = t->qbits;
    int head_size = t->head_dim;
    int q_dim = p->n_heads * head_size;
    int kv_dim = p->n_kv_heads * head_size;
    int xb_dim = q_dim > dim ? q_dim : dim;
    int hidden_dim = p->hidden_dim;

    float rope_cos[MOTE_PREFILL_BATCH][ROPE_MAX_HALF], rope_sin[MOTE_PREFILL_BATCH][ROPE_MAX_HALF];
    for (int b = 0; b < nb; b++) {
        embed_token(t, tokens[b], bs->x + (long)b * dim);
        rope_table(t, pos0 + b, rope_cos[b], rope_sin[b]);
    }

    for (int l = 0; l < p->n_layers; l++) {
        long loff = (long)l * p->seq_len * kv_dim;
        float *kc = s->key_cache + loff + (long)pos0 * kv_dim;     /* token b's k at kc + b * kv_dim */
        float *vc = s->value_cache + loff + (long)pos0 * kv_dim;

        /* ---- attention: q, k, v for every token, then attention in order
         * (token b sees the KV of tokens < b, already in the cache) ---- */
        for (int b = 0; b < nb; b++)
            rmsnorm(bs->xb + (long)b * xb_dim, bs->x + (long)b * dim, w->rms_att + (long)l * dim, dim, t->rms_eps);
        quantize_rows(bs, bs->xb, xb_dim, nb, dim, gs);
        {
            QSegB seg[3] = {
                { bs->q, q_dim, &w->q_wq, (long)l * dim * q_dim,  q_dim },
                { kc,    kv_dim, &w->q_wk, (long)l * dim * kv_dim, kv_dim },
                { vc,    kv_dim, &w->q_wv, (long)l * dim * kv_dim, kv_dim },
            };
            matmul_q_batch(bs->xq, bs->xs, nb, dim, gs, qb, seg, 3);
        }
        for (int b = 0; b < nb; b++)
            attend(t, l, pos0 + b, bs->q + (long)b * q_dim, kc + (long)b * kv_dim, vc + (long)b * kv_dim,
                   bs->xb + (long)b * xb_dim, rope_cos[b], rope_sin[b]);

        quantize_rows(bs, bs->xb, xb_dim, nb, q_dim, gs);
        {
            QSegB seg[1] = { { bs->xb2, dim, &w->q_wo, (long)l * q_dim * dim, dim } };
            matmul_q_batch(bs->xq, bs->xs, nb, q_dim, gs, qb, seg, 1);
        }
        for (int b = 0; b < nb; b++) {
            float *x = bs->x + (long)b * dim, *o = bs->xb2 + (long)b * dim;
            for (int i = 0; i < dim; i++)
                x[i] += o[i];
        }

        /* ---- feed-forward ---- */
        for (int b = 0; b < nb; b++)
            rmsnorm(bs->xb + (long)b * xb_dim, bs->x + (long)b * dim, w->rms_ffn + (long)l * dim, dim, t->rms_eps);
        quantize_rows(bs, bs->xb, xb_dim, nb, dim, gs);
        {
            QSegB seg[2] = {
                { bs->hb,  hidden_dim, &w->q_w1, (long)l * dim * hidden_dim, hidden_dim },
                { bs->hb2, hidden_dim, &w->q_w3, (long)l * dim * hidden_dim, hidden_dim },
            };
            matmul_q_batch(bs->xq, bs->xs, nb, dim, gs, qb, seg, 2);
        }
        for (int b = 0; b < nb; b++)
            silu_mul(bs->hb + (long)b * hidden_dim, bs->hb2 + (long)b * hidden_dim, hidden_dim);
        quantize_rows(bs, bs->hb, hidden_dim, nb, hidden_dim, gs);
        {
            QSegB seg[1] = { { bs->xb2, dim, &w->q_w2, (long)l * hidden_dim * dim, dim } };
            matmul_q_batch(bs->xq, bs->xs, nb, hidden_dim, gs, qb, seg, 1);
        }
        for (int b = 0; b < nb; b++) {
            float *x = bs->x + (long)b * dim, *o = bs->xb2 + (long)b * dim;
            for (int i = 0; i < dim; i++)
                x[i] += o[i];
        }
    }
    /* like forward_prefill: the last token's residual stream in state.x */
    memcpy(s->x, bs->x + (long)(nb - 1) * dim, sizeof(float) * dim);
}
