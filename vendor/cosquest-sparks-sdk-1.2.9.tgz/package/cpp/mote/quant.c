/* quant.c — the arithmetic behind quant.h. See there for the scheme. */
#include "quant.h"
#include "parallel.h"

#include <math.h>

#if defined(__ARM_NEON)
#include <arm_neon.h>
#endif
#if defined(__wasm_simd128__)
#include <wasm_simd128.h>
#endif

/* Runtime dot-product dispatch (AArch64 builds without +dotprod).
 *
 * The phone builds leave -march=...+dotprod off so one binary runs on every
 * ARMv8.0 core (A11/A12 iPhones, Cortex-A53 Androids). Before this, those
 * builds ran the int8 and int4 dot products as a scalar C loop on EVERY
 * phone, which is what made a 0.6B prefill take about 30 s on a budget
 * Android. Now: a plain-NEON widening path for cores without the instruction,
 * and the SDOT path compiled per function (target attribute) and picked at
 * run time when the CPU reports FEAT_DotProd (Android/Linux HWCAP_ASIMDDP,
 * Apple sysctl hw.optional.arm.FEAT_DotProd). All three are integer
 * arithmetic, so their results are bit-identical. */
#if defined(__aarch64__) && defined(__ARM_NEON) && !defined(__ARM_FEATURE_DOTPROD) && \
    (defined(__clang__) || (defined(__GNUC__) && __GNUC__ >= 10)) && \
    (defined(__linux__) || defined(__ANDROID__) || defined(__APPLE__)) && !defined(MOTE_NO_SDOT_DISPATCH)
#define MOTE_SDOT_DISPATCH 1
#if defined(__APPLE__)
#include <sys/sysctl.h>
#else
#include <sys/auxv.h>
#ifndef HWCAP_ASIMDDP
#define HWCAP_ASIMDDP (1UL << 20)
#endif
#endif
#define MOTE_SDOT_ATTR __attribute__((target("dotprod")))
#endif

#define QMAX 127.0f

void quantize(const QTensor *out, const float *x, int n, int gs)
{
    int groups = n / gs;
    for (int g = 0; g < groups; g++) {
        const float *xg = x + g * gs;

        float wmax = 0.0f;
        for (int i = 0; i < gs; i++) {
            float a = fabsf(xg[i]);
            if (a > wmax) wmax = a;
        }

        float scale = wmax / QMAX;
        out->s[g] = scale;

        int8_t *qg = out->q + g * gs;
        for (int i = 0; i < gs; i++) {
            float v = scale > 0.0f ? xg[i] / scale : 0.0f;
            /* roundf then clamp; the clamp only bites on floating-point slop */
            int q = (int)lroundf(v);
            if (q > 127) q = 127;
            if (q < -127) q = -127;
            qg[i] = (int8_t)q;
        }
    }
}

void dequantize(const QTensor *in, float *x, int n, int gs)
{
    for (int i = 0; i < n; i++)
        x[i] = in->q[i] * in->s[i / gs];
}

/* int32 dot product of two int8 groups. Uses the NEON dot-product instruction
 * where it exists (every recent Apple chip), otherwise a plain loop. The result
 * is bit-identical either way, since it is integer arithmetic. */
static inline int32_t dot_group_i8(const int8_t *a, const int8_t *b, int gs)
{
#if defined(__ARM_NEON) && defined(__ARM_FEATURE_DOTPROD)
    int32x4_t acc = vdupq_n_s32(0);
    int k = 0;
    for (; k + 16 <= gs; k += 16)
        acc = vdotq_s32(acc, vld1q_s8(a + k), vld1q_s8(b + k));
    int32_t sum = vaddvq_s32(acc);
    for (; k < gs; k++)                       /* tail when gs is not a mult of 16 */
        sum += (int32_t)a[k] * (int32_t)b[k];
    return sum;
#elif defined(__ARM_NEON) && defined(__aarch64__)
    /* no SDOT: widen int8 x int8 to int16 (two products per lane fit: at most
     * 2 * 127 * 128 = 32512), then pairwise-add into int32 lanes */
    int32x4_t acc = vdupq_n_s32(0);
    int k = 0;
    for (; k + 16 <= gs; k += 16) {
        int8x16_t va = vld1q_s8(a + k), vb = vld1q_s8(b + k);
        int16x8_t p = vmull_s8(vget_low_s8(va), vget_low_s8(vb));
        p = vmlal_high_s8(p, va, vb);
        acc = vpadalq_s16(acc, p);
    }
    int32_t sum = vaddvq_s32(acc);
    for (; k < gs; k++)
        sum += (int32_t)a[k] * (int32_t)b[k];
    return sum;
#elif defined(__wasm_simd128__)
    /* widen int8 pairs to int16 products, then pairwise-add into int32 lanes */
    v128_t acc = wasm_i32x4_splat(0);
    int k = 0;
    for (; k + 16 <= gs; k += 16) {
        v128_t va = wasm_v128_load(a + k);
        v128_t vb = wasm_v128_load(b + k);
        acc = wasm_i32x4_add(acc, wasm_i32x4_extadd_pairwise_i16x8(
                                      wasm_i16x8_extmul_low_i8x16(va, vb)));
        acc = wasm_i32x4_add(acc, wasm_i32x4_extadd_pairwise_i16x8(
                                      wasm_i16x8_extmul_high_i8x16(va, vb)));
    }
    int32_t sum = wasm_i32x4_extract_lane(acc, 0) + wasm_i32x4_extract_lane(acc, 1)
                + wasm_i32x4_extract_lane(acc, 2) + wasm_i32x4_extract_lane(acc, 3);
    for (; k < gs; k++)
        sum += (int32_t)a[k] * (int32_t)b[k];
    return sum;
#else
    int32_t sum = 0;
    for (int k = 0; k < gs; k++)
        sum += (int32_t)a[k] * (int32_t)b[k];
    return sum;
#endif
}

typedef struct {
    float *out;
    const QTensor *x, *w;
    long woff;
    int n, gs;
} MatmulQ8;

static void matmul_q8_range(int begin, int end, void *vctx)
{
    const MatmulQ8 *c = (const MatmulQ8 *)vctx;
    for (int i = begin; i < end; i++) {
        long in0 = c->woff + (long)i * c->n;      /* row i of the weight tensor */
        float val = 0.0f;
        for (int j = 0; j < c->n; j += c->gs) {
            int32_t sum = dot_group_i8(c->x->q + j, c->w->q + in0 + j, c->gs);
            val += (float)sum * c->x->s[j / c->gs] * c->w->s[(in0 + j) / c->gs];
        }
        c->out[i] = val;
    }
}

#ifdef MOTE_SDOT_DISPATCH
/* The SDOT kernels for the run-time dispatch above: the same loops as
 * matmul_q8_range / matmul_q4_range with the vdotq_s32 dot, compiled for a
 * dotprod core and only ever called on one. */
static int have_sdot(void)
{
    static volatile int cached = -1;   /* the same answer from any thread */
    int v = cached;
    if (v < 0) {
#if defined(__APPLE__)
        int on = 0;
        size_t len = sizeof on;
        v = sysctlbyname("hw.optional.arm.FEAT_DotProd", &on, &len, NULL, 0) == 0 && on ? 1 : 0;
#else
        v = (getauxval(AT_HWCAP) & HWCAP_ASIMDDP) ? 1 : 0;
#endif
        cached = v;
    }
    return v;
}

int mote_quant_kernel(void) { return have_sdot() ? 2 : 1; }

static inline MOTE_SDOT_ATTR int32_t dot_group_i8_sdot(const int8_t *a, const int8_t *b, int gs)
{
    int32x4_t acc = vdupq_n_s32(0);
    int k = 0;
    for (; k + 16 <= gs; k += 16)
        acc = vdotq_s32(acc, vld1q_s8(a + k), vld1q_s8(b + k));
    int32_t sum = vaddvq_s32(acc);
    for (; k < gs; k++)
        sum += (int32_t)a[k] * (int32_t)b[k];
    return sum;
}

static MOTE_SDOT_ATTR void matmul_q8_range_sdot(int begin, int end, void *vctx)
{
    const MatmulQ8 *c = (const MatmulQ8 *)vctx;
    for (int i = begin; i < end; i++) {
        long in0 = c->woff + (long)i * c->n;
        float val = 0.0f;
        for (int j = 0; j < c->n; j += c->gs) {
            int32_t sum = dot_group_i8_sdot(c->x->q + j, c->w->q + in0 + j, c->gs);
            val += (float)sum * c->x->s[j / c->gs] * c->w->s[(in0 + j) / c->gs];
        }
        c->out[i] = val;
    }
}
#else
int mote_quant_kernel(void)
{
#if defined(__ARM_NEON) && defined(__ARM_FEATURE_DOTPROD)
    return 2;
#elif (defined(__ARM_NEON) && defined(__aarch64__)) || defined(__wasm_simd128__)
    return 1;
#else
    return 0;
#endif
}
#endif

/* Below this much work, even chunked thread dispatch costs more than it saves;
 * run the whole thing serial (still vectorized). */
#define PARALLEL_WORK_MIN (1 << 18)

void matmul_q8(float *out, const QTensor *x, const QTensor *w,
               long woff, int n, int d, int gs)
{
    MatmulQ8 ctx = { out, x, w, woff, n, gs };
    void (*range)(int, int, void *) = matmul_q8_range;
#ifdef MOTE_SDOT_DISPATCH
    if (have_sdot()) range = matmul_q8_range_sdot;
#endif
    if ((long)d * n >= PARALLEL_WORK_MIN)
        mote_parallel_for(d, range, &ctx);
    else
        range(0, d, &ctx);
}

/* ---- int4 ---- */

void quantize_q4(const QTensor *out, const float *x, long n, int gs)
{
    int half = gs / 2;
    long groups = n / gs;
    for (long g = 0; g < groups; g++) {
        const float *xg = x + g * gs;

        /* The scale is the group's largest-magnitude weight divided by -8,
         * keeping its sign, so that weight lands exactly on -8 and everything
         * else gets the finer step |max|/8 instead of |max|/7. Measured on
         * TinyStories this one trick is worth more than any clipping scheme
         * tried (2.642 vs 2.764 perplexity against plain [-7,7] rounding).
         *
         * And nothing fancier than plain round-to-nearest, deliberately. A
         * clipped-scale search once lived here; it lowered weight RMS error,
         * changed perplexity by noise (2.640 vs 2.642), and silently broke
         * quantization-aware-trained checkpoints — QAT teaches the weights to
         * survive one exact rounding, so the converter must apply that exact
         * rounding, not a cleverer one. */
        float amax = 0.0f, m = 0.0f;
        for (int i = 0; i < gs; i++) {
            float a = fabsf(xg[i]);
            if (a > amax) { amax = a; m = xg[i]; }
        }
        float scale = m / -8.0f;
        out->s[g] = scale;

        int8_t q[256];               /* gs is small; 256 is far above any real one */
        for (int i = 0; i < gs; i++) {
            int v = scale != 0.0f ? (int)lroundf(xg[i] / scale) : 0;
            if (v > 7) v = 7;
            if (v < -8) v = -8;
            q[i] = (int8_t)v;
        }

        uint8_t *b = (uint8_t *)out->q + g * half;
        for (int k = 0; k < half; k++)
            b[k] = (uint8_t)((q[k] & 0x0F) | (q[k + half] << 4));
    }
}

/* sign-extend the two nibbles of one packed byte */
static inline int nib_lo(uint8_t b) { return (int)((int8_t)(uint8_t)(b << 4)) >> 4; }
static inline int nib_hi(uint8_t b) { return (int)(int8_t)b >> 4; }

void dequantize_q4(const QTensor *in, float *x, int n, int gs)
{
    int half = gs / 2;
    for (long g = 0; g < n / gs; g++) {
        const uint8_t *b = (const uint8_t *)in->q + g * half;
        float s = in->s[g];
        float *xg = x + g * gs;
        for (int k = 0; k < half; k++) {
            xg[k]        = nib_lo(b[k]) * s;
            xg[k + half] = nib_hi(b[k]) * s;
        }
    }
}

/* int32 dot of an int8 activation group against a packed int4 weight group.
 * The split-half packing pays off here: sign-extending the low and high nibbles
 * of a register yields w[0..15] and w[half..half+15] as two contiguous int8
 * vectors, each dotted against its slice of the activation. */
static inline int32_t dot_group_q4(const int8_t *a, const uint8_t *wb, int gs)
{
    int half = gs / 2;
    int32_t sum = 0;
    int k = 0;
#if defined(__ARM_NEON) && defined(__ARM_FEATURE_DOTPROD)
    int32x4_t acc = vdupq_n_s32(0);
    for (; k + 16 <= half; k += 16) {
        int8x16_t b  = vld1q_s8((const int8_t *)wb + k);
        int8x16_t lo = vshrq_n_s8(vshlq_n_s8(b, 4), 4);
        int8x16_t hi = vshrq_n_s8(b, 4);
        acc = vdotq_s32(acc, vld1q_s8(a + k), lo);
        acc = vdotq_s32(acc, vld1q_s8(a + half + k), hi);
    }
    sum = vaddvq_s32(acc);
#elif defined(__ARM_NEON) && defined(__aarch64__)
    /* no SDOT: same unpack, widening multiply (products fit int16 easily) */
    int32x4_t acc = vdupq_n_s32(0);
    for (; k + 16 <= half; k += 16) {
        int8x16_t b  = vld1q_s8((const int8_t *)wb + k);
        int8x16_t lo = vshrq_n_s8(vshlq_n_s8(b, 4), 4);
        int8x16_t hi = vshrq_n_s8(b, 4);
        int8x16_t a0 = vld1q_s8(a + k), a1 = vld1q_s8(a + half + k);
        int16x8_t p = vmull_s8(vget_low_s8(a0), vget_low_s8(lo));
        p = vmlal_high_s8(p, a0, lo);
        p = vmlal_s8(p, vget_low_s8(a1), vget_low_s8(hi));
        p = vmlal_high_s8(p, a1, hi);
        acc = vpadalq_s16(acc, p);
    }
    sum = vaddvq_s32(acc);
#elif defined(__wasm_simd128__)
    /* same split-half unpack as NEON: shifts on i8x16 sign-extend the nibbles */
    v128_t acc = wasm_i32x4_splat(0);
    for (; k + 16 <= half; k += 16) {
        v128_t b  = wasm_v128_load(wb + k);
        v128_t lo = wasm_i8x16_shr(wasm_i8x16_shl(b, 4), 4);
        v128_t hi = wasm_i8x16_shr(b, 4);
        v128_t a0 = wasm_v128_load(a + k);
        v128_t a1 = wasm_v128_load(a + half + k);
        acc = wasm_i32x4_add(acc, wasm_i32x4_extadd_pairwise_i16x8(
                                      wasm_i16x8_extmul_low_i8x16(a0, lo)));
        acc = wasm_i32x4_add(acc, wasm_i32x4_extadd_pairwise_i16x8(
                                      wasm_i16x8_extmul_high_i8x16(a0, lo)));
        acc = wasm_i32x4_add(acc, wasm_i32x4_extadd_pairwise_i16x8(
                                      wasm_i16x8_extmul_low_i8x16(a1, hi)));
        acc = wasm_i32x4_add(acc, wasm_i32x4_extadd_pairwise_i16x8(
                                      wasm_i16x8_extmul_high_i8x16(a1, hi)));
    }
    sum = wasm_i32x4_extract_lane(acc, 0) + wasm_i32x4_extract_lane(acc, 1)
        + wasm_i32x4_extract_lane(acc, 2) + wasm_i32x4_extract_lane(acc, 3);
#endif
    for (; k < half; k++)                     /* tail, and the whole loop when scalar */
        sum += (int32_t)a[k] * nib_lo(wb[k]) + (int32_t)a[k + half] * nib_hi(wb[k]);
    return sum;
}

static void matmul_q4_range(int begin, int end, void *vctx)
{
    const MatmulQ8 *c = (const MatmulQ8 *)vctx;   /* same fields, int4 weights */
    int half = c->gs / 2;
    for (int i = begin; i < end; i++) {
        long in0 = c->woff + (long)i * c->n;      /* element offset of row i */
        const uint8_t *row = (const uint8_t *)c->w->q + in0 / 2;
        float val = 0.0f;
        for (int j = 0; j < c->n; j += c->gs) {
            int32_t sum = dot_group_q4(c->x->q + j, row + (long)(j / c->gs) * half, c->gs);
            val += (float)sum * c->x->s[j / c->gs] * c->w->s[(in0 + j) / c->gs];
        }
        c->out[i] = val;
    }
}

#ifdef MOTE_SDOT_DISPATCH
static inline MOTE_SDOT_ATTR int32_t dot_group_q4_sdot(const int8_t *a, const uint8_t *wb, int gs)
{
    int half = gs / 2;
    int k = 0;
    int32x4_t acc = vdupq_n_s32(0);
    for (; k + 16 <= half; k += 16) {
        int8x16_t b  = vld1q_s8((const int8_t *)wb + k);
        int8x16_t lo = vshrq_n_s8(vshlq_n_s8(b, 4), 4);
        int8x16_t hi = vshrq_n_s8(b, 4);
        acc = vdotq_s32(acc, vld1q_s8(a + k), lo);
        acc = vdotq_s32(acc, vld1q_s8(a + half + k), hi);
    }
    int32_t sum = vaddvq_s32(acc);
    for (; k < half; k++)
        sum += (int32_t)a[k] * nib_lo(wb[k]) + (int32_t)a[k + half] * nib_hi(wb[k]);
    return sum;
}

static MOTE_SDOT_ATTR void matmul_q4_range_sdot(int begin, int end, void *vctx)
{
    const MatmulQ8 *c = (const MatmulQ8 *)vctx;
    int half = c->gs / 2;
    for (int i = begin; i < end; i++) {
        long in0 = c->woff + (long)i * c->n;
        const uint8_t *row = (const uint8_t *)c->w->q + in0 / 2;
        float val = 0.0f;
        for (int j = 0; j < c->n; j += c->gs) {
            int32_t sum = dot_group_q4_sdot(c->x->q + j, row + (long)(j / c->gs) * half, c->gs);
            val += (float)sum * c->x->s[j / c->gs] * c->w->s[(in0 + j) / c->gs];
        }
        c->out[i] = val;
    }
}
#endif

void matmul_q4(float *out, const QTensor *x, const QTensor *w,
               long woff, int n, int d, int gs)
{
    MatmulQ8 ctx = { out, x, w, woff, n, gs };
    void (*range)(int, int, void *) = matmul_q4_range;
#ifdef MOTE_SDOT_DISPATCH
    if (have_sdot()) range = matmul_q4_range_sdot;
#endif
    if ((long)d * n >= PARALLEL_WORK_MIN)
        mote_parallel_for(d, range, &ctx);
    else
        range(0, d, &ctx);
}

/* ---- several matmuls over one activation, in one parallel dispatch ----
 * q, k and v (and w1 and w3) read the same normalized input. Quantizing it
 * once and handing all their rows to the thread pool together saves two
 * quantizations and two pool wake-ups per group (about 84 of the 197 per
 * token on a 28-layer model); on a phone, each wake-up of the pool costs as
 * much as a small matmul. Each output row is still computed by exactly one
 * thread with the same kernel, so the results are unchanged. */
typedef struct {
    const QSeg *segs;
    int nseg, n, gs;
    const QTensor *x;
    void (*range)(int, int, void *);
} MatmulMulti;

static void matmul_multi_range(int begin, int end, void *vctx)
{
    const MatmulMulti *m = (const MatmulMulti *)vctx;
    int base = 0;
    for (int i = 0; i < m->nseg && base < end; i++) {
        const QSeg *sg = &m->segs[i];
        int b = begin > base ? begin : base;
        int e = end < base + sg->d ? end : base + sg->d;
        if (b < e) {
            MatmulQ8 c = { sg->out, m->x, sg->w, sg->woff, m->n, m->gs };
            m->range(b - base, e - base, &c);
        }
        base += sg->d;
    }
}

void matmul_q_multi(const QTensor *x, int n, int gs, int qbits, const QSeg *segs, int nseg)
{
    MatmulMulti m = { segs, nseg, n, gs, x, qbits == 4 ? matmul_q4_range : matmul_q8_range };
#ifdef MOTE_SDOT_DISPATCH
    if (have_sdot()) m.range = qbits == 4 ? matmul_q4_range_sdot : matmul_q8_range_sdot;
#endif
    int total = 0;
    for (int i = 0; i < nseg; i++) total += segs[i].d;
    if ((long)total * n >= PARALLEL_WORK_MIN)
        mote_parallel_for(total, matmul_multi_range, &m);
    else
        matmul_multi_range(0, total, &m);
}

/* ---- batched: the same matmuls over several tokens at once (prefill) ----
 * A prompt's tokens are all known up front, so prefill runs them through
 * each matmul together: every weight row is read from memory once per batch
 * instead of once per token, and the thread pool wakes once per batch. Each
 * (row, token) result is the row kernel's exact arithmetic, in the same
 * order, so a batched prefill writes the same KV cache as token-by-token. */
typedef struct {
    const QSegB *segs;
    int nseg, n, gs, nb;
    const int8_t *xq;     /* token b's activation at xq + b * n          */
    const float *xs;      /* its scales at xs + b * (n / gs)             */
    int q4;
    int sdot;
} MatmulBatch;

#define MOTE_BATCH_ROWS(DOT8, DOT4)                                                   \
    for (int i = b0; i < b1; i++) {                                                   \
        long in0 = sg->woff + (long)i * n;                                            \
        const float *ws = sg->w->s + in0 / gs;                                        \
        for (int b = 0; b < m->nb; b++) {                                             \
            const int8_t *xq = m->xq + (long)b * n;                                   \
            const float *xs = m->xs + (long)b * (n / gs);                             \
            float val = 0.0f;                                                         \
            if (m->q4) {                                                              \
                const uint8_t *row = (const uint8_t *)sg->w->q + in0 / 2;             \
                for (int j = 0; j < n; j += gs) {                                     \
                    int32_t sum = DOT4(xq + j, row + (long)(j / gs) * (gs / 2), gs);  \
                    val += (float)sum * xs[j / gs] * ws[j / gs];                      \
                }                                                                     \
            } else {                                                                  \
                for (int j = 0; j < n; j += gs) {                                     \
                    int32_t sum = DOT8(xq + j, sg->w->q + in0 + j, gs);               \
                    val += (float)sum * xs[j / gs] * ws[j / gs];                      \
                }                                                                     \
            }                                                                         \
            sg->out[(long)b * sg->ostride + i] = val;                                 \
        }                                                                             \
    }

/* rows [b0, b1) of one segment */
static void batch_rows(const MatmulBatch *m, const QSegB *sg, int b0, int b1)
{
    int n = m->n, gs = m->gs;
    MOTE_BATCH_ROWS(dot_group_i8, dot_group_q4)
}

#ifdef MOTE_SDOT_DISPATCH
static MOTE_SDOT_ATTR void batch_rows_sdot(const MatmulBatch *m, const QSegB *sg, int b0, int b1)
{
    int n = m->n, gs = m->gs;
    MOTE_BATCH_ROWS(dot_group_i8_sdot, dot_group_q4_sdot)
}
#endif

static void matmul_batch_range(int begin, int end, void *vctx)
{
    const MatmulBatch *m = (const MatmulBatch *)vctx;
    int base = 0;
    for (int i = 0; i < m->nseg && base < end; i++) {
        const QSegB *sg = &m->segs[i];
        int b = begin > base ? begin : base;
        int e = end < base + sg->d ? end : base + sg->d;
        if (b < e) {
#ifdef MOTE_SDOT_DISPATCH
            if (m->sdot) batch_rows_sdot(m, sg, b - base, e - base);
            else
#endif
            batch_rows(m, sg, b - base, e - base);
        }
        base += sg->d;
    }
}

void matmul_q_batch(const int8_t *xq, const float *xs, int nb, int n, int gs, int qbits,
                    const QSegB *segs, int nseg)
{
    MatmulBatch m = { segs, nseg, n, gs, nb, xq, xs, qbits == 4, 0 };
#ifdef MOTE_SDOT_DISPATCH
    m.sdot = have_sdot();
#endif
    int total = 0;
    for (int i = 0; i < nseg; i++) total += segs[i].d;
    if ((long)total * n * nb >= PARALLEL_WORK_MIN)
        mote_parallel_for(total, matmul_batch_range, &m);
    else
        matmul_batch_range(0, total, &m);
}
