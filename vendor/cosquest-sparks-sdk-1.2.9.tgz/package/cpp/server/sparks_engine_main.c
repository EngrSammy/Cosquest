/* sparks-engine: the Sparks model on a server CPU, as a JSON-lines process.
 *
 * The server fallback worker (apps/server-worker) runs one of these per job
 * slot. It is the same mote engine the phones run, with the phone engine's
 * generation settings (sparks_engine.c): greedy unless told otherwise, the
 * caller's stop string cut out of the text, the task's token cap, and an
 * optional flat JSON schema for mote's grammar. Prompts arrive already
 * rendered by tasks.ts, so they are byte-identical to the phone's.
 *
 *   sparks-engine --model sparks.mq --tokenizer qwen3.mtok [--threads N]
 *
 * stdout, once loaded:
 *   {"ready":true,"load_ms":812,"dim":2048,"n_layers":28,"vocab":151936,"seq_len":4096,"qbits":4,"threads":4}
 * stdin, one request per line:
 *   {"id":1,"prompt":"<|im_start|>system\n...","max_tokens":24,"stop":"\n"}
 *   {"id":2,"system":"...","user":"...","max_tokens":24,"stop":"\n","schema":"{...}"}
 *   {"op":"quit"}
 * stdout, one response per request, same id:
 *   {"id":1,"text":"{\"subject\":\"Raid route\"}","tokens":9,"tokens_in":212,"ms":640.1,"first_token_ms":402.7}
 *   {"id":2,"error":"..."}
 *
 * "system"/"user" are rendered with the Qwen3 chat template, thinking off,
 * exactly as tasks.ts chatPrompt() does. Threads: OpenMP on Linux (--threads
 * or OMP_NUM_THREADS); Grand Central Dispatch on macOS uses every core.
 */
#define _POSIX_C_SOURCE 200809L
#include "mote_lib.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#ifdef _OPENMP
#include <omp.h>
#endif

/* ------------------------------------------------------------ strings */
typedef struct { char *p; size_t len, cap; } sbuf;

static void sb_put(sbuf *b, const char *s, size_t n) {
    if (b->len + n + 1 > b->cap) {
        size_t cap = b->cap ? b->cap : 256;
        while (cap < b->len + n + 1) cap *= 2;
        char *p = realloc(b->p, cap);
        if (!p) { fprintf(stderr, "sparks-engine: out of memory\n"); exit(2); }
        b->p = p; b->cap = cap;
    }
    memcpy(b->p + b->len, s, n);
    b->len += n;
    b->p[b->len] = '\0';
}
static void sb_puts(sbuf *b, const char *s) { sb_put(b, s, strlen(s)); }

static void sb_json_str(sbuf *b, const char *s) {
    sb_put(b, "\"", 1);
    for (const unsigned char *c = (const unsigned char *)s; *c; c++) {
        char esc[8];
        switch (*c) {
        case '"':  sb_put(b, "\\\"", 2); break;
        case '\\': sb_put(b, "\\\\", 2); break;
        case '\n': sb_put(b, "\\n", 2); break;
        case '\r': sb_put(b, "\\r", 2); break;
        case '\t': sb_put(b, "\\t", 2); break;
        default:
            if (*c < 0x20) { snprintf(esc, sizeof esc, "\\u%04x", *c); sb_put(b, esc, 6); }
            else sb_put(b, (const char *)c, 1);
        }
    }
    sb_put(b, "\"", 1);
}

static double now_ms(void) {
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return ts.tv_sec * 1e3 + ts.tv_nsec / 1e6;
}

/* ------------------------------------------------- a flat JSON object
 * Requests are one flat object. Nested values are skipped, not rejected, so a
 * newer worker can send fields this binary does not know. */
typedef struct { const char *s; size_t i, n; } lex;

static void ws(lex *l) { while (l->i < l->n && strchr(" \t\r\n", l->s[l->i])) l->i++; }

static void utf8_put(sbuf *b, unsigned cp) {
    char o[4]; size_t n;
    if (cp < 0x80) { o[0] = (char)cp; n = 1; }
    else if (cp < 0x800) { o[0] = (char)(0xC0 | (cp >> 6)); o[1] = (char)(0x80 | (cp & 0x3F)); n = 2; }
    else if (cp < 0x10000) { o[0] = (char)(0xE0 | (cp >> 12)); o[1] = (char)(0x80 | ((cp >> 6) & 0x3F)); o[2] = (char)(0x80 | (cp & 0x3F)); n = 3; }
    else { o[0] = (char)(0xF0 | (cp >> 18)); o[1] = (char)(0x80 | ((cp >> 12) & 0x3F)); o[2] = (char)(0x80 | ((cp >> 6) & 0x3F)); o[3] = (char)(0x80 | (cp & 0x3F)); n = 4; }
    sb_put(b, o, n);
}

static int hex4(lex *l, unsigned *out) {
    if (l->i + 4 > l->n) return -1;
    unsigned v = 0;
    for (int k = 0; k < 4; k++) {
        char c = l->s[l->i++];
        v <<= 4;
        if (c >= '0' && c <= '9') v |= (unsigned)(c - '0');
        else if (c >= 'a' && c <= 'f') v |= (unsigned)(c - 'a' + 10);
        else if (c >= 'A' && c <= 'F') v |= (unsigned)(c - 'A' + 10);
        else return -1;
    }
    *out = v;
    return 0;
}

/* Parses a string at l->i (on the opening quote) into out (may be NULL to skip). */
static int jstring(lex *l, sbuf *out) {
    if (l->i >= l->n || l->s[l->i] != '"') return -1;
    l->i++;
    while (l->i < l->n) {
        char c = l->s[l->i++];
        if (c == '"') return 0;
        if (c != '\\') { if (out) sb_put(out, &c, 1); continue; }
        if (l->i >= l->n) return -1;
        char e = l->s[l->i++];
        const char *r = NULL;
        switch (e) {
        case '"': r = "\""; break;  case '\\': r = "\\"; break; case '/': r = "/"; break;
        case 'b': r = "\b"; break;  case 'f': r = "\f"; break;  case 'n': r = "\n"; break;
        case 'r': r = "\r"; break;  case 't': r = "\t"; break;
        case 'u': {
            unsigned cp;
            if (hex4(l, &cp)) return -1;
            if (cp >= 0xD800 && cp < 0xDC00 && l->i + 6 <= l->n && l->s[l->i] == '\\' && l->s[l->i + 1] == 'u') {
                unsigned lo; l->i += 2;
                if (hex4(l, &lo)) return -1;
                cp = 0x10000 + ((cp - 0xD800) << 10) + (lo - 0xDC00);
            }
            if (out) utf8_put(out, cp);
            continue;
        }
        default: return -1;
        }
        if (out) sb_puts(out, r);
    }
    return -1;
}

/* Skips any value; returns its [start,end) in the source. */
static int jskip(lex *l, size_t *start, size_t *end) {
    ws(l);
    *start = l->i;
    if (l->i >= l->n) return -1;
    char c = l->s[l->i];
    if (c == '"') { if (jstring(l, NULL)) return -1; }
    else if (c == '{' || c == '[') {
        int depth = 0;
        while (l->i < l->n) {
            char d = l->s[l->i];
            if (d == '"') { if (jstring(l, NULL)) return -1; continue; }
            if (d == '{' || d == '[') depth++;
            if (d == '}' || d == ']') { depth--; if (depth == 0) { l->i++; break; } }
            l->i++;
        }
        if (depth) return -1;
    } else {
        while (l->i < l->n && !strchr(",}] \t\r\n", l->s[l->i])) l->i++;
        if (l->i == *start) return -1;
    }
    *end = l->i;
    return 0;
}

typedef struct {
    sbuf id;           /* raw JSON of "id", echoed back */
    sbuf op, prompt, system, user, stop, schema;
    int has_prompt, has_system, has_user, has_stop, has_schema;
    int max_tokens;
    float temperature, top_p, repeat_penalty;
    unsigned long long seed;
} request;

static void req_free(request *r) {
    free(r->id.p); free(r->op.p); free(r->prompt.p); free(r->system.p);
    free(r->user.p); free(r->stop.p); free(r->schema.p);
}

static int parse_request(const char *line, size_t n, request *r, const char **why) {
    memset(r, 0, sizeof *r);
    r->max_tokens = 256; r->repeat_penalty = 1.0f;
    lex l = { line, 0, n };
    ws(&l);
    if (l.i >= n || line[l.i] != '{') { *why = "request is not a JSON object"; return -1; }
    l.i++;
    for (;;) {
        ws(&l);
        if (l.i < n && line[l.i] == '}') { l.i++; break; }
        sbuf key = {0};
        if (jstring(&l, &key)) { free(key.p); *why = "bad key"; return -1; }
        ws(&l);
        if (l.i >= n || line[l.i] != ':') { free(key.p); *why = "expected ':'"; return -1; }
        l.i++;
        ws(&l);
        const char *k = key.p ? key.p : "";
        sbuf *dst = NULL; int *flag = NULL;
        if (!strcmp(k, "op")) dst = &r->op;
        else if (!strcmp(k, "prompt")) { dst = &r->prompt; flag = &r->has_prompt; }
        else if (!strcmp(k, "system")) { dst = &r->system; flag = &r->has_system; }
        else if (!strcmp(k, "user")) { dst = &r->user; flag = &r->has_user; }
        else if (!strcmp(k, "stop")) { dst = &r->stop; flag = &r->has_stop; }
        else if (!strcmp(k, "schema") || !strcmp(k, "grammar")) { dst = &r->schema; flag = &r->has_schema; }
        if (dst && l.i < n && line[l.i] == '"') {
            if (jstring(&l, dst)) { free(key.p); *why = "bad string"; return -1; }
            if (!dst->p) sb_puts(dst, "");
            if (flag) *flag = 1;
        } else {
            size_t a, b;
            if (jskip(&l, &a, &b)) { free(key.p); *why = "bad value"; return -1; }
            char num[64] = {0};
            size_t len = b - a < sizeof num - 1 ? b - a : sizeof num - 1;
            memcpy(num, line + a, len);
            if (!strcmp(k, "id")) sb_put(&r->id, line + a, b - a);
            else if (!strcmp(k, "max_tokens")) r->max_tokens = atoi(num);
            else if (!strcmp(k, "temperature")) r->temperature = (float)atof(num);
            else if (!strcmp(k, "top_p")) r->top_p = (float)atof(num);
            else if (!strcmp(k, "repeat_penalty")) r->repeat_penalty = (float)atof(num);
            else if (!strcmp(k, "seed")) r->seed = strtoull(num, NULL, 10);
        }
        free(key.p);
        ws(&l);
        if (l.i < n && line[l.i] == ',') { l.i++; continue; }
        if (l.i < n && line[l.i] == '}') { l.i++; break; }
        *why = "expected ',' or '}'";
        return -1;
    }
    return 0;
}

/* --------------------------------------------------------- generation */
typedef struct { sbuf out; int generated, max_tokens, constrained; double t0, first; const char *stop; } gen_state;

/* The phone engine's on_token (sparks_engine.c on_token_run), minus preemption. */
static int on_token(const char *piece, void *user) {
    gen_state *g = user;
    if (g->first <= 0) g->first = now_ms();
    g->generated++;
    sb_puts(&g->out, piece);
    if (g->constrained) return 1;   /* mote owns the budget and the close-out */
    if (g->stop && g->out.p && strstr(g->out.p, g->stop)) return 0;
    if (g->max_tokens > 0 && g->generated >= g->max_tokens) return 0;
    return 1;
}

#define GRAMMAR_CACHE 8
static struct { char *schema; mote_grammar *g; } cache[GRAMMAR_CACHE];
static int cache_next;

static mote_grammar *grammar_for(mote *m, const char *schema, char *err, size_t err_len) {
    for (int i = 0; i < GRAMMAR_CACHE; i++)
        if (cache[i].schema && !strcmp(cache[i].schema, schema)) return cache[i].g;
    mote_grammar *g = mote_grammar_compile(m, schema, err, err_len);
    if (!g) return NULL;
    int slot = cache_next++ % GRAMMAR_CACHE;
    if (cache[slot].g) { mote_grammar_free(cache[slot].g); free(cache[slot].schema); }
    cache[slot].schema = strdup(schema);
    cache[slot].g = g;
    return g;
}

static void respond_error(const request *r, const char *msg) {
    sbuf o = {0};
    sb_puts(&o, "{\"id\":");
    sb_puts(&o, r && r->id.p ? r->id.p : "null");
    sb_puts(&o, ",\"error\":");
    sb_json_str(&o, msg);
    sb_puts(&o, "}\n");
    fwrite(o.p, 1, o.len, stdout);
    fflush(stdout);
    free(o.p);
}

static void handle(mote *m, request *r) {
    sbuf prompt = {0};
    if (r->has_prompt) sb_puts(&prompt, r->prompt.p);
    else if (r->has_user) {
        /* tasks.ts chatPrompt(): Qwen3 template, thinking off. */
        sb_puts(&prompt, "<|im_start|>system\n");
        sb_puts(&prompt, r->has_system ? r->system.p : "");
        sb_puts(&prompt, "<|im_end|>\n<|im_start|>user\n");
        sb_puts(&prompt, r->user.p);
        sb_puts(&prompt, "<|im_end|>\n<|im_start|>assistant\n<think>\n\n</think>\n\n");
    } else { respond_error(r, "need prompt, or system and user"); return; }

    gen_state g = {0};
    g.max_tokens = r->max_tokens;
    g.stop = r->has_stop && r->stop.p && *r->stop.p ? r->stop.p : NULL;
    g.t0 = now_ms();
    mote_params mp = { r->temperature, r->top_p, r->repeat_penalty, r->seed, r->max_tokens };
    int ret;
    if (r->has_schema && r->schema.p && *r->schema.p) {
        char err[256] = {0};
        mote_grammar *gr = grammar_for(m, r->schema.p, err, sizeof err);
        if (!gr) { respond_error(r, *err ? err : "schema did not compile"); free(prompt.p); return; }
        g.constrained = 1;
        ret = mote_generate_constrained(m, prompt.p, &mp, gr, on_token, &g);
    } else {
        ret = mote_generate(m, prompt.p, &mp, on_token, &g);
    }
    double ms = now_ms() - g.t0;
    if (ret < 0) {
        respond_error(r, ret == MOTE_ERR_GRAMMAR_UNSTARTED ? "grammar_unstarted" : "generate failed");
        free(prompt.p); free(g.out.p);
        return;
    }
    if (g.stop && g.out.p) {   /* trim at the stop string, as the phone does */
        char *s = strstr(g.out.p, g.stop);
        if (s) { *s = '\0'; g.out.len = (size_t)(s - g.out.p); }
    }
    sbuf o = {0};
    char nums[160];
    sb_puts(&o, "{\"id\":");
    sb_puts(&o, r->id.p ? r->id.p : "null");
    sb_puts(&o, ",\"text\":");
    sb_json_str(&o, g.out.p ? g.out.p : "");
    snprintf(nums, sizeof nums, ",\"tokens\":%d,\"tokens_in\":%d,\"ms\":%.1f,\"first_token_ms\":%.1f}\n",
             g.generated, (int)(strlen(prompt.p) / 3.6 + 0.5), ms, g.first > 0 ? g.first - g.t0 : ms);
    sb_puts(&o, nums);
    fwrite(o.p, 1, o.len, stdout);
    fflush(stdout);
    free(o.p); free(g.out.p); free(prompt.p);
}

/* ---------------------------------------------------------------- main */
static void usage(void) {
    fprintf(stderr, "usage: sparks-engine --model PATH.mq --tokenizer PATH.mtok [--threads N]\n");
}

int main(int argc, char **argv) {
    const char *model = NULL, *tok = NULL;
    int threads = 0;
    for (int i = 1; i < argc; i++) {
        if (!strcmp(argv[i], "--model") && i + 1 < argc) model = argv[++i];
        else if (!strcmp(argv[i], "--tokenizer") && i + 1 < argc) tok = argv[++i];
        else if (!strcmp(argv[i], "--threads") && i + 1 < argc) threads = atoi(argv[++i]);
        else if (!strcmp(argv[i], "--help") || !strcmp(argv[i], "-h")) { usage(); return 0; }
        else { usage(); return 64; }
    }
    if (!model || !tok) { usage(); return 64; }
#ifdef _OPENMP
    if (threads > 0) omp_set_num_threads(threads);
    threads = omp_get_max_threads();
#endif
    double t0 = now_ms();
    mote *m = mote_create_from_files(model, tok);
    if (!m) {
        const char *why = mote_last_error();
        sbuf o = {0};
        sb_puts(&o, "{\"ready\":false,\"error\":");
        sb_json_str(&o, why ? why : "mote_create_from_files failed");
        sb_puts(&o, "}\n");
        fwrite(o.p, 1, o.len, stdout);
        fflush(stdout);
        return 1;
    }
    mote_info_t info;
    mote_get_info(m, &info);
    printf("{\"ready\":true,\"load_ms\":%.1f,\"dim\":%d,\"n_layers\":%d,\"vocab\":%d,\"seq_len\":%d,\"qbits\":%d,\"threads\":%d}\n",
           now_ms() - t0, info.dim, info.n_layers, info.vocab_size, info.seq_len, info.quantized ? info.qbits : 32, threads);
    fflush(stdout);

    char *line = NULL;
    size_t cap = 0;
    ssize_t n;
    while ((n = getline(&line, &cap, stdin)) >= 0) {
        if (n == 0 || (n == 1 && line[0] == '\n')) continue;
        request r;
        const char *why = NULL;
        if (parse_request(line, (size_t)n, &r, &why)) { respond_error(&r, why); req_free(&r); continue; }
        if (r.op.p && !strcmp(r.op.p, "quit")) { req_free(&r); break; }
        if (r.op.p && !strcmp(r.op.p, "ping")) {
            printf("{\"id\":%s,\"pong\":true}\n", r.id.p ? r.id.p : "null");
            fflush(stdout);
        } else {
            handle(m, &r);
        }
        req_free(&r);
    }
    free(line);
    for (int i = 0; i < GRAMMAR_CACHE; i++) if (cache[i].g) { mote_grammar_free(cache[i].g); free(cache[i].schema); }
    mote_free(m);
    return 0;
}
