// React Native autolinking (CLI and Expo): where the native code is.
// iOS: sparks-sdk.podspec at the package root. Android: android/ (a library
// project with its own CMake build of cpp/), package com.cosquest.sparks,
// TurboModule spec generated from src/NativeSparks.ts (codegenConfig).
module.exports = {
  dependency: {
    platforms: {
      android: {
        sourceDir: 'android',
        packageImportPath: 'import com.cosquest.sparks.SparksPackage;',
        packageInstance: 'new SparksPackage()',
      },
    },
  },
};
