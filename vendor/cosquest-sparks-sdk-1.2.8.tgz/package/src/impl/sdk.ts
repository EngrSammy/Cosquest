/**
 * The real Sparks SDK: the public API (../index.ts) over the native module
 * (../NativeSparks.ts).
 *
 * Protocol behaviour follows the JS mock (packages/sparks-sdk-mock), which is
 * the behavioural reference: device.register and heartbeats, hints, job
 * leasing (ack, progress, result, release), HPKE-sealed inputs, context
 * bundles, the Spark mirror, startSpark's duplicate check, call segments,
 * the scribe, commands and consent. The protocol code is copied from the mock
 * rather than shared because the mock must not be edited by this package; the
 * duplicated pieces are marked "as the mock".
 *
 * What differs from the mock: the model is real (mote via the native engine,
 * prompts in tasks.ts), the device key and HPKE open are native (iOS Keychain
 * and CryptoKit, Android Keystore and BouncyCastle), the store is encrypted on disk, downloads are real, gates come
 * from the OS, and the scheduler pauses the engine by priority.
 */
import type {
  AbortSignalLike, AsrManifest, BackendToSdk, CallCommandEvent, CallCommandIntent, CallId, CallOutline, CallsApi, ChatId,
  ChatMember, ChatMessage, CommandContext, ConsentDecision, ConsentState, ContextBundle, DeviceCapabilities,
  DeviceTier, GameState, IngestResult, JobInput, JobOfferPayload, JobOutput, JobReleasePayload, JobType, MergeSuggestion,
  ModelApi, ModelManifest, ModelStatus, ModelVariantInfo, OutlineInput, OutlineSpanSummary, RelatedMessage,
  RolePingSuggestion, SchedulerState, SdkToBackend, Spark, SparkCatalogEntry, SparkId, SparkMatch, SparkSummary,
  SparkTopicEvent, SparksApi, SparksConfig, SparksEventMap, SparksSdk, SparksThresholds, StartSparkRequest,
  StartSparkResult, TopicId, TopicShift, TopicSummary, TranscriptSegment, TranscriptionNotice, TranscriptionSession, Unsubscribe,
  OrchestratorApi, OrchestratorLine, OrchestratorSayRequest, MessageId, SparksErrorInfo, JobAckPayload, JobStep, JobStepEvent,
} from '../index';
import type {
  NativeAsrLineEvent, NativeDeviceInfo, NativeDownloadEvent, NativeEngineState, NativeGates, NativeGenerateResult, Spec,
} from '../NativeSparks';
import * as T from './tasks';
import * as J from './jobs';
import { LocalStore } from './store';
import { Pace } from './pace';
import {
  Emitter, Lru, abortable, cosine, fromNative, g, hash32, infoOf, secs, sleep, sparksError, trigramSimilarity, uuidv4,
} from './runtime';

const SDK_VERSION = '1.2.8';
/** The native build this JavaScript expects (SPK_NATIVE_BUILD in cpp/sparks/sparks_core.h). */
const NATIVE_BUILD = 10207;

// ------------------------------------------------------------- constants

/** As the mock (and the backend's device.registered defaults). */
const DEFAULT_THRESHOLDS: SparksThresholds = {
  assignMinScore: 0.82, assignMinMargin: 0.04, duplicateMinScore: 0.85, rolePingMinConfidence: 0.75,
  scribeIntervalMs: 15000, scribeMinNewSegments: 8,
};

/** The transcription notice (API.md §8). Same text as the mock. */
const NOTICE: TranscriptionNotice = {
  version: 2,
  title: 'Turn on Sparks for calls',
  body: 'Sparks works in calls the way it does in chat. While you talk, your phone turns what you say into text, Sparks picks out the topics as they come up, and when the call ends it writes up what was discussed under each one. The audio never leaves your phone and is never saved. The text is shared with the people on the call.\nYou can turn Sparks off for yourself at any time from the call screen.',
  acceptLabel: 'Turn on Sparks',
  declineLabel: 'Not now',
  indicatorLabel: 'Sparks on',
};

const P_WARDEN = 0, P_INTERACTIVE = 1, P_BACKGROUND = 2;
const HEARTBEAT_MS = 60000;
const MANIFEST_RECHECK_MS = 24 * 3600 * 1000;
/**
 * Newest `.mq` format the vendored engine reads: MQ_VERSION in cpp/mote/model.h
 * (5 = heads that are not dim / n_heads wide, which the Qwen3-0.6B lite model
 * needs). A manifest variant with a higher `mq_version` is skipped, and the
 * manifest is requested with `mq=<this>` so the server can list variants older
 * SDKs cannot load only to clients that can. test/variants.mts checks it
 * against model.h.
 */
export const ENGINE_MQ_VERSION = 5;
/**
 * Background inference budget per rolling hour (PERFORMANCE §4), per lane.
 * 'chat': hints and chat jobs (detect, assign, summarize, rolepings); it also
 * decides the heartbeat's `available`. 'call': call outline jobs, budgeted on
 * their own (PERFORMANCE §3: up to 10 min for a 30-minute call's outline) so
 * a long chat day cannot block an outline and an outline cannot block chat.
 * The live scribe (topic checks during a call) runs only while the call does,
 * like transcription, and counts against neither: it used to count against
 * the one shared budget, so after a long call the phone refused that call's
 * own outline ('paused') and reported itself unavailable for up to an hour.
 * A phone that reports no battery (simulator, emulator) gets the charging budget.
 */
const BUDGET_MS: Record<Exclude<Lane, 'live'>, { battery: number; charging: number }> = {
  chat: { battery: 3 * 60000, charging: 10 * 60000 },
  call: { battery: 10 * 60000, charging: 20 * 60000 },
};
type Lane = 'chat' | 'call' | 'live';
/** The backend's Sparks bot sender (its default botUserId): its posts are skipped even when the app maps them without `bot`. */
const SPARKS_BOT_ID = 'sparks-bot';
/** Job types this SDK runs. A newer backend may offer others: they are refused (unsupported) instead of failing after the ack. */
const JOB_TYPES_RUN = new Set<string>(['spark.detect', 'spark.assign', 'spark.summarize', 'spark.rolepings', 'spark.related', 'call.scribe', 'call.outline.map', 'call.outline.reduce']);
const laneOf = (t: JobType): Lane => (t === 'call.scribe' ? 'live' : t.startsWith('call.') ? 'call' : 'chat');
/**
 * The longest a job may run on this phone, whatever its deadline (call
 * outlines have days). Past it, or past the job's deadline if sooner, the
 * SDK stops waiting for the engine and releases the job (reason 'error',
 * E_TIMEOUT) so the backend can offer it again: an accepted job always ends
 * in job.result or job.release, never in silence.
 */
const MAX_JOB_RUN_MS = 15 * 60000;
/** job.progress cadence while a job runs: a third of its lease, 2 to 20 s. */
const PROGRESS_MIN_MS = 2000, PROGRESS_MAX_MS = 20000;
/**
 * Model steps a job can do without (SDK 1.2.7): skipped when this phone's
 * measured speed says the step would not finish before the job's soft stop.
 * spark.detect's duplicate check is one: without it the backend's lexical
 * safety net still joins a near-identical Spark, and the subject the phone
 * already wrote is not thrown away.
 */
const OPTIONAL_STEPS = new Set<T.SparksTask>(['match_existing']);
/** A job stops this long before its deadline (at most a tenth of its time) to send what it has. */
const SOFT_STOP_MS = 4000;

/** A running job's time budget: the soft stop, and whether it was reached. */
interface JobBudget {
  softAt: number;
  /** Aborts the current model step (not the job) at the soft stop. */
  soft: SimpleAbort;
  outOfTime: boolean;
}
const MAX_PENDING_SENDS = 500;
/** Backend replies meaning "this connection is not tied to a device": register again (SparksTransport.send). */
const UNBOUND_REPLIES = new Set(['register first', 'unknown device']);
/** How far back transportReconnected re-sends delivered messages, and which types (all safe to repeat: deduped by id or idempotent). */
const RECENT_MS = 60000;
const RESEND_ON_RECONNECT = new Set<SdkToBackend['type']>([
  'message.spark_hint', 'spark.create', 'job.ack', 'job.result', 'job.release', 'call.segment', 'call.consent', 'context.request',
]);
/** The backend's refusal in a transport reply, if any. */
function replyError(reply: unknown): string | null {
  if (!reply || typeof reply !== 'object') return null;
  const e = (reply as { error?: unknown }).error;
  return typeof e === 'string' && e ? e : null;
}

/** How long an outbound message stays worth retrying (DATA_CONTRACT §3). */
function sendTtlMs(type: SdkToBackend['type']): number {
  switch (type) {
    case 'device.register': case 'call.consent': return Infinity;
    case 'device.heartbeat': case 'job.progress': case 'call.topic_proposal': case 'call.topic_summary_proposal': return 0;
    case 'message.spark_hint': return 5 * 60000;
    case 'spark.create': return 2 * 60000;
    case 'call.segment': return 10 * 60000;
    case 'call.command': return 15000;
    case 'call.listening': return 60000;
    case 'context.request': return 60000;
    default: return 30000;   // job.ack / job.result / job.release: bounded by the lease below
  }
}

type Priority = typeof P_WARDEN | typeof P_INTERACTIVE | typeof P_BACKGROUND;

interface GenOptions {
  priority: Priority;
  maxTokens: number;
  stop?: string;
  temperature?: number;
  topP?: number;
  repeatPenalty?: number;
  schema?: string;
  signal?: AbortSignalLike;
  /** Accumulates per-job metrics. */
  meter?: Meter;
  /** The model task (tasks.ts), for job step lines. */
  task?: string;
  /** The running job's step reporter, when this generate belongs to a job. */
  trace?: JobTrace;
  /** Which background budget a P_BACKGROUND generate counts against (default 'chat'). */
  lane?: Lane;
}

type JobTrace = (step: JobStep, detail?: string, error?: SparksErrorInfo) => void;

interface Meter { tokensIn: number; tokensOut: number }

interface RunningJob {
  jobId: string;
  type: JobType;
  leaseToken: string;
  leaseExpiresAt: number;
  abort: SimpleAbort;
}

/** Aborts when either signal does (a job's abort, or its soft stop for the current step). */
function anySignal(a: AbortSignalLike | undefined, b: SimpleAbort): SimpleAbort {
  const out = new SimpleAbort();
  const fromA = () => out.abort(String((a as { reason?: unknown } | undefined)?.reason ?? 'aborted'));
  const fromB = () => out.abort(b.reason ?? 'deadline');
  if (a?.aborted) fromA(); else a?.addEventListener('abort', fromA);
  if (b.aborted) fromB(); else b.addEventListener('abort', fromB);
  return out;
}

class SimpleAbort implements AbortSignalLike {
  aborted = false;
  reason: string | null = null;
  private ls = new Set<() => void>();
  abort(reason: string): void {
    if (this.aborted) return;
    this.aborted = true;
    this.reason = reason;
    for (const l of [...this.ls]) l();
  }
  addEventListener(_t: 'abort', l: () => void): void { this.ls.add(l); }
  removeEventListener(_t: 'abort', l: () => void): void { this.ls.delete(l); }
}

interface Utterance { segmentId: string; startMs: number }
interface Session {
  opts: { callId: CallId; chatId: ChatId; callStartedAt: string; partials: boolean; commands: CommandContext | false };
  userMuted: boolean;
  /** Call-clock ms when the native stream started (lines are relative to it). */
  baseMs: number;
  lines: Map<string, Utterance>;
  startedAt: string;
  /** Listening report (call.listening): when this run started, since when the mic is on (null: muted), the minute timer. */
  runStartedAt: number;
  unmutedSince: number | null;
  reportTimer: ReturnType<typeof setInterval> | null;
}
/** What this phone heard on a call, over every run of transcription on it (call.listening). */
interface ListenTotals { listenedMs: number; unmutedMs: number; lines: number }
const LISTENING_REPORT_MS = 60000;
interface ScribeState {
  jobId: string; leaseToken: string; callId: CallId; chatId: ChatId;
  current: { topicId: TopicId; title: string } | null;
  topics: TopicShift[]; segments: TranscriptSegment[]; participants: ChatMember[];
  newSince: number; checking: boolean; timers: unknown[]; abort: SimpleAbort;
  /** Start of the newest line the previous scribe check saw (a topic change is placed after it). */
  seenUpToMs: number;
  /** Live topic summaries (the job input's liveSummary), or null when the backend did not ask for them. */
  live: J.LiveSummaryTracker | null;
  summarizing: boolean;
  /** A topic change was proposed and its call.topic_shift has not come back yet (until this time): no summary meanwhile. */
  shiftPendingUntil: number;
}

/** How long the scribe waits for its proposed topic change to come back before summarizing again anyway. */
const SHIFT_PENDING_MS = 10000;
/** Calls whose live topic summaries this phone keeps (getTopicSummaries), most recent last. */
const TOPIC_SUMMARY_CALLS = 8;

let singleton: NativeSparksImpl | null = null;

export async function createNativeSparks(config: SparksConfig, native: Spec | null): Promise<SparksSdk> {
  if (singleton) throw sparksError('E_ALREADY_INITIALIZED', 'createSparks was already called in this process');
  if (!config?.userId || !config.sessionId || !config.transport || typeof config.transport.send !== 'function') {
    throw sparksError('E_INVALID_ARGUMENT', 'userId, sessionId and transport are required', false, { field: 'config' });
  }
  if (!native) {
    throw sparksError('E_NOT_INITIALIZED',
      'The Sparks native module is not linked. Use a development build with the New Architecture (not Expo Go), run pod install, and rebuild.', false);
  }
  const sdk = new NativeSparksImpl(config, native);
  singleton = sdk;
  try {
    return await sdk.start();
  } catch (e) {
    singleton = null;
    sdk.dispose();
    throw fromNative(e);
  }
}

class NativeSparksImpl implements SparksSdk {
  readonly version = SDK_VERSION;
  deviceId = '';
  readonly model: ModelApi;
  readonly orchestrator: OrchestratorApi;
  /** @deprecated Since 1.2: the same object as `orchestrator`. */
  readonly warden: OrchestratorApi;
  readonly sparks: SparksApi;
  readonly calls: CallsApi;

  private readonly scope: string;
  private store: LocalStore;
  private ev = new Emitter();
  private info!: NativeDeviceInfo;
  private tier: DeviceTier = 'none';
  private tierReason: DeviceCapabilities['tierReason'];
  private publicKey = '';
  private kid = '';
  private thresholds = DEFAULT_THRESHOLDS;
  private clockOffsetMs = 0;
  private gameState: GameState = 'idle';
  private gates: NativeGates = { foreground: true, batteryLevel: -1, charging: false, lowPowerMode: false, thermal: 'nominal', memoryWarningAgeMs: -1 };
  private engine: NativeEngineState = { running: -1, queuedWarden: 0, queuedInteractive: 0, queuedBackground: 0, pausedMask: 0, wardenLoaded: false, sparksLoaded: false, modelAttached: false };
  private seen: string[] = [];
  private seenSet = new Set<string>();
  private pendingSends: { type: SdkToBackend['type']; cancelled: boolean }[] = [];
  private runningJob: RunningJob | null = null;
  private scribe: ScribeState | null = null;
  /** The latest live summary per topic, per call (call.topic_summary). */
  private topicSummaries = new Map<CallId, Map<TopicId, TopicSummary>>();
  private sessions = new Map<CallId, Session>();
  private pendingCommands = new Map<string, CallCommandEvent>();
  private pendingStarts = new Map<MessageId, (e: SparkTopicEvent) => void>();
  private requestedContext = new Set<ChatId>();
  private modelStatus: ModelStatus = { phase: 'not_downloaded', tier: 'none' };
  private modelPaths: { model: string; tokenizer: string; version: string } | null = null;
  /** The manifest's `asr` entry whose files are on disk and handed to the transcriber. */
  private asrFiles: AsrManifest | null = null;
  private loadPromise: Promise<ModelStatus> | null = null;
  private ensurePromise: Promise<ModelStatus> | null = null;
  private manifestCheckedAt = 0;
  private nextRequestId = 1;
  private inferenceLog: { at: number; ms: number; lane: Lane }[] = [];
  private embedCache = new Lru<number[]>(512);
  /** This phone's measured model speed (reset when a different model loads). */
  private pace = new Pace();
  private paceModel: string | null = null;
  private heartbeatTimer: unknown = null;
  private subscriptions: { remove(): void }[] = [];
  private lastHeartbeatKey = '';
  private lastPauseMask = -1;
  private alive = true;
  private segCounter = 0;
  /**
   * Segment ids are seg_<device>_<run>_<n>: n counts from 1 each time the
   * SDK starts, so the run part (random per start) keeps ids unique across
   * app launches. Up to 1.2.7 ids were seg_<device>_<n> and a phone reused
   * its own earlier ids after every restart; backends that store lines by id
   * dropped them as repeats (25 Oct: a whole side of a voice chat).
   */
  private segRun = uuidv4().replace(/-/g, '').slice(0, 6);
  private listenTotals = new Map<CallId, ListenTotals>();

  constructor(private config: SparksConfig, private native: Spec) {
    this.scope = `${config.userId}:${config.sessionId}`;
    this.store = new LocalStore({
      get: (n) => native.storeGet(this.scope, n),
      set: (n, v) => native.storeSet(this.scope, n, v),
      wipe: () => native.storeWipe(this.scope),
    });
    this.model = this.makeModelApi();
    this.orchestrator = this.makeOrchestratorApi();
    this.warden = this.orchestrator;
    this.sparks = this.makeSparksApi();
    this.calls = this.makeCallsApi();
  }

  // ================================================================ start

  async start(): Promise<this> {
    const n = this.native;
    this.info = await n.getDeviceInfo(this.config.forceTier ?? '');
    this.tier = this.info.tier as DeviceTier;
    this.tierReason = (this.info.tierReason || undefined) as DeviceCapabilities['tierReason'];
    this.modelStatus = { phase: this.tier === 'none' ? 'unsupported' : 'not_downloaded', tier: this.tier };
    // Speech files already on disk (local only); before register so it reports them.
    await this.restoreAsr().catch((e) => this.log('debug', 'asr restore failed', e));
    await this.openKey();
    await this.store.open();
    this.gates = await n.getGates();

    this.subscriptions.push(
      n.onGates((e) => this.onGates(e.gates, e.memoryWarning)),
      n.onEngineState((s) => { this.engine = s; this.emitScheduler(); }),
      n.onAsrLine((e) => this.onAsrLine(e)),
      n.onDownload((e) => this.onDownload(e)),
    );
    n.startObserving();
    this.applyPauseMask();

    // Contract: resolve once device.register is accepted by transport.send.
    // device.registered may arrive later; thresholds use defaults until then.
    await this.send('device.register', this.registerPayload(), { attempts: 4 });
    this.heartbeat(true);
    this.heartbeatTimer = g.setInterval(() => this.heartbeat(true), HEARTBEAT_MS);

    // Pick up a model that is already on disk (no network). ensure() downloads.
    void this.restoreModel();
    return this;
  }

  private async openKey(): Promise<void> {
    const k = await this.native.deviceKey(this.scope);
    this.publicKey = k.publicKey;
    this.kid = k.kid;
    // Stable per key: a new key (after wipe) is a new device to the backend.
    this.deviceId = `dev_${k.publicKey.replace(/[^A-Za-z0-9]/g, '').slice(0, 16)}`;
  }

  /** From the native module ('ios' | 'android'); the wire enum has only these two. */
  private platform(): 'ios' | 'android' {
    return this.info.platform === 'android' ? 'android' : 'ios';
  }

  private registerPayload() {
    return {
      deviceId: this.deviceId, userId: this.config.userId, sessionId: this.config.sessionId, platform: this.platform(),
      osVersion: this.info.osVersion, appVersion: this.info.appVersion, sdkVersion: SDK_VERSION, tier: this.tier,
      modelVersion: this.modelStatus.version ?? null, transcription: this.info.transcription,
      publicKey: this.publicKey, kid: this.kid,
    };
  }

  dispose(): void {
    this.alive = false;
    if (this.heartbeatTimer) g.clearInterval(this.heartbeatTimer);
    for (const s of this.subscriptions) s.remove();
    this.subscriptions = [];
  }

  // ============================================================== plumbing

  private log(level: 'debug' | 'info' | 'warn' | 'error', ...a: unknown[]) {
    const order = ['silent', 'error', 'warn', 'info', 'debug'];
    if (order.indexOf(this.config.logLevel ?? 'warn') >= order.indexOf(level)) g.console.log(`[sparks ${this.config.userId}]`, ...a);
  }
  private now() { return Date.now() + this.clockOffsetMs; }
  private iso(ms = this.now()) { return new Date(ms).toISOString(); }
  private emitError(info: SparksErrorInfo) { this.ev.emit('error', info); }

  /**
   * Send with exponential backoff (1 s, 2 s, 4 s ... 60 s) while the message
   * is still meaningful. `deadline` bounds lease-tied messages.
   */
  private async send<K extends SdkToBackend['type']>(
    type: K, payload: Extract<SdkToBackend, { type: K }>['payload'], opts: { attempts?: number; deadline?: number } = {},
  ): Promise<void> {
    const msg = { v: 1, type, id: uuidv4(), ts: this.iso(), payload } as SdkToBackend;
    const ttl = sendTtlMs(type);
    const deadline = Math.min(opts.deadline ?? Infinity, ttl === Infinity ? Infinity : Date.now() + ttl);
    const entry = { type, cancelled: false };
    this.pendingSends.push(entry);
    if (this.pendingSends.length > MAX_PENDING_SENDS) {
      const victim = this.pendingSends.find((p) => p.type === 'message.spark_hint' && !p.cancelled)
        ?? this.pendingSends.find((p) => p.type !== 'call.segment' && p.type !== 'call.consent' && !p.cancelled);
      if (victim) victim.cancelled = true;
    }
    let rebound = false;
    try {
      for (let i = 0; ; i++) {
        if (entry.cancelled) throw sparksError('E_TRANSPORT', `dropped ${type}: outbound queue full`, true);
        let reply: unknown;
        try { reply = await this.config.transport.send(msg); } catch (e) {
          const wait = Math.min(60000, 1000 * 2 ** i);
          const last = (opts.attempts !== undefined && i + 1 >= opts.attempts) || ttl === 0 || Date.now() + wait > deadline || !this.alive;
          if (last) {
            const info: SparksErrorInfo = { code: 'E_TRANSPORT', message: `${type}: ${String(e)}`, retryable: true };
            this.emitError(info);
            throw sparksError('E_TRANSPORT', info.message, true);
          }
          await sleep(wait);
          continue;
        }
        const refusal = replyError(reply);
        if (!refusal) {
          if (reply !== undefined && reply !== null && type !== 'device.register') this.rebindStreak = 0;   // the binding works
          this.remember(msg, ttl);
          return;
        }
        // A socket the backend no longer ties to this device (a reconnect): register again, then this message once more.
        if (type !== 'device.register' && UNBOUND_REPLIES.has(refusal) && !rebound && this.alive) {
          rebound = true;
          this.log('warn', `${type} refused by the backend (${refusal}): registering this device again`);
          await this.rebind(refusal);
          continue;
        }
        this.log('warn', `${type} refused by the backend: ${refusal}`);
        return;
      }
    } finally {
      this.pendingSends.splice(this.pendingSends.indexOf(entry), 1);
    }
  }
  // ------------------------------------------------ reconnects and rebinding

  /** One re-registration at a time; consecutive ones wait 1, 2, 4 ... 60 s apart (reset once a message gets through). */
  private rebinding: Promise<void> | null = null;
  private rebindStreak = 0;
  private lastRebindAt = 0;
  /** Messages delivered in the last minute, re-sent by transportReconnected (same ids: the backend drops repeats). */
  private recent: { msg: SdkToBackend; at: number; until: number }[] = [];

  private rebind(why: string, now = false): Promise<void> {
    if (this.rebinding) return this.rebinding;
    this.rebinding = (async () => {
      const gap = this.rebindStreak ? Math.min(60000, 1000 * 2 ** (this.rebindStreak - 1)) : 0;
      const wait = now ? 0 : this.lastRebindAt + gap - Date.now();
      if (wait > 0) await sleep(wait);
      this.rebindStreak = Math.min(this.rebindStreak + 1, 8);
      this.lastRebindAt = Date.now();
      this.log('info', `device.register again (${why})`);
      await this.send('device.register', this.registerPayload(), { attempts: 4 }).catch(() => undefined);
    })().finally(() => { this.rebinding = null; });
    return this.rebinding;
  }

  private remember(msg: SdkToBackend, ttl: number) {
    if (!RESEND_ON_RECONNECT.has(msg.type) || ttl === 0) return;
    const at = Date.now();
    this.recent = this.recent.filter((r) => at - r.at < RECENT_MS && r.until > at);
    this.recent.push({ msg, at, until: ttl === Infinity ? Infinity : at + ttl });
    if (this.recent.length > 200) this.recent.shift();
  }

  async transportReconnected(): Promise<void> {
    if (!this.alive) return;
    try {
      const resend = this.recent.filter((r) => Date.now() - r.at < RECENT_MS && r.until > Date.now()).map((r) => r.msg);
      await this.rebind('transport reconnected', true);
      this.heartbeat(false);
      for (const m of resend) {
        void Promise.resolve().then(() => this.config.transport.send(m)).catch(() => undefined);
      }
      this.log('info', `reconnected: registered again, re-sent ${resend.length} recent message(s)`);
    } catch (e) {
      this.log('warn', 'transportReconnected failed', e);
    }
  }

  private fire<K extends SdkToBackend['type']>(type: K, payload: Extract<SdkToBackend, { type: K }>['payload'], opts?: { attempts?: number; deadline?: number }): void {
    // fire() is typed at its own signature; the cast only bridges TS's distributive Extract.
    void this.send(type, payload as never, opts).catch(() => undefined);
  }

  // ======================================================== gates, scheduler

  private onGates(gates: NativeGates, memoryWarning: boolean) {
    const before = this.heartbeatKey();
    this.gates = gates;
    if (memoryWarning) {
      // PERFORMANCE §2: free the sparks handle now (its KV is a cache), release background work, keep the Orchestrator.
      void this.native.unloadModel(1).catch(() => undefined);
      if (this.runningJob) this.runningJob.abort.abort('memory');
    }
    this.applyPauseMask();
    if (this.heartbeatKey() !== before) this.heartbeat(false);
  }

  private budgetMs(lane: Lane): number {
    const hourAgo = Date.now() - 3600000;
    this.inferenceLog = this.inferenceLog.filter((x) => x.at > hourAgo);
    return this.inferenceLog.reduce((n, x) => n + (x.lane === lane ? x.ms : 0), 0);
  }

  /** Charging, or no battery reported at all (simulators, emulators): the larger budget. */
  private onMains(): boolean { return this.gates.charging || this.gates.batteryLevel < 0; }
  private budgetLimitMs(lane: Lane): number {
    return lane === 'live' ? Infinity : BUDGET_MS[lane][this.onMains() ? 'charging' : 'battery'];
  }

  /** Why background work may not run right now, or null when every gate passes (ARCHITECTURE §2.2). */
  private pauseReason(): SchedulerState['pausedReason'] | null {
    const gt = this.gates;
    if (this.gameState !== 'idle' && this.gameState !== 'map') return 'game_state';
    if (!gt.foreground) return 'app_background';
    if (gt.lowPowerMode) return 'low_power_mode';
    if (!gt.charging && gt.batteryLevel >= 0 && gt.batteryLevel < 0.2) return 'low_battery';
    if (gt.thermal === 'serious' || gt.thermal === 'critical') return 'thermal';
    if (gt.memoryWarningAgeMs >= 0 && gt.memoryWarningAgeMs < 60000) return 'memory';
    return null;
  }

  private overBudget(lane: Lane = 'chat'): boolean {
    return this.budgetMs(lane) >= this.budgetLimitMs(lane);
  }

  private modelUsable(): boolean {
    return this.modelStatus.phase === 'ready' || this.modelStatus.phase === 'loaded';
  }

  /** Accepting new jobs right now (heartbeat `available`). */
  private available(): boolean {
    return this.alive && this.tier !== 'none' && (this.config.acceptJobs ?? true) && this.modelUsable()
      && this.pauseReason() === null && !this.overBudget();
  }

  /** P2 pauses on any closed gate; P1 also pauses in battle and ar; P0 never. */
  private applyPauseMask() {
    let mask = 0;
    if (this.pauseReason() !== null) mask |= 1 << P_BACKGROUND;
    if (this.gameState === 'battle' || this.gameState === 'ar') mask |= 1 << P_INTERACTIVE;
    if (mask !== this.lastPauseMask) {
      this.lastPauseMask = mask;
      this.native.setPaused(mask);
    }
    this.emitScheduler();
  }

  private emitScheduler() {
    const e = this.engine;
    const running = e.running === P_WARDEN ? 'warden' : e.running === P_INTERACTIVE ? 'interactive' : e.running === P_BACKGROUND ? 'background' : null;
    const reason = this.pauseReason();
    const s: SchedulerState = {
      running,
      queued: { warden: e.queuedWarden, interactive: e.queuedInteractive, background: e.queuedBackground },
      paused: reason !== null,
      pausedReason: reason ?? undefined,
    };
    this.ev.emit('scheduler', s);
  }

  private heartbeatKey() {
    const gt = this.gates;
    return [this.available(), this.gameState, gt.charging, gt.thermal, gt.foreground].join('|');
  }

  private heartbeat(periodic: boolean) {
    if (!this.alive) return;
    if (periodic && !this.gates.foreground) return;   // every 60 s while foreground
    this.lastHeartbeatKey = this.heartbeatKey();
    const gt = this.gates;
    this.fire('device.heartbeat', {
      deviceId: this.deviceId, foreground: gt.foreground, gameState: this.gameState, modelLoaded: this.modelStatus.phase === 'loaded',
      batteryLevel: gt.batteryLevel < 0 ? null : Math.round(gt.batteryLevel * 100) / 100, charging: gt.charging,
      lowPowerMode: gt.lowPowerMode, thermal: (['nominal', 'fair', 'serious', 'critical'].includes(gt.thermal) ? gt.thermal : 'nominal') as 'nominal',
      activeJobIds: [this.runningJob?.jobId, this.scribe?.jobId].filter((x): x is string => !!x), available: this.available(),
    }, { attempts: 1 });
  }

  private maybeHeartbeat() { if (this.heartbeatKey() !== this.lastHeartbeatKey) this.heartbeat(false); }

  // ================================================================ engine

  /**
   * Generate on the engine. Loads the model lazily when it is on disk. An
   * abort (job deadline, backend cancel, memory warning) cancels the native
   * request and rejects at once, also while the model is still loading: the
   * caller never waits on a native call it has given up on.
   */
  private async generate(prompt: string, o: GenOptions): Promise<NativeGenerateResult> {
    if (this.tier === 'none') throw sparksError('E_DEVICE_UNSUPPORTED', 'This phone has no local model', false);
    const task = o.task ?? 'generate';
    const t0 = Date.now();
    let requestId = 0;
    try {
      if (o.signal?.aborted) throw sparksError('E_CANCELLED', 'aborted', false);
      const loading = this.modelStatus.phase !== 'loaded' ? `, model ${this.modelStatus.phase}: loading it first` : '';
      o.trace?.('generate.start', `${task}: ${prompt.length} chars, up to ${o.maxTokens} tokens${loading}`);
      await abortable(this.ensureLoaded(), o.signal);
      requestId = this.nextRequestId++;
      const id = requestId;
      const r = await abortable(this.native.generate({
        requestId: id, priority: o.priority, prompt, schema: o.schema ?? '', stop: o.stop ?? '',
        temperature: o.temperature ?? 0, topP: o.topP ?? 0, repeatPenalty: o.repeatPenalty ?? 1.0,
        maxTokens: o.maxTokens, seed: 0, stream: false,
      }), o.signal, () => this.native.cancel(id));
      if (o.meter) { o.meter.tokensIn += r.tokensInEstimate; o.meter.tokensOut += r.tokensOut; }
      this.pace.record(r);
      if (o.priority === P_BACKGROUND) this.inferenceLog.push({ at: Date.now(), ms: r.runMs, lane: o.lane ?? 'chat' });
      o.trace?.('generate.end', `${task}: ${r.tokensOut} tokens out, ~${r.tokensInEstimate} in, ${secs(Date.now() - t0)} (first token ${secs(r.firstTokenMs)}, engine ${secs(r.runMs)})`);
      return r;
    } catch (e) {
      if (o.priority === P_BACKGROUND && requestId) this.inferenceLog.push({ at: Date.now(), ms: Date.now() - t0, lane: o.lane ?? 'chat' });
      const err = fromNative(e, 'E_ENGINE');
      // Stopped from outside (deadline, soft stop, cancel): the job's own step (timeout, partial, cancelled) says why.
      if (!o.signal?.aborted) o.trace?.('generate.failed', `${task} after ${secs(Date.now() - t0)}`, infoOf(err));
      throw err;
    }
  }

  /** A tasks.ts Generate bound to a priority: greedy, one line, the task's token cap (MODEL_TASKS.md). */
  private gen(priority: Priority, signal?: AbortSignalLike, meter?: Meter, trace?: JobTrace, lane?: Lane, budget?: JobBudget): T.Generate {
    return async (task, prompt) => {
      let sig = signal;
      if (budget) {
        if (OPTIONAL_STEPS.has(task)) {
          const left = budget.softAt - Date.now();
          // Typical output is about half the task's token cap.
          if (!this.pace.fits(prompt.length, Math.ceil(T.MAX_TOKENS[task] / 2), left)) {
            budget.outOfTime = true;
            const est = this.pace.estimateMs(prompt.length, Math.ceil(T.MAX_TOKENS[task] / 2)) ?? 0;
            trace?.('generate.skipped', `${task}: needs about ${secs(est)} on this phone, ${secs(left)} left before the deadline`);
            throw sparksError('E_TIMEOUT', `${task} skipped: it would not finish before the deadline`, true);
          }
        }
        sig = anySignal(signal, budget.soft);
      }
      return (await this.generate(prompt, { priority, maxTokens: T.MAX_TOKENS[task], stop: '\n', signal: sig, meter, task, trace, lane })).text;
    };
  }

  private async embed(text: string, priority: Priority, signal?: AbortSignalLike): Promise<number[]> {
    const key = `${priority === P_WARDEN ? 'w' : 's'}:${text}`;
    const hit = this.embedCache.get(key);
    if (hit) return hit;
    if (this.tier === 'none') throw sparksError('E_DEVICE_UNSUPPORTED', 'This phone has no local model', false);
    await this.ensureLoaded();
    const requestId = this.nextRequestId++;
    const onAbort = () => this.native.cancel(requestId);
    signal?.addEventListener('abort', onAbort);
    try {
      const v = await this.native.embed(requestId, priority, text.slice(0, 1000));
      this.embedCache.set(key, v);
      return v;
    } catch (e) {
      throw fromNative(e, 'E_ENGINE');
    } finally {
      signal?.removeEventListener('abort', onAbort);
    }
  }

  // ================================================================= model

  private setModel(s: Partial<ModelStatus>): ModelStatus {
    const before = this.modelStatus;
    this.modelStatus = { ...this.modelStatus, ...s };
    this.ev.emit('model.status', this.modelStatus);
    if (before.phase !== this.modelStatus.phase) { this.applyPauseMask(); this.maybeHeartbeat(); }
    if (before.version !== this.modelStatus.version || before.tier !== this.modelStatus.tier) {
      this.fire('device.register', this.registerPayload());
    }
    return this.modelStatus;
  }

  private onDownload(e: NativeDownloadEvent) {
    const v = this.modelStatus.variant;
    if (!v || (e.sha256 !== v.model.sha256.toLowerCase())) return;   // tokenizer progress is noise
    if (e.phase === 'downloading') this.setModel({ phase: 'downloading', bytesDownloaded: e.bytesDownloaded, bytesTotal: e.bytesTotal });
    else if (e.phase === 'paused') this.setModel({ phase: 'download_paused', bytesDownloaded: e.bytesDownloaded, bytesTotal: e.bytesTotal });
    else if (e.phase === 'verifying') this.setModel({ phase: 'verifying' });
  }

  /** The first variant this phone meets, never above its hardware tier (ARCHITECTURE §6). */
  private pickVariant(m: ModelManifest): ModelVariantInfo | null {
    const variants = m.variants?.length ? m.variants
      : [{ label: m.label, model: m.model, tokenizer: m.tokenizer, min_ram_bytes: m.min_ram_bytes }];
    const rank = (t: DeviceTier) => (t === 'full' ? 0 : t === 'lite' ? 1 : 2);
    for (let i = 0; i < variants.length; i++) {
      const v = variants[i] as ModelManifest['variants'][number];
      const tier: 'full' | 'lite' = v.tier ?? (/0\.5b|05b|\blite\b|0\.5 ?b/i.test(v.label) || (i > 0 && !/1\.7/.test(v.label)) ? 'lite' : 'full');
      if (rank(tier) < rank(this.tier)) continue;
      // A format this engine cannot read: never download it. No field = an old manifest, loadable.
      if ((v.mq_version ?? 0) > ENGINE_MQ_VERSION) continue;
      // SPK_RAM_TOLERANCE / SparksTierPolicy.ramTolerance
      if (this.info.ramBytes < 0.85 * v.min_ram_bytes) continue;
      return { label: v.label, tier, model: v.model, tokenizer: v.tokenizer, minRamBytes: v.min_ram_bytes };
    }
    return null;
  }

  private async fetchManifest(): Promise<ModelManifest> {
    const headers: Record<string, string> = { Accept: 'application/json' };
    if (this.config.getAuthToken) headers.Authorization = `Bearer ${await this.config.getAuthToken()}`;
    let res;
    const url = this.config.modelManifestUrl;
    const withMq = `${url}${url.includes('?') ? '&' : '?'}mq=${ENGINE_MQ_VERSION}`;
    try { res = await g.fetch(withMq, { headers }); } catch (e) {
      throw sparksError('E_MODEL_DOWNLOAD_FAILED', `manifest: ${String(e)}`, true);
    }
    if (!res.ok) throw sparksError('E_MODEL_DOWNLOAD_FAILED', `manifest: HTTP ${res.status}`, true);
    const m = await res.json() as ModelManifest;
    if (!m || !m.model || typeof m.min_ram_bytes !== 'number') throw sparksError('E_PAYLOAD_INVALID', 'manifest has an unexpected shape', false);
    this.manifestCheckedAt = Date.now();
    return m;
  }

  /** At start: use a verified model already on disk (no network). */
  private async restoreModel(): Promise<void> {
    if (this.tier === 'none') return;
    const last = await this.native.storeGet(this.scope, 'model.variant').catch(() => null);
    if (!last) return;
    try {
      const v = JSON.parse(last) as ModelVariantInfo;
      const [mp, tp] = await Promise.all([this.native.modelFilePath(v.model.sha256, 'model'), this.native.modelFilePath(v.tokenizer.sha256, 'tokenizer')]);
      if (mp && tp && this.modelStatus.phase === 'not_downloaded') {
        this.modelPaths = { model: mp, tokenizer: tp, version: v.model.sha256.slice(0, 12) };
        this.setModel({ phase: 'ready', variant: v, version: this.modelPaths.version, bytesDownloaded: v.model.bytes, bytesTotal: v.model.bytes });
      }
    } catch { /* a stale record: ensure() will fix it */ }
  }

  private async ensureModel(opts?: { allowCellular?: boolean; signal?: AbortSignalLike }): Promise<ModelStatus> {
    if (this.tier === 'none') {
      // No language model on this phone, but it still transcribes its owner.
      const m = await this.fetchManifest().catch(() => null);
      if (m) await this.ensureAsr(m, opts).catch((e) => this.log('warn', 'speech model download failed', e));
      return this.setModel({ phase: 'unsupported' });
    }
    const loadedVersion = this.modelStatus.phase === 'loaded' ? this.modelStatus.version : undefined;
    this.setModel({ phase: this.modelStatus.phase === 'loaded' ? 'loaded' : 'checking', error: undefined });
    let manifest: ModelManifest;
    try { manifest = await this.fetchManifest(); } catch (e) {
      // Offline with a verified model on disk: keep working (ARCHITECTURE §6 "Offline").
      if (this.modelPaths) return this.setModel({ phase: loadedVersion ? 'loaded' : 'ready' });
      const info = infoOf(e);
      this.setModel({ phase: 'error', error: info });
      throw fromNative(e);
    }
    // Speech files download alongside the model; their failure never fails ensure().
    const asr = this.ensureAsr(manifest, opts).catch((e) => this.log('warn', 'speech model download failed', e));
    try {
      return await this.ensureVariant(manifest, loadedVersion, opts);
    } finally {
      await asr;
    }
  }

  private async ensureVariant(manifest: ModelManifest, loadedVersion: string | undefined, opts?: { allowCellular?: boolean; signal?: AbortSignalLike }): Promise<ModelStatus> {
    const variant = this.pickVariant(manifest);
    if (!variant) {
      this.tier = 'none';
      this.tierReason = 'manifest';
      return this.setModel({ phase: 'unsupported', tier: 'none', variant: undefined });
    }
    if (variant.tier !== this.tier) { this.tier = variant.tier; this.tierReason = 'manifest'; }
    const version = variant.model.sha256.slice(0, 12);
    if (loadedVersion === version) return this.setModel({ phase: 'loaded', variant, tier: this.tier, updatePending: false });

    let mp = await this.native.modelFilePath(variant.model.sha256, 'model');
    let tp = await this.native.modelFilePath(variant.tokenizer.sha256, 'tokenizer');
    if (!mp || !tp) {
      const free = this.info.freeDiskBytes;
      if (free > 0 && free < variant.model.bytes + 500 * 2 ** 20 && !mp) {
        const info: SparksErrorInfo = { code: 'E_INSUFFICIENT_STORAGE', message: 'not enough free space for the model', retryable: true };
        this.setModel({ phase: 'error', error: info, variant });
        throw sparksError(info.code, info.message, true);
      }
      this.setModel({ phase: 'downloading', variant, tier: this.tier, bytesDownloaded: 0, bytesTotal: variant.model.bytes });
      const allowCellular = opts?.allowCellular ?? this.config.allowCellularDownload ?? false;
      const token = this.config.getAuthToken ? await this.config.getAuthToken() : '';
      const onAbort = () => this.native.cancelDownloads();
      opts?.signal?.addEventListener('abort', onAbort);
      try {
        if (!tp) tp = await this.native.downloadFile({ url: variant.tokenizer.url, sha256: variant.tokenizer.sha256, bytes: variant.tokenizer.bytes, kind: 'tokenizer', allowCellular, authToken: token });
        if (!mp) mp = await this.native.downloadFile({ url: variant.model.url, sha256: variant.model.sha256, bytes: variant.model.bytes, kind: 'model', allowCellular, authToken: token });
      } catch (e) {
        const err = fromNative(e, 'E_MODEL_DOWNLOAD_FAILED');
        if (err.code === 'E_CANCELLED') return this.setModel({ phase: 'download_paused' });
        this.setModel({ phase: 'error', error: infoOf(err) });
        throw err;
      } finally {
        opts?.signal?.removeEventListener('abort', onAbort);
      }
    }
    await this.native.storeSet(this.scope, 'model.variant', JSON.stringify(variant)).catch(() => undefined);
    this.modelPaths = { model: mp, tokenizer: tp, version };
    if (loadedVersion) return this.setModel({ phase: 'loaded', variant, updatePending: true });
    return this.setModel({ phase: 'ready', variant, version, tier: this.tier, bytesDownloaded: variant.model.bytes, bytesTotal: variant.model.bytes, updatePending: false });
  }

  // ------------------------------------------------- speech model (manifest asr)

  private asrShas(f: AsrManifest | null = this.asrFiles): string[] {
    return f ? [f.encoder.sha256, f.decoder.sha256, f.tokenizer.sha256, f.vad.sha256] : [];
  }

  /** At start: hand verified speech files already on disk to the transcriber (no network). */
  private async restoreAsr(): Promise<void> {
    const raw = await this.native.storeGet(this.scope, 'model.asr').catch(() => null);
    if (!raw) return;
    const a = JSON.parse(raw) as AsrManifest;
    const paths = await Promise.all(this.asrShas(a).map((sha) => this.native.modelFilePath(sha, 'asr')));
    if (paths.every((p): p is string => !!p)) {
      this.asrFiles = a;
      await this.setAsrModel(paths);
    }
  }

  /** Download (or find) and verify the manifest's speech files, then hand them to the transcriber. */
  private async ensureAsr(m: ModelManifest, opts?: { allowCellular?: boolean }): Promise<void> {
    const a = m.asr;
    if (!a || a.engine !== 'moonshine-base' || !a.encoder || !a.decoder || !a.tokenizer || !a.vad) return;
    const allowCellular = opts?.allowCellular ?? this.config.allowCellularDownload ?? false;
    const paths: string[] = [];
    for (const f of [a.encoder, a.decoder, a.tokenizer, a.vad]) {
      let p = await this.native.modelFilePath(f.sha256, 'asr');
      if (!p) {
        // The bearer token goes only to the manifest's own host (these files may be on a CDN).
        const token = this.config.getAuthToken && sameOrigin(f.url, this.config.modelManifestUrl) ? await this.config.getAuthToken() : '';
        p = await this.native.downloadFile({ url: f.url, sha256: f.sha256, bytes: f.bytes, kind: 'asr', allowCellular, authToken: token });
      }
      paths.push(p);
    }
    const previous = this.asrFiles;
    await this.native.storeSet(this.scope, 'model.asr', JSON.stringify(a)).catch(() => undefined);
    this.asrFiles = a;
    await this.setAsrModel(paths);
    // Old speech files go with the next model load; a phone without a model drops them now.
    if (this.tier === 'none' && previous && this.asrShas(previous).join() !== this.asrShas(a).join()) {
      void this.native.deleteModelFiles(this.asrShas(a)).catch(() => undefined);
    }
  }

  private async setAsrModel(paths: string[] | null): Promise<void> {
    const ok = await this.native.asrSetModel({
      encoder: paths?.[0] ?? '', decoder: paths?.[1] ?? '', tokenizer: paths?.[2] ?? '', vad: paths?.[3] ?? '',
    }).catch(() => false);
    if (ok !== this.info.transcription) {
      this.info = { ...this.info, transcription: ok };
      if (this.deviceId) this.fire('device.register', this.registerPayload());
    }
  }

  private async loadModel(): Promise<ModelStatus> {
    if (this.tier === 'none') throw sparksError('E_DEVICE_UNSUPPORTED', 'This phone has no local model', false);
    const swap = this.modelStatus.phase === 'loaded' && this.modelStatus.updatePending;
    if (this.modelStatus.phase === 'loaded' && !swap) return this.modelStatus;
    if (!this.modelPaths) throw sparksError('E_MODEL_NOT_READY', 'call model.ensure() first', true);
    const paths = this.modelPaths;
    this.setModel({ phase: 'loading' });
    try {
      const info = await this.native.loadModel(paths.model, paths.tokenizer, this.tier, false);
      this.logEngine(info);
    } catch (e) {
      const err = fromNative(e, 'E_ENGINE');
      this.setModel({ phase: 'error', error: infoOf(err) });
      throw err;
    }
    this.embedCache.clear();
    if (this.paceModel !== paths.version) { this.pace.reset(); this.paceModel = paths.version; }
    const v = this.modelStatus.variant;
    // The previous version stays until the new one has loaded once (ARCHITECTURE §6).
    if (v) void this.native.deleteModelFiles([v.model.sha256, v.tokenizer.sha256, ...this.asrShas()]).catch(() => undefined);
    return this.setModel({ phase: 'loaded', version: paths.version, updatePending: false });
  }

  /**
   * One line on how this phone runs the model, and a warning when the app's
   * native code is older than this JavaScript: an app that took a new SDK
   * without rebuilding (a dev client built before the update) keeps the old
   * engine, and none of the native fixes reach the phone.
   */
  private logEngine(info: { kernel?: number; threads?: number; nativeBuild?: number; qbits?: number } | null | undefined) {
    const kernel = info?.kernel === 2 ? 'ARM dot product' : info?.kernel === 1 ? 'NEON' : info?.kernel === 0 ? 'plain C' : 'unknown';
    const threads = info?.threads ? `, ${info.threads} threads` : '';
    this.log('info', `engine: ${kernel} kernel${threads}, int${info?.qbits ?? '?'} model, native build ${info?.nativeBuild ?? 'before 1.2.7'}`);
    if (!info?.nativeBuild || info.nativeBuild < NATIVE_BUILD) {
      this.log('warn', `the app's native Sparks code is older than this SDK (${SDK_VERSION}): rebuild the app (Android: npx expo run:android or a new EAS build; iOS: pod install and rebuild). Until then the phone runs the old, slower engine.`);
    }
  }

  private async ensureLoaded(): Promise<void> {
    if (this.modelStatus.phase === 'loaded') return;
    if (!this.modelPaths) throw sparksError('E_MODEL_NOT_READY', 'The model is not downloaded yet (model.ensure())', true);
    if (!this.loadPromise) this.loadPromise = this.loadModel().finally(() => { this.loadPromise = null; });
    await this.loadPromise;
  }

  private makeModelApi(): ModelApi {
    const self = this;
    return {
      status: () => self.modelStatus,
      ensure(options) {
        if (!self.ensurePromise) self.ensurePromise = self.ensureModel(options).finally(() => { self.ensurePromise = null; });
        return self.ensurePromise;
      },
      load: () => self.loadModel(),
      async unload() {
        await self.native.unloadModel(-1);
        if (self.modelStatus.phase === 'loaded') self.setModel({ phase: self.modelPaths ? 'ready' : 'not_downloaded' });
      },
      async checkForUpdate() {
        if (self.tier === 'none') return self.modelStatus;
        return self.model.ensure();
      },
      cancelDownload() { self.native.cancelDownloads(); },
      async deleteFiles() {
        await self.native.unloadModel(-1).catch(() => undefined);
        await self.native.deleteModelFiles([]);
        self.modelPaths = null;
        await self.native.storeSet(self.scope, 'model.variant', null).catch(() => undefined);
        // Speech files too: transcription is off until the next ensure().
        self.asrFiles = null;
        await self.native.storeSet(self.scope, 'model.asr', null).catch(() => undefined);
        await self.setAsrModel(null);
        self.setModel({ phase: self.tier === 'none' ? 'unsupported' : 'not_downloaded', version: undefined, updatePending: false, bytesDownloaded: undefined });
      },
    };
  }

  // =============================================================== inbound

  receive(message: BackendToSdk): void {
    try {
      if (!message || (message as { v?: number }).v !== 1 || typeof message.type !== 'string' || typeof message.id !== 'string') {
        this.emitError({ code: 'E_PAYLOAD_INVALID', message: 'unknown envelope version or shape', retryable: false });
        return;
      }
      if (this.seenSet.has(message.id)) return;
      this.seen.push(message.id); this.seenSet.add(message.id);
      if (this.seen.length > 1000) this.seenSet.delete(this.seen.shift()!);
      const serverTs = Date.parse(message.ts);
      if (!Number.isNaN(serverTs)) this.clockOffsetMs = this.clockOffsetMs * 0.8 + (serverTs - Date.now()) * 0.2;
      switch (message.type) {
        case 'device.registered':
          this.thresholds = { ...DEFAULT_THRESHOLDS, ...message.payload.thresholds };
          if (!Number.isNaN(Date.parse(message.payload.serverTime))) this.clockOffsetMs = Date.parse(message.payload.serverTime) - Date.now();
          break;
        case 'job.offer': void this.onOffer(message.payload); break;
        case 'job.cancel': this.onCancel(message.payload.jobId, message.payload.reason); break;
        case 'job.verdict': {
          const v = message.payload;
          if (this.recentJobs.has(v.jobId)) this.traceKnown(v.jobId, 'verdict', v.accepted ? 'accepted' : `rejected (${v.reason ?? 'no reason'})`);
          else this.log('debug', 'verdict', v);
          break;
        }
        case 'spark.event': this.applySparkEvent(message.payload); break;
        case 'spark.snapshot': {
          const s = this.store.peek(message.payload.chatId);
          s.sparks = new Map(message.payload.sparks.map((x) => [x.sparkId, x]));
          this.store.touch(message.payload.chatId, 'sparks');
          this.ev.emit('sparks.synced', { chatId: message.payload.chatId });
          break;
        }
        case 'call.segment': {
          const seg: TranscriptSegment = { ...message.payload.segment, origin: 'remote' };
          this.ev.emit('call.segment', seg);
          this.feedScribe(seg);
          break;
        }
        case 'call.topic_shift':
          if (this.scribe && this.scribe.callId === message.payload.callId) {
            this.scribe.current = { topicId: message.payload.topicId, title: message.payload.title };
            this.scribe.topics.push(message.payload);
            this.scribe.live?.addTopic(message.payload);
            this.scribe.shiftPendingUntil = 0;
          }
          this.ev.emit('call.topicShift', message.payload);
          break;
        case 'call.topic_summary': this.onTopicSummary(message.payload); break;
        case 'call.engagement':
          if (message.payload.pinSuggestion) this.ev.emit('call.pinSuggestion', message.payload.pinSuggestion);
          break;
        case 'call.command_applied': this.log('info', 'command applied', message.payload); break;
        case 'call.outline_ready': this.ev.emit('call.outlineReady', message.payload.outline); break;
        case 'context.bundle': void this.onBundle(message.payload.bundleId, message.payload.sealed); break;
        default: this.log('warn', 'ignoring unknown type', (message as { type: string }).type);
      }
    } catch (e) {
      this.emitError({ code: 'E_INTERNAL', message: String(e), retryable: false });
    }
  }

  /** As the mock: drop out-of-order versions, keep members' local copies in step, resolve startSpark waiters. */
  private applySparkEvent(e: SparkTopicEvent) {
    const s = this.store.peek(e.chatId);
    const prev = s.sparks.get(e.spark.sparkId);
    if (prev && prev.version >= e.spark.version) return;
    if (e.kind === 'deleted' || e.kind === 'merged') s.sparks.delete(e.spark.sparkId); else s.sparks.set(e.spark.sparkId, e.spark);
    this.store.touch(e.chatId, 'sparks');
    let touched = false;
    for (const id of e.messageIds ?? []) {
      const msg = s.messages.get(id);
      if (msg) { s.messages.set(id, { ...msg, sparkId: e.spark.sparkId, sparkRevivalIndex: e.spark.revivalIndex }); touched = true; }
      const waiter = this.pendingStarts.get(id);
      if (waiter) { this.pendingStarts.delete(id); waiter(e); }
    }
    if (touched) this.store.touch(e.chatId, 'messages');
    this.ev.emit('spark', e);
  }

  private async open<Tp>(kind: 'job.offer' | 'context.bundle', id: string, sealed: { enc: string; ct: string }): Promise<Tp> {
    const text = await this.native.openSealed(this.scope, sealed.enc, sealed.ct, `cosquest-sparks/v1/${kind}`, `${id}|${this.deviceId}`);
    return JSON.parse(text) as Tp;
  }

  private async onBundle(bundleId: string, sealed: { enc: string; ct: string }) {
    let bundle: ContextBundle;
    try { bundle = await this.open<ContextBundle>('context.bundle', bundleId, sealed); } catch {
      this.emitError({ code: 'E_DECRYPT_FAILED', message: `context bundle ${bundleId} did not open`, retryable: false });
      return;
    }
    if (bundle.scope !== 'chat') return;   // call bundles: nothing cached locally in v0.1
    const s = await this.store.chat(bundle.chatId);
    s.members = bundle.members;
    this.storeMessages(bundle.chatId, bundle.messages);
    for (const sp of bundle.sparks) { const cur = s.sparks.get(sp.sparkId); if (!cur || cur.version < sp.version) s.sparks.set(sp.sparkId, sp); }
    this.store.touch(bundle.chatId, 'members');
    this.store.touch(bundle.chatId, 'sparks');
    this.ev.emit('sparks.synced', { chatId: bundle.chatId });
    if (bundle.hasMore) {
      this.fire('context.request', { scope: 'chat', chatId: bundle.chatId, sinceSeq: bundle.untilSeq, limit: 500 });
    }
  }

  // ================================================================== jobs

  /**
   * The step reporter of one job: a 'job.step' event and, at logLevel 'info'
   * ('warn' for failures, 'debug' for progress), a log line.
   */
  private tracer(jobId: string, type: JobType, receivedAt: number): JobTrace {
    let ended = false;
    return (step, detail, error) => {
      // After the job's last step, only the backend's verdict follows (a cancelled model call reporting back late is noise).
      if (ended && step !== 'verdict') return;
      if (step === 'refused' || step === 'result.sent' || step === 'result.failed' || step === 'released' || step === 'timeout' || step === 'cancelled') ended = true;
      const e: JobStepEvent = {
        jobId, type, step, at: this.iso(), elapsedMs: Date.now() - receivedAt,
        ...(detail ? { detail } : {}), ...(error ? { error } : {}),
      };
      this.ev.emit('job.step', e);
      const level = step === 'progress' ? 'debug'
        : step === 'timeout' || step === 'result.failed' || step === 'generate.failed' || (step === 'released' && !!error) ? 'warn' : 'info';
      const err = error ? ` [${error.code}: ${error.message}]` : '';
      this.log(level, `job ${jobId} ${type} ${step} +${secs(e.elapsedMs)}${detail ? `: ${detail}` : ''}${err}`);
    };
  }

  /** Recent jobs by id, so a later job.verdict or job.cancel line can name the type. */
  private recentJobs = new Map<string, { type: JobType; receivedAt: number }>();
  private rememberJob(jobId: string, type: JobType, receivedAt: number) {
    this.recentJobs.set(jobId, { type, receivedAt });
    if (this.recentJobs.size > 50) this.recentJobs.delete(this.recentJobs.keys().next().value as string);
  }
  private traceKnown(jobId: string, step: JobStep, detail?: string) {
    const j = this.recentJobs.get(jobId);
    if (j) this.tracer(jobId, j.type, j.receivedAt)(step, detail);
  }

  /** Why this phone turns the offer down right now, or null. The reason is spelled out for the job step line. */
  private refusal(p: JobOfferPayload): { reason: NonNullable<JobAckPayload['reason']>; detail: string } | null {
    if (!JOB_TYPES_RUN.has(p.type)) return { reason: 'unsupported', detail: `this SDK does not run ${p.type} jobs` };
    if (this.tier === 'none') return { reason: 'unsupported', detail: `no local model on this phone (tier none${this.tierReason ? `, ${this.tierReason}` : ''})` };
    if (!(this.config.acceptJobs ?? true)) return { reason: 'unsupported', detail: 'acceptJobs is false in the SDK config' };
    if (!this.modelUsable()) return { reason: 'unsupported', detail: `the model is ${this.modelStatus.phase}, not ready or loaded` };
    if (!this.alive) return { reason: 'unsupported', detail: 'the SDK was shut down' };
    const paused = this.pauseReason();
    if (paused) return { reason: 'paused', detail: `background work is paused (${paused})` };
    const lane = laneOf(p.type);
    if (this.overBudget(lane)) {
      return { reason: 'paused', detail: `the ${lane} background budget is used up: ${secs(this.budgetMs(lane))} of model time in the last hour, limit ${secs(this.budgetLimitMs(lane))} ${this.onMains() ? 'while charging' : 'on battery'}` };
    }
    const r = this.runningJob;
    if (r && p.type !== 'call.scribe') return { reason: 'busy', detail: `still running job ${r.jobId} (${r.type})` };
    return null;
  }

  private refuse(p: JobOfferPayload, reason: NonNullable<JobAckPayload['reason']>, detail: string, trace: JobTrace) {
    trace('refused', `${reason}: ${detail}`);
    this.fire('job.ack', { jobId: p.jobId, leaseToken: p.leaseToken, accepted: false, reason }, { attempts: 1 });
  }

  /**
   * A job offer, start to end. Every accepted job ends in exactly one of
   * job.result, job.release or a backend cancel: a watchdog at the job's
   * deadline (or MAX_JOB_RUN_MS) stops waiting for the engine and releases
   * it, and job.progress keeps the lease alive while the engine works, for
   * every job type (a slow phone can need longer than one lease).
   */
  private async onOffer(p: JobOfferPayload) {
    const receivedAt = Date.now();
    const trace = this.tracer(p.jobId, p.type, receivedAt);
    this.rememberJob(p.jobId, p.type, receivedAt);
    const leaseEnd = Date.parse(p.leaseExpiresAt), deadlineAt = Date.parse(p.deadline);
    const leaseLeft = Number.isNaN(leaseEnd) ? NaN : leaseEnd - this.now();
    trace('offer', `attempt ${p.attempt}, lease ${secs(leaseLeft)}, deadline in ${secs(deadlineAt - this.now())}`);
    const no = this.refusal(p);
    if (no) return this.refuse(p, no.reason, no.detail, trace);
    let input: JobInput;
    try { input = await this.open<JobInput>('job.offer', p.jobId, p.input); } catch {
      this.emitError({ code: 'E_DECRYPT_FAILED', message: `job ${p.jobId} input did not open`, retryable: false });
      return this.refuse(p, 'decrypt_failed', "the sealed input did not open with this device's key", trace);
    }
    if (input.type !== p.type) {
      this.emitError({ code: 'E_PAYLOAD_INVALID', message: `job ${p.jobId}: input type ${input.type} != ${p.type}`, retryable: false });
      return this.refuse(p, 'unsupported', `input type ${input.type} does not match the offer`, trace);
    }
    // Lease-tied sends retry until the lease (as extended by job.progress) has run out, plus the backend's grace.
    let leaseUntil = Number.isNaN(leaseLeft) ? NaN : Date.now() + leaseLeft;
    const sendDeadline = () => (Number.isNaN(leaseUntil) ? undefined : leaseUntil + 10000);
    await this.send('job.ack', { jobId: p.jobId, leaseToken: p.leaseToken, accepted: true }, { attempts: 2, deadline: sendDeadline() })
      .then(() => trace('acked'), (e) => trace('acked', 'the ack could not be sent; running the job anyway', infoOf(e)));
    const startedAt = this.iso();
    this.ev.emit('job.started', { jobId: p.jobId, type: p.type, attempt: p.attempt, startedAt });
    if (input.type === 'call.scribe') {
      trace('started', 'scribe: checks topics every few lines until the call ends');
      return this.startScribe(p, input);
    }

    const abort = new SimpleAbort();
    const job: RunningJob = { jobId: p.jobId, type: p.type, leaseToken: p.leaseToken, leaseExpiresAt: leaseEnd, abort };
    this.runningJob = job;
    this.maybeHeartbeat();
    const t0 = Date.now();
    const meter: Meter = { tokensIn: 0, tokensOut: 0 };
    const ttl = Number.isNaN(leaseLeft) ? 30000 : Math.max(PROGRESS_MIN_MS * 3, leaseLeft);
    const progressEvery = Math.max(PROGRESS_MIN_MS, Math.min(PROGRESS_MAX_MS, Math.floor(ttl / 3)));
    const progress = g.setInterval(() => {
      trace('progress', `keeping the lease (every ${secs(progressEvery)})`);
      void this.send('job.progress', { jobId: p.jobId, leaseToken: p.leaseToken, progress: 0 }, { attempts: 1 })
        .then(() => { leaseUntil = Date.now() + ttl; }, () => undefined);
    }, progressEvery);
    const giveUpMs = Math.max(0, Math.min(Number.isNaN(deadlineAt) ? Infinity : deadlineAt - this.now(), MAX_JOB_RUN_MS));
    const hardStop = g.setTimeout(() => abort.abort('timeout'), giveUpMs);
    // The soft stop: a few seconds before the deadline the running model step is cancelled (not the job),
    // so a job that has something useful (spark.detect's subject) can still send it in time.
    const softMs = Math.max(0, giveUpMs - Math.min(SOFT_STOP_MS, giveUpMs / 10));
    const budget: JobBudget = { softAt: Date.now() + softMs, soft: new SimpleAbort(), outOfTime: false };
    const softStop = g.setTimeout(() => { budget.outOfTime = true; budget.soft.abort('deadline'); }, softMs);
    trace('started', `on the ${this.tier} model${this.modelStatus.version ? ` ${this.modelStatus.version}` : ''} (${this.modelStatus.phase}), gives up in ${secs(giveUpMs)}, progress every ${secs(progressEvery)}`);
    const finish = (outcome: 'succeeded' | 'released' | 'failed' | 'cancelled', error?: SparksErrorInfo) => {
      g.clearInterval(progress);
      g.clearTimeout(hardStop);
      g.clearTimeout(softStop);
      if (this.runningJob === job) this.runningJob = null;
      this.ev.emit('job.finished', { jobId: p.jobId, type: p.type, attempt: p.attempt, startedAt, outcome, error });
      this.maybeHeartbeat();
    };
    let output: JobOutput;
    try {
      // abortable: the job ends when the watchdog or a cancel fires, even if the engine never answers.
      output = await abortable(this.runJob(input, abort, meter, trace, budget), abort);
    } catch (e) {
      const err = infoOf(e);
      if (abort.reason === 'cancelled') {
        trace('cancelled', 'the backend cancelled it');
        return finish('cancelled', err);
      }
      if (abort.reason === 'timeout' || (budget.outOfTime && !abort.aborted)) {
        const info: SparksErrorInfo = {
          code: 'E_TIMEOUT', retryable: true,
          message: `${p.type} did not finish within ${secs(giveUpMs)} (the engine had not answered); released so the backend can offer it again`,
        };
        this.fire('job.release', { jobId: p.jobId, leaseToken: p.leaseToken, reason: 'error', error: info }, { attempts: 2, deadline: sendDeadline() });
        trace('timeout', 'job.release sent (reason error)', info);
        return finish('failed', info);
      }
      const reason: JobReleasePayload['reason'] = abort.reason === 'memory' ? 'error'
        : err.code === 'E_PAUSED' ? this.releaseReason() : err.code === 'E_PREEMPTED' ? 'preempted' : 'error';
      this.fire('job.release', { jobId: p.jobId, leaseToken: p.leaseToken, reason, error: err }, { attempts: 2, deadline: sendDeadline() });
      trace('released', `reason ${reason}${abort.reason === 'memory' ? ' (memory warning)' : ''}`, err);
      return finish(reason === 'error' ? 'failed' : 'released', err);
    }
    const wallMs = Date.now() - t0;
    await this.send('job.result', {
      jobId: p.jobId, leaseToken: p.leaseToken, type: p.type, idempotencyKey: p.idempotencyKey, output,
      metrics: { wallMs, tokensIn: meter.tokensIn, tokensOut: meter.tokensOut, modelVersion: this.modelStatus.version ?? '', tier: this.tier },
    }, { deadline: sendDeadline() }).then(() => {
      trace('result.sent', `${secs(wallMs)} of work, ~${meter.tokensIn} tokens in, ${meter.tokensOut} out`);
      finish('succeeded');
    }, (e) => {
      const info = infoOf(e);
      trace('result.failed', 'job.result could not be sent before the lease ran out', info);
      finish('failed', info);
    });
  }

  private releaseReason(): JobReleasePayload['reason'] {
    switch (this.pauseReason()) {
      case 'app_background': return 'app_background';
      case 'low_battery': case 'low_power_mode': return 'low_battery';
      case 'thermal': return 'thermal';
      default: return 'paused';
    }
  }

  private onCancel(jobId: string, reason?: string) {
    if (this.runningJob?.jobId !== jobId) this.traceKnown(jobId, 'cancelled', `the backend cancelled it (${reason ?? 'no reason'})${this.scribe?.jobId === jobId ? '' : ', not running here'}`);
    if (this.scribe?.jobId === jobId) {
      this.stopScribe();
      this.ev.emit('job.finished', { jobId, type: 'call.scribe', attempt: 1, startedAt: this.iso(), outcome: 'cancelled' });
      return;
    }
    if (this.runningJob?.jobId === jobId) this.runningJob.abort.abort('cancelled');
  }

  private async runJob(input: JobInput, abort: SimpleAbort, meter: Meter, trace?: JobTrace, budget?: JobBudget): Promise<JobOutput> {
    return J.runJob(input, this.gen(P_BACKGROUND, abort, meter, trace, laneOf(input.type), budget), {
      membersOf: async (chatId) => (await this.store.chat(chatId)).members,
      embed: (text) => this.embed(text, P_BACKGROUND, abort),
      outOfTime: () => !!budget?.outOfTime,
      note: (detail) => trace?.('partial', detail),
    });
  }

  // =============================================================== scribe

  private startScribe(p: JobOfferPayload, input: Extract<JobInput, { type: 'call.scribe' }>) {
    this.stopScribe();
    const last = input.topics[input.topics.length - 1];
    const st: ScribeState = {
      jobId: p.jobId, leaseToken: p.leaseToken, callId: input.callId, chatId: input.chatId,
      current: last ? { topicId: last.topicId, title: last.title } : null,
      topics: [...input.topics], segments: [...input.recentSegments], participants: input.participants,
      newSince: input.recentSegments.length, checking: false, timers: [], abort: new SimpleAbort(),
      seenUpToMs: -Infinity,
      live: input.liveSummary ? new J.LiveSummaryTracker(input.liveSummary, {
        topics: input.topics, segments: input.recentSegments, summaries: input.summaries,
        // A scribe from the call's start (nothing before it) hears every topic whole.
        startedAtMs: input.topics.length || input.recentSegments.length ? undefined : 0,
      }) : null,
      summarizing: false, shiftPendingUntil: 0,
    };
    for (const x of input.summaries ?? []) this.onTopicSummary(x, false);
    this.scribe = st;
    st.timers.push(g.setInterval(() => this.fire('job.progress', { jobId: st.jobId, leaseToken: st.leaseToken, progress: 0 }, { attempts: 1 }), 20000));
    st.timers.push(g.setInterval(() => { void this.scribeCheck(); void this.summaryCheck(); }, this.thresholds.scribeIntervalMs));
    this.maybeHeartbeat();
  }

  private stopScribe() {
    if (!this.scribe) return;
    this.scribe.timers.forEach((t) => g.clearInterval(t));
    this.scribe.abort.abort('cancelled');
    this.scribe = null;
    this.maybeHeartbeat();
  }

  private feedScribe(seg: TranscriptSegment) {
    const st = this.scribe;
    if (!st || st.callId !== seg.callId || !seg.final) return;
    st.segments.push(seg);
    if (st.segments.length > 40) st.segments.shift();
    st.live?.addLine(seg);
    if (++st.newSince >= this.thresholds.scribeMinNewSegments) void this.scribeCheck();
    void this.summaryCheck();
  }

  /**
   * Live topic summary (module 1.3.1): the current topic, once enough new
   * lines arrived and its interval passed (LiveSummaryTracker.due), with the
   * outline-map prompt over the topic's lines (J.topicSummary). The backend
   * checks it again and broadcasts call.topic_summary.
   */
  private async summaryCheck() {
    const st = this.scribe;
    // Only lines a topic check has seen, and not while a topic change is in flight (they may belong to the new topic).
    if (!st?.live || st.summarizing || st.checking || Date.now() < st.shiftPendingUntil || !this.modelUsable()) return;
    const known = (await this.store.chat(st.chatId).catch(() => null))?.members ?? [];
    const people = [...st.participants, ...known.filter((m) => !st.participants.some((p) => p.userId === m.userId))];
    if (st.summarizing || st.checking) return;
    const due = st.live.due(Date.now(), people, st.seenUpToMs);
    if (!due) return;
    st.summarizing = true;
    try {
      const summary = await J.topicSummary(this.gen(P_BACKGROUND, st.abort, undefined, undefined, 'live'), due);
      if (!summary || this.scribe !== st) return;
      this.fire('call.topic_summary_proposal', {
        callId: st.callId, jobId: st.jobId, leaseToken: st.leaseToken, topicId: due.topicId, summary, basedOnSegmentId: due.basedOnSegmentId,
      }, { attempts: 1 });
    } catch (e) {
      this.log('debug', 'topic summary failed', e);
    } finally {
      st.summarizing = false;
    }
  }

  /** call.topic_summary from the backend (or a scribe input's summaries, emit false): kept per call, newest per topic. */
  private onTopicSummary(t: TopicSummary, emit = true) {
    let m = this.topicSummaries.get(t.callId);
    if (!m) {
      m = new Map();
      this.topicSummaries.set(t.callId, m);
      if (this.topicSummaries.size > TOPIC_SUMMARY_CALLS) this.topicSummaries.delete(this.topicSummaries.keys().next().value!);
    }
    const had = m.get(t.topicId);
    if (had && had.updatedAtMs > t.updatedAtMs) return;   // out of order
    m.set(t.topicId, t);
    if (this.scribe?.callId === t.callId) this.scribe.live?.setSummary(t);
    if (emit) this.ev.emit('call.topicSummary', t);
  }

  /** Every 15 s or 8 segments: subject_line for the first topic, then topic_shift (ARCHITECTURE §4.2). */
  private async scribeCheck() {
    const st = this.scribe;
    if (!st || !st.newSince || st.checking || !this.modelUsable()) return;
    st.checking = true;
    st.newSince = 0;
    const since = st.seenUpToMs;
    st.seenUpToMs = st.segments[st.segments.length - 1]?.startMs ?? since;
    try {
      const p = await J.scribeProposal(this.gen(P_BACKGROUND, st.abort, undefined, undefined, 'live'), st, since);
      if (!p || this.scribe !== st) return;
      st.shiftPendingUntil = Date.now() + SHIFT_PENDING_MS;
      this.fire('call.topic_proposal', {
        callId: st.callId, jobId: st.jobId, leaseToken: st.leaseToken, title: p.title,
        returningToTopicId: p.returningToTopicId, startedAtMs: p.startedAtMs, confidence: 0.8,
      }, { attempts: 1 });
    } catch (e) {
      this.log('debug', 'scribe check failed', e);
    } finally {
      st.checking = false;
      if (this.scribe === st) void this.summaryCheck();
    }
  }

  // ========================================================== local store

  private storeMessages(chatId: ChatId, msgs: ChatMessage[]): ChatMessage[] {
    const s = this.store.peek(chatId);
    const added: ChatMessage[] = [];
    for (const msg of msgs) {
      if (msg.bot || msg.senderId === SPARKS_BOT_ID) continue;   // Sparks bot posts are not conversation: never hinted, indexed or searched
      const prev = s.messages.get(msg.messageId);
      if (!prev) added.push(msg);
      s.messages.set(msg.messageId, { ...prev, ...msg, text: (msg.text ?? '').slice(0, 1000), sparkId: msg.sparkId ?? prev?.sparkId ?? null });
    }
    if (msgs.length) this.store.touch(chatId, 'messages');
    return added;
  }

  private catalog(chatId: ChatId, states: ('active' | 'dormant')[]): SparkCatalogEntry[] {
    return [...this.store.peek(chatId).sparks.values()].filter((s) => states.includes(s.state))
      .map((s) => ({ sparkId: s.sparkId, subject: s.subject, state: s.state, summary: s.summary?.text ?? null, lastMessageAt: s.lastMessageAt }));
  }

  private findSpark(sparkId: SparkId): { chatId: ChatId; spark: Spark } | null {
    for (const chatId of this.store.chatIds()) {
      const sp = this.store.peek(chatId).sparks.get(sparkId);
      if (sp) return { chatId, spark: sp };
    }
    return null;
  }

  private ensureReady() { if (!this.alive) throw sparksError('E_NOT_INITIALIZED', 'SDK was shut down', false); }
  private needsModel() { if (this.tier === 'none') throw sparksError('E_DEVICE_UNSUPPORTED', 'This phone has no local model', false); }

  /**
   * message.spark_hint for one of this user's own messages: a reply to a
   * message in an active Spark goes to that Spark; otherwise the model's
   * assign_message over the active Sparks and the three messages before it,
   * at background priority (counted in the background budget). No hint when
   * the answer did not parse: the backend then runs spark.assign elsewhere.
   */
  private async hint(chatId: ChatId, m: ChatMessage): Promise<void> {
    const s = this.store.peek(chatId);
    // A reply goes where the message it answers is: no model run (the 1.2.1 backend threads it too; this covers older ones).
    const parent = m.replyToMessageId ? s.messages.get(m.replyToMessageId) : undefined;
    if (parent?.sparkId && s.sparks.get(parent.sparkId)?.state === 'active') {
      this.fire('message.spark_hint', { chatId, messageId: m.messageId, seq: m.seq, sparkId: parent.sparkId, score: 1, method: 'model' });
      return;
    }
    const recent = [...s.messages.values()]
      .filter((x) => x.seq < m.seq && !x.deleted && x.kind === 'text' && x.text.trim())
      .sort((a, b) => a.seq - b.seq).slice(-3)
      .map((x) => ({ who: T.nameOf(s.members, x.senderId), text: x.text }));
    const h = await J.modelHint(this.gen(P_BACKGROUND), this.catalog(chatId, ['active']), recent, { who: T.nameOf(s.members, m.senderId), text: m.text });
    if (!h) return;
    this.fire('message.spark_hint', { chatId, messageId: m.messageId, seq: m.seq, sparkId: h.sparkId, score: h.score, method: 'model' });
  }

  // ============================================================ Sparks API

  private makeSparksApi(): SparksApi {
    const self = this;
    return {
      async ingest(chatId, messages, options): Promise<IngestResult> {
        self.ensureReady();
        const s = await self.store.chat(chatId);
        if (options?.members) { s.members = options.members; self.store.touch(chatId, 'members'); }
        const added = self.storeMessages(chatId, messages);
        let hinted = 0;
        // Same condition as the heartbeat's `available`: the backend waits for a hint only from such a phone.
        if (self.available()) {
          for (const m of added) {
            if (m.senderId !== self.config.userId || m.kind !== 'text' || m.postedInSpark || m.sparkId || m.deleted) continue;
            if (self.now() - Date.parse(m.sentAt) > 5 * 60000) continue;
            hinted++;
            void self.hint(chatId, m).catch((e) => self.log('debug', 'hint failed', e));
          }
        }
        return { stored: added.length, hinted };
      },
      async setMembers(chatId, members) {
        self.ensureReady();
        const s = await self.store.chat(chatId);
        s.members = members;
        self.store.touch(chatId, 'members');
        if (!self.requestedContext.has(chatId)) {
          self.requestedContext.add(chatId);
          const sinceSeq = Math.max(0, ...[...s.messages.values()].map((m) => m.seq));
          self.fire('context.request', { scope: 'chat', chatId, sinceSeq, limit: 500 });
        }
      },
      getSparks(chatId) {
        return [...self.store.peek(chatId).sparks.values()].sort((a, b) => Date.parse(b.lastMessageAt) - Date.parse(a.lastMessageAt));
      },
      onTopic(listener) { return self.ev.on('spark', listener); },
      async summarize(sparkId, options): Promise<SparkSummary> {
        self.ensureReady(); self.needsModel();
        const found = self.findSpark(sparkId);
        if (!found) throw sparksError('E_INVALID_ARGUMENT', 'unknown sparkId', false, { field: 'sparkId' });
        const s = await self.store.chat(found.chatId);
        const msgs = [...s.messages.values()].filter((m) => m.sparkId === sparkId && !m.deleted && m.seq > (options?.sinceSeq ?? -1)).sort((a, b) => a.seq - b.seq).slice(-60);
        const previous = options?.sinceSeq !== undefined ? found.spark.summary?.text ?? null : null;
        const text = await T.runningSummary(self.gen(P_INTERACTIVE, options?.signal), previous,
          msgs.map((m) => ({ who: T.nameOf(s.members, m.senderId), text: m.text })), s.members.map((m) => m.displayName));
        if (!text) throw sparksError('E_ENGINE', 'the model did not produce a faithful summary', true);
        const maxWords = options?.maxWords;
        const out = maxWords ? T.words(text).length > maxWords ? `${text.split(/\s+/).slice(0, maxWords).join(' ')}…` : text : text;
        return { text: out, basedOnSeq: Math.max(0, ...msgs.map((m) => m.seq)), updatedAt: self.iso() };
      },
      async matchExisting(chatId, query, options) {
        self.ensureReady();
        const min = options?.minScore ?? self.thresholds.duplicateMinScore;
        const states: ('active' | 'dormant')[] = options?.includeDormant === false ? ['active'] : ['active', 'dormant'];
        const entries = self.catalog(chatId, states);
        if (!entries.length) return [];
        const limit = options?.limit ?? 3;
        if (self.tier === 'none' || !self.modelUsable()) {
          return entries.map((e): SparkMatch => ({ sparkId: e.sparkId, subject: e.subject, state: e.state, method: 'lexical',
            score: Math.round(Math.max(trigramSimilarity(query.subject, e.subject), trigramSimilarity(`${query.subject} ${query.seedText ?? ''}`, `${e.subject} ${e.summary ?? ''}`)) * 100) / 100 }))
            .filter((m) => m.score >= min).sort((a, b) => b.score - a.score).slice(0, limit);
        }
        // The trained match_existing task (manual mode) decides among the six closest Sparks. Embedding similarity
        // could not tell related from unrelated subjects, so it no longer ranks or scores here.
        const top = J.rankCatalog(entries, `${query.subject} ${query.seedText ?? ''}`, 6);
        const seedName = T.nameOf(self.store.peek(chatId).members, self.config.userId);
        const verdict = await T.matchExisting(self.gen(P_INTERACTIVE), { mode: 'manual', subject: query.subject, seed: query.seedText ? { who: seedName, text: query.seedText } : null }, top).catch(() => null);
        if (verdict) {
          const hit = verdict.sparkId && verdict.confidence >= J.MATCH_MIN_CONFIDENCE ? top.find((e) => e.sparkId === verdict.sparkId) : undefined;
          return hit ? [{ sparkId: hit.sparkId, subject: hit.subject, state: hit.state, score: Math.round(verdict.confidence * 100) / 100, method: 'llm' }] : [];
        }
        // The model's answer did not parse: lexical, as on a phone without a model.
        return entries.map((e): SparkMatch => ({ sparkId: e.sparkId, subject: e.subject, state: e.state, method: 'lexical',
          score: Math.round(Math.max(trigramSimilarity(query.subject, e.subject), trigramSimilarity(`${query.subject} ${query.seedText ?? ''}`, `${e.subject} ${e.summary ?? ''}`)) * 100) / 100 }))
          .filter((m) => m.score >= min).sort((a, b) => b.score - a.score).slice(0, limit);
      },
      async startSpark(req: StartSparkRequest): Promise<StartSparkResult> {
        self.ensureReady();
        const subject = req.subject.trim();
        if (!subject || subject.length > 48) throw sparksError('E_INVALID_ARGUMENT', 'subject must be 1 to 48 characters', false, { field: 'subject' });
        const resolution = req.resolution ?? 'auto';
        if (resolution === 'auto') {
          const seed = (await self.store.chat(req.chatId)).messages.get(req.seedMessageId);
          const candidates = await self.sparks.matchExisting(req.chatId, { subject, seedText: seed?.text });
          if (candidates.length) return { status: 'needs_choice', candidates };
        }
        const res = resolution === 'auto' ? 'new' : resolution;
        const done = new Promise<SparkTopicEvent>((resolve, reject) => {
          self.pendingStarts.set(req.seedMessageId, resolve);
          g.setTimeout(() => { if (self.pendingStarts.delete(req.seedMessageId)) reject(sparksError('E_TIMEOUT', 'no spark.event within 10 s', true)); }, 10000);
        });
        await self.send('spark.create', { clientRequestId: uuidv4(), chatId: req.chatId, seedMessageId: req.seedMessageId, subject, resolution: res });
        const e = await done;
        return e.kind === 'created' ? { status: 'created', spark: e.spark } : { status: 'attached', spark: e.spark };
      },
      async suggestMerges(chatId, options) {
        self.ensureReady(); self.needsModel();
        const all = self.catalog(chatId, ['active', 'dormant']).slice(0, 30);
        const vecs = new Map<SparkId, number[]>();
        for (const e of all) vecs.set(e.sparkId, await self.embed(`${e.subject}. ${e.summary ?? ''}`.trim(), P_INTERACTIVE));
        const out: MergeSuggestion[] = [];
        for (let i = 0; i < all.length; i++) for (let j = i + 1; j < all.length; j++) {
          const score = cosine(vecs.get(all[i].sparkId)!, vecs.get(all[j].sparkId)!);
          if (score < self.thresholds.duplicateMinScore) continue;
          const [src, dst] = Date.parse(all[i].lastMessageAt) < Date.parse(all[j].lastMessageAt) ? [all[i], all[j]] : [all[j], all[i]];
          out.push({ sourceSparkId: src.sparkId, targetSparkId: dst.sparkId, score: Math.round(score * 100) / 100, reason: `"${src.subject}" looks like the same subject as "${dst.subject}".` });
        }
        return out.sort((a, b) => b.score - a.score).slice(0, options?.limit ?? 3);
      },
      async suggestRolePings(sparkId): Promise<RolePingSuggestion[]> {
        self.ensureReady(); self.needsModel();
        const found = self.findSpark(sparkId);
        if (!found) return [];
        const members = (await self.store.chat(found.chatId)).members;
        const roles = [...new Set(members.flatMap((m) => m.roles))].map((role) => {
          const holders = members.filter((m) => m.roles.includes(role));
          return { role, userIds: holders.map((m) => m.userId), names: holders.map((m) => m.displayName) };
        });
        return (await T.rolePing(self.gen(P_INTERACTIVE), found.spark.subject, found.spark.summary?.text ?? null, roles)) ?? [];
      },
      async findRelated(chatId, query, options): Promise<RelatedMessage[]> {
        self.ensureReady(); self.needsModel();
        const s = await self.store.chat(chatId);
        const recent = [...s.messages.values()].filter((m) => !m.deleted && m.text.trim()).sort((a, b) => b.seq - a.seq).slice(0, 300);
        const q = await self.embed(query, P_INTERACTIVE);
        const out: RelatedMessage[] = [];
        for (const message of recent) out.push({ message, score: cosine(q, await self.embed(message.text, P_INTERACTIVE)) });
        return out.sort((a, b) => b.score - a.score).slice(0, options?.limit ?? 5).map((r) => ({ ...r, score: Math.round(r.score * 100) / 100 }));
      },
    };
  }

  // ============================================================ Calls API

  private callClock(callId: CallId) {
    const s = this.sessions.get(callId);
    return this.now() - Date.parse(s?.opts.callStartedAt ?? this.iso());
  }

  private effectiveMute(s: Session) { return s.userMuted || this.gameState === 'trivia'; }

  private totalsOf(callId: CallId): ListenTotals {
    let t = this.listenTotals.get(callId);
    if (!t) {
      t = { listenedMs: 0, unmutedMs: 0, lines: 0 };
      this.listenTotals.set(callId, t);
      // Only recent calls matter: keep the last 20.
      if (this.listenTotals.size > 20) this.listenTotals.delete(this.listenTotals.keys().next().value as CallId);
    }
    return t;
  }

  /** Mute state changed (or a report is due): fold the time since the last change into the totals. */
  private settleListening(s: Session, nowMs = Date.now()) {
    const t = this.totalsOf(s.opts.callId);
    t.listenedMs += Math.max(0, nowMs - s.runStartedAt);
    s.runStartedAt = nowMs;
    if (s.unmutedSince !== null) {
      t.unmutedMs += Math.max(0, nowMs - s.unmutedSince);
      s.unmutedSince = nowMs;
    }
  }

  /** call.listening: whether this phone was really listening on the call (SDK 1.2.8). Best effort. */
  private reportListening(s: Session, state: 'on' | 'off') {
    this.settleListening(s);
    const t = this.totalsOf(s.opts.callId);
    this.fire('call.listening', {
      callId: s.opts.callId, userId: this.config.userId, state,
      listenedMs: Math.round(t.listenedMs), unmutedMs: Math.round(t.unmutedMs), lines: t.lines, at: this.iso(),
    }, { attempts: 3 });
  }

  private applyMute(s: Session) {
    const muted = this.effectiveMute(s);
    this.settleListening(s);
    s.unmutedSince = muted ? null : Date.now();
    this.native.asrSetMuted(s.opts.callId, muted);
  }

  private onAsrLine(e: NativeAsrLineEvent) {
    const s = this.sessions.get(e.callId);
    if (!s) return;
    if (!e.final && !s.opts.partials) return;
    let u = s.lines.get(e.lineId);
    if (!u) {
      u = { segmentId: `seg_${this.deviceId.slice(-6)}_${this.segRun}_${String(++this.segCounter).padStart(5, '0')}`, startMs: Math.round(s.baseMs + e.startS * 1000) };
      s.lines.set(e.lineId, u);
    }
    const seg: TranscriptSegment = {
      segmentId: u.segmentId, callId: e.callId, userId: this.config.userId, deviceId: this.deviceId,
      startMs: u.startMs, endMs: Math.round(s.baseMs + (e.startS + e.durationS) * 1000), text: e.text.trim(),
      final: e.final, locale: this.config.locale ?? 'en-US', engine: 'moonshine-base', origin: 'local',
    };
    this.ev.emit('call.segment', seg);
    if (!e.final) return;
    s.lines.delete(e.lineId);
    this.totalsOf(e.callId).lines++;
    this.feedScribe(seg);
    const { origin: _o, ...wire } = seg;
    this.fire('call.segment', { segment: { ...wire, final: true } });
    const ctx = s.opts.commands;
    if (ctx && ctx.canIssue) void this.detectCommand(s, seg, ctx);
  }

  private async detectCommand(s: Session, seg: TranscriptSegment, ctx: CommandContext) {
    try {
      const intent = await this.calls.parseCommand(seg.text, ctx);
      if (!intent) return;
      const event: CallCommandEvent = { callId: s.opts.callId, intent, utterance: seg.text, segmentId: seg.segmentId, expiresAt: this.iso(this.now() + 15000), commandId: `cmd_${uuidv4().slice(0, 8)}` };
      this.pendingCommands.set(event.commandId, event);
      this.ev.emit('call.command', event);
    } catch (e) {
      this.log('debug', 'command parse failed', e);
    }
  }

  private makeCallsApi(): CallsApi {
    const self = this;
    return {
      async startTranscription(opts): Promise<TranscriptionSession> {
        self.ensureReady();
        if (self.calls.getConsent(opts.callId).decision !== 'accepted') throw sparksError('E_CONSENT_REQUIRED', 'The user has not accepted the transcription notice', false);
        if ((opts.audioSource ?? 'external') === 'microphone') {
          throw sparksError('E_TRANSCRIPTION_UNAVAILABLE', "audioSource 'microphone' is not implemented yet; feed audio through SparksAudioSink ('external')", false);
        }
        if (!self.info.transcription) {
          throw sparksError('E_TRANSCRIPTION_UNAVAILABLE', 'The speech model is not downloaded yet (model.ensure() with a manifest that lists `asr`), or this build has no speech runtime', true);
        }
        const session: Session = {
          opts: { callId: opts.callId, chatId: opts.chatId, callStartedAt: opts.callStartedAt, partials: opts.partials !== false, commands: opts.commands ?? false },
          userMuted: false, baseMs: 0, lines: new Map(), startedAt: self.iso(),
          runStartedAt: Date.now(), unmutedSince: null, reportTimer: null,
        };
        const previous = self.sessions.get(opts.callId);
        if (previous?.reportTimer) { clearInterval(previous.reportTimer); previous.reportTimer = null; }
        self.sessions.set(opts.callId, session);
        session.baseMs = self.callClock(opts.callId);
        try { await self.native.asrStart(opts.callId, session.opts.partials); } catch (e) {
          self.sessions.delete(opts.callId);
          throw fromNative(e, 'E_TRANSCRIPTION_UNAVAILABLE');
        }
        session.runStartedAt = Date.now();
        if (self.effectiveMute(session)) self.native.asrSetMuted(opts.callId, true);
        else session.unmutedSince = Date.now();
        self.reportListening(session, 'on');
        session.reportTimer = setInterval(() => { if (self.sessions.get(opts.callId) === session) self.reportListening(session, 'on'); }, LISTENING_REPORT_MS);
        return {
          callId: opts.callId, engine: 'moonshine-base', startedAt: session.startedAt,
          setMuted: (muted) => { session.userMuted = muted; self.applyMute(session); },
          stop: () => self.calls.stopTranscription(opts.callId),
        };
      },
      async stopTranscription(callId) {
        const s = self.sessions.get(callId);
        if (!s) return;
        if (s.reportTimer) clearInterval(s.reportTimer);
        s.reportTimer = null;
        await self.native.asrStop(callId).catch(() => undefined);   // delivers the last line as final first
        self.reportListening(s, 'off');
        // Only this run's session: a new run for the same call may have started meanwhile.
        if (self.sessions.get(callId) === s) self.sessions.delete(callId);
      },
      pushAudio(callId, frame) {
        const s = self.sessions.get(callId);
        if (!s || self.effectiveMute(s)) return;
        // frame.startMs is on the call clock; the native side counts from asrStart.
        self.native.asrPush(callId, frame.pcm16Base64, Math.max(0, frame.startMs - s.baseMs));
      },
      onSegment(l) { return self.ev.on('call.segment', l); },
      onTopicShift(l) { return self.ev.on('call.topicShift', l); },
      onTopicSummary(l) { return self.ev.on('call.topicSummary', l); },
      getTopicSummaries(callId) { return [...(self.topicSummaries.get(callId)?.values() ?? [])]; },
      onCommand(l) { return self.ev.on('call.command', l); },
      async confirmCommand(commandId) {
        const c = self.pendingCommands.get(commandId);
        if (!c) throw sparksError('E_INVALID_ARGUMENT', 'unknown commandId', false, { field: 'commandId' });
        self.pendingCommands.delete(commandId);
        if (Date.parse(c.expiresAt) < self.now()) throw sparksError('E_TIMEOUT', 'command expired', false);
        await self.send('call.command', { commandId, callId: c.callId, issuerUserId: self.config.userId, segmentId: c.segmentId, utterance: c.utterance, intent: c.intent });
      },
      onPinSuggestion(l) { return self.ev.on('call.pinSuggestion', l); },
      async parseCommand(utterance, context): Promise<CallCommandIntent | null> {
        if (self.tier === 'none' || !self.modelUsable()) return null;
        // The speaker is this user; their rank comes from any chat member list we hold.
        let me: ChatMember | undefined;
        for (const id of self.store.chatIds()) { me = self.store.peek(id).members.find((m) => m.userId === self.config.userId); if (me) break; }
        const name = context.members.find((m) => m.userId === self.config.userId)?.displayName ?? me?.displayName ?? 'Me';
        const rank = me?.rank ?? context.ranks[context.ranks.length - 1] ?? 'member';
        try { return await T.commandParse(self.gen(P_INTERACTIVE), utterance, context, { name, rank }); } catch { return null; }
      },
      async outline(input: OutlineInput, options): Promise<CallOutline> {
        self.needsModel();
        if (options?.signal?.aborted) throw sparksError('E_CANCELLED', 'aborted', false);
        const gen = self.gen(P_INTERACTIVE, options?.signal);
        const byTopic = input.topics.length ? [...input.topics].sort((a, b) => a.startedAtMs - b.startedAtMs)
          : [{ callId: input.callId, topicId: 't0', title: 'Call', colorIndex: 0, startedAtMs: 0, returning: false }];
        const spans: OutlineSpanSummary[] = [];
        const colorBySpan = new Map<string, number>();
        let k = 0;
        for (let i = 0; i < byTopic.length; i++) {
          const t = byTopic[i];
          const segs = input.segments.filter((s) => s.final && s.startMs >= t.startedAtMs && s.startMs < (byTopic[i + 1]?.startedAtMs ?? Infinity));
          // Spans of at most ~1,200 tokens (1 token ≈ 0.75 words), as the backend splits them.
          for (const chunk of J.chunkByWords(segs, 900)) {
            const spanId = `s${k++}`;
            colorBySpan.set(spanId, t.colorIndex);
            spans.push(await J.outlineSpan(gen, spanId, t.title, chunk, input.participants));
          }
        }
        const red = await J.outlineReduce(gen, spans);
        return {
          callId: input.callId, chatId: input.chatId, title: red.title, summary: red.summary, startedAt: input.startedAt, endedAt: input.endedAt,
          topics: red.topics.map((t, order) => {
            const ss = spans.filter((s) => t.spanIds.includes(s.spanId));
            return {
              topicId: `t${order}`, title: t.title, colorIndex: colorBySpan.get(t.spanIds[0]) ?? order, order, summary: t.summary,
              points: t.points, decisions: t.decisions, actionItems: t.actionItems,
              spans: ss.map((s) => ({ startMs: s.startMs, endMs: s.endMs })), speakerIds: [...new Set(ss.flatMap((s) => s.speakerIds))],
            };
          }),
          segmentCount: input.segments.length, generatedAt: self.iso(),
          generatedBy: { deviceIds: [self.deviceId], modelVersion: self.modelStatus.version ?? '' },
        };
      },
      getTranscriptionNotice() { return NOTICE; },
      getConsent(callId): ConsentState {
        const c = (callId && self.store.consents.get(`call:${callId}`)) || self.store.consents.get('always');
        return c && c.noticeVersion === NOTICE.version ? c : { noticeVersion: NOTICE.version, decision: 'unset' };
      },
      async recordConsent(d: ConsentDecision) {
        if (d.noticeVersion !== NOTICE.version) throw sparksError('E_INVALID_ARGUMENT', 'stale notice version', false, { field: 'noticeVersion' });
        if (d.scope === 'call' && !d.callId) throw sparksError('E_INVALID_ARGUMENT', 'callId is required for scope "call"', false, { field: 'callId' });
        const decidedAt = self.iso();
        self.store.consents.set(d.scope === 'always' ? 'always' : `call:${d.callId}`, { noticeVersion: d.noticeVersion, decision: d.decision, scope: d.scope, decidedAt });
        self.store.touchGlobal('consents');
        if (d.decision === 'declined') {
          for (const [id, s] of self.sessions) if (d.scope === 'always' || id === d.callId) { s.userMuted = true; self.applyMute(s); }
        }
        await self.send('call.consent', { userId: self.config.userId, noticeVersion: d.noticeVersion, decision: d.decision, scope: d.scope, callId: d.callId ?? null, decidedAt });
      },
    };
  }

  // ========================================================= Orchestrator
  // The in-game persona on the phone's model. Its prompt, sampling and native
  // checker keep the training contract's name ("warden"); the API is the Orchestrator.

  private orchestratorKey(req: OrchestratorSayRequest) {
    return req.cacheKey ?? `w_${hash32(JSON.stringify([req.moment, req.style, req.facts, req.maxWords ?? 0]))}`;
  }

  /** Generate, check, one retry, else null. */
  private async orchestratorWrite(req: OrchestratorSayRequest, signal: AbortSignalLike | undefined): Promise<{ line: OrchestratorLine } | { rejected: number }> {
    const input = T.wardenInput(req.moment, req.style, req.facts);
    const place = typeof req.facts.place === 'string' ? req.facts.place : '';
    let rejected = 0;
    for (let attempt = 0; attempt < 2; attempt++) {
      const r = await this.generate(T.wardenPrompt(input), { priority: P_WARDEN, ...T.WARDEN_SAMPLING, stop: '\n', signal });
      const text = this.native.wardenClean(r.text);
      const why = this.native.wardenCheck(text, req.moment, input, place, req.maxWords ?? 18);
      if (!why) {
        const secs = Math.max(0.001, (r.runMs - Math.max(0, r.firstTokenMs)) / 1000);
        return { line: { text, moment: req.moment, fromModel: true, rejected, cached: false, firstTokenMs: r.firstTokenMs >= 0 ? Math.round(r.firstTokenMs) : undefined, tokensPerSecond: r.tokensOut > 1 ? Math.round((r.tokensOut - 1) / secs * 10) / 10 : undefined } };
      }
      this.log('debug', 'orchestrator line rejected:', why, text);
      rejected++;
    }
    return { rejected };
  }

  private makeOrchestratorApi(): OrchestratorApi {
    const self = this;
    const speakOpts = (s: OrchestratorSayRequest['speak']) => (typeof s === 'object' ? s : {});
    return {
      async say(req) {
        if (!req || typeof req.fallback !== 'string' || !req.fallback) throw sparksError('E_INVALID_ARGUMENT', 'fallback is required', false, { field: 'fallback' });
        const key = self.orchestratorKey(req);
        let line: OrchestratorLine | null = null;
        const hit = self.store.warden.get(key);
        if (hit) line = { ...hit, cached: true };
        else if (self.tier !== 'none' && self.modelUsable()) {
          const abort = new SimpleAbort();
          const onOuter = () => abort.abort('cancelled');
          req.signal?.addEventListener('abort', onOuter);
          const timer = g.setTimeout(() => abort.abort('deadline'), req.deadlineMs ?? 2500);
          try {
            const r = await self.orchestratorWrite(req, abort);
            line = 'line' in r ? r.line : { text: req.fallback, moment: req.moment, fromModel: false, rejected: r.rejected, cached: false };
          } catch {
            line = null;   // never rejects for model reasons
          } finally {
            g.clearTimeout(timer);
            req.signal?.removeEventListener('abort', onOuter);
          }
        }
        if (req.signal?.aborted) throw sparksError('E_CANCELLED', 'aborted', false);
        line ??= { text: req.fallback, moment: req.moment, fromModel: false, rejected: 0, cached: false };
        self.ev.emit('orchestrator.line', line);
        self.ev.emit('warden.line', line);   // deprecated alias, until 1.3
        if (req.speak) void self.orchestrator.speak(line.text, speakOpts(req.speak)).catch(() => undefined);
        return line;
      },
      async prepare(req) {
        if (self.tier === 'none' || !self.modelUsable()) return;
        const key = self.orchestratorKey(req);
        if (self.store.warden.has(key)) return;
        const r = await self.orchestratorWrite(req, req.signal).catch(() => null);
        if (r && 'line' in r) self.store.putWarden(key, r.line);
      },
      async speak(text, options) {
        await self.native.speak(text, options?.rate ?? 1, options?.pitch ?? 1, options?.duckOthers ?? true);
      },
      stopSpeaking() { self.native.stopSpeaking(); },
    };
  }

  // ================================================================= root

  setGameState(state: GameState): void {
    const before = this.gameState;
    this.gameState = state;
    if ((before === 'trivia') !== (state === 'trivia')) {
      for (const s of this.sessions.values()) this.applyMute(s);
    }
    this.applyPauseMask();
    this.heartbeat(false);
  }

  async getCapabilities(): Promise<DeviceCapabilities> {
    return {
      tier: this.tier, platform: this.platform(), osVersion: this.info.osVersion, deviceModel: this.info.deviceModel, ramBytes: this.info.ramBytes,
      armDotProd: this.info.armDotProd, transcription: this.info.transcription, tierReason: this.tierReason,
    };
  }

  on<E extends keyof SparksEventMap>(event: E, listener: (payload: SparksEventMap[E]) => void): Unsubscribe {
    return this.ev.on(event, listener);
  }

  async wipe(): Promise<void> {
    this.stopScribe();
    if (this.runningJob) this.runningJob.abort.abort('cancelled');
    for (const id of [...this.sessions.keys()]) await this.calls.stopTranscription(id);
    await this.store.wipe();
    this.embedCache.clear();
    this.requestedContext.clear();
    await this.native.deleteDeviceKey(this.scope);
    // A new key is a new device: register it (the backend drops the old row on seeing it).
    await this.openKey();
    this.fire('device.register', this.registerPayload());
  }

  async shutdown(): Promise<void> {
    if (!this.alive) return;
    const job = this.runningJob;
    if (job) {
      job.abort.abort('cancelled');
      await this.send('job.release', { jobId: job.jobId, leaseToken: job.leaseToken, reason: 'paused' }, { attempts: 1 }).catch(() => undefined);
    }
    if (this.scribe) {
      const st = this.scribe;
      this.stopScribe();
      await this.send('job.release', { jobId: st.jobId, leaseToken: st.leaseToken, reason: 'paused' }, { attempts: 1 }).catch(() => undefined);
    }
    for (const id of [...this.sessions.keys()]) await this.calls.stopTranscription(id);
    await this.store.flush().catch(() => undefined);
    await this.native.unloadModel(-1).catch(() => undefined);
    this.dispose();
    if (singleton === this) singleton = null;
  }
}

/** Same scheme and host[:port]. Regex rather than URL: RN's URL polyfill lacks `origin`. */
function sameOrigin(a: string, b: string): boolean {
  const o = (u: string) => /^([a-z][a-z0-9+.-]*:\/\/[^/?#]+)/i.exec(u)?.[1].toLowerCase() ?? null;
  const x = o(a);
  return x !== null && x === o(b);
}
