/* sparks_asr.c: call transcription, everything except the model runner.
 *
 *   push (audio thread) -> ring -> worker: resample to 16 kHz -> Silero VAD
 *   per 32 ms frame -> utterance framing -> Moonshine (partials while open,
 *   one final at end of speech + 600 ms or 15 s) -> on_line
 *
 * The audio thread only copies into a single-producer ring of fixed slots: no
 * lock, no allocation, no model call (Moonshine's own streaming API takes a
 * lock that a running decode holds, which would stall the call's capture
 * callback). Everything else runs on one worker thread, which also owns the
 * capture clock: each slot carries the capture time of its first sample; a
 * run follows sample counts and starts again on a gap (mute, a pause in the
 * call stack's audio, a rate change), so segment times stay on the capture
 * clock however long the user was muted.
 *
 * Model calls go through spk_asr_engine (sparks_moonshine.c for real, a fake
 * in the tests), so all timing rules here are unit tested without weights. */
#define _POSIX_C_SOURCE 200809L
#include "sparks_core.h"

#include <math.h>
#include <pthread.h>
#include <stdatomic.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <unistd.h>

#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif

#define MS_TO_SAMPLES(ms) ((int64_t)(ms) * SPK_ASR_RATE / 1000)

static double now_ms(void) {
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return ts.tv_sec * 1000.0 + ts.tv_nsec / 1e6;
}

static void sleep_ms(int ms) {
    struct timespec ts = { ms / 1000, (long)(ms % 1000) * 1000000L };
    nanosleep(&ts, NULL);
}

/* ================================================================ resampler */
#define RS_ZEROS 16          /* zero crossings per side at the cutoff */
#define RS_BLOCK 4096        /* input accepted per inner pass         */

static double rs_kernel(double x, double fc, double half) {
    double ax = fabs(x);
    if (ax >= half) return 0.0;
    double t = 2.0 * fc * x;
    double sinc = fabs(t) < 1e-9 ? 1.0 : sin(M_PI * t) / (M_PI * t);
    double u = ax / half;   /* 0..1 */
    double w = 0.42 + 0.5 * cos(M_PI * u) + 0.08 * cos(2.0 * M_PI * u);   /* Blackman */
    return 2.0 * fc * sinc * w;
}

int spk_resampler_init(spk_resampler *r, int in_rate) {
    if (!r) return -1;
    memset(r, 0, sizeof *r);
    if (in_rate < 8000 || in_rate > 192000) return -1;
    r->in_rate = in_rate;
    if (in_rate == SPK_ASR_RATE) return 0;   /* pass-through */
    double lower = in_rate < SPK_ASR_RATE ? in_rate : SPK_ASR_RATE;
    double fc = 0.45 * lower / in_rate;         /* 0.9 x the lower Nyquist, cycles per input sample */
    r->cutoff = (float)fc;
    r->step = (double)in_rate / SPK_ASR_RATE;
    r->half = (int)ceil(RS_ZEROS / (2.0 * fc));
    r->table_len = r->half * SPK_RS_OVERSAMPLE + 2;
    r->table = malloc(sizeof(float) * (size_t)r->table_len);
    r->cap = 2 * r->half + RS_BLOCK + 2;
    r->buf = calloc((size_t)r->cap, sizeof(float));
    if (!r->table || !r->buf) { spk_resampler_free(r); return -1; }
    for (int i = 0; i < r->table_len; i++)
        r->table[i] = (float)rs_kernel((double)i / SPK_RS_OVERSAMPLE, fc, r->half);
    r->len = r->half;          /* leading zeros: output 0 sits on input 0 */
    r->pos = r->half;
    return 0;
}

void spk_resampler_free(spk_resampler *r) {
    if (!r) return;
    free(r->table);
    free(r->buf);
    r->table = NULL;
    r->buf = NULL;
}

int spk_resampler_max_out(const spk_resampler *r, int n) {
    if (!r || r->in_rate == SPK_ASR_RATE || r->step <= 0) return n < 0 ? 0 : n;
    return (int)((double)(n + r->len + r->half) / r->step) + 4;
}

static inline float rs_tap(const spk_resampler *r, double d) {
    double x = fabs(d) * SPK_RS_OVERSAMPLE;
    int i = (int)x;
    if (i >= r->table_len - 1) return 0.0f;
    float f = (float)(x - i);
    return r->table[i] + (r->table[i + 1] - r->table[i]) * f;
}

/* Emit every output whose look-ahead is in the buffer, then drop history. */
static int rs_drain(spk_resampler *r, float *out, int cap) {
    int written = 0;
    while (written < cap) {
        int c = (int)floor(r->pos);
        if (c + r->half >= r->len) break;
        double acc = 0.0;
        for (int j = c - r->half + 1; j <= c + r->half; j++)
            acc += (double)r->buf[j] * rs_tap(r, r->pos - j);
        out[written++] = (float)acc;
        r->pos += r->step;
    }
    int drop = (int)floor(r->pos) - r->half + 1;
    if (drop > 0) {
        if (drop > r->len) drop = r->len;
        memmove(r->buf, r->buf + drop, sizeof(float) * (size_t)(r->len - drop));
        r->len -= drop;
        r->pos -= drop;
    }
    return written;
}

int spk_resampler_process(spk_resampler *r, const float *in, int n, float *out, int cap) {
    if (!r || !in || n <= 0 || !out || cap <= 0) return 0;
    if (r->in_rate == SPK_ASR_RATE) {
        int m = n < cap ? n : cap;
        memcpy(out, in, sizeof(float) * (size_t)m);
        return m;
    }
    int written = 0;
    while (n > 0) {
        int room = r->cap - r->len;
        int m = n < room ? n : room;
        if (m <= 0) break;   /* cannot happen: drain always frees room */
        memcpy(r->buf + r->len, in, sizeof(float) * (size_t)m);
        r->len += m;
        in += m;
        n -= m;
        written += rs_drain(r, out + written, cap - written);
    }
    return written;
}

int spk_resampler_flush(spk_resampler *r, float *out, int cap) {
    if (!r || r->in_rate == SPK_ASR_RATE || !r->buf) return 0;
    /* half zeros of look-ahead release every output before the end of input */
    float zeros[256] = {0};
    int need = r->half, written = 0;
    while (need > 0) {
        int m = need < 256 ? need : 256;
        written += spk_resampler_process(r, zeros, m, out + written, cap - written);
        need -= m;
    }
    memset(r->buf, 0, sizeof(float) * (size_t)r->cap);
    r->len = r->half;
    r->pos = r->half;
    return written;
}

/* =================================================================== framer */
void spk_framer_reset(spk_framer *f) {
    if (f) memset(f, 0, sizeof *f);
}

static void framer_fill(const spk_framer *f, spk_utterance *u, int reason) {
    if (!u) return;
    u->audio_start = f->audio_start;
    u->speech_start = f->speech_start;
    u->speech_end = f->speech_end;
    u->voiced = f->voiced;
    u->reason = reason;
}

int spk_framer_step(spk_framer *f, float prob, spk_utterance *u) {
    if (!f) return SPK_FR_NONE;
    int64_t s0 = f->pos, s1 = f->pos + SPK_ASR_HOP;
    f->pos = s1;
    if (!f->open) {
        if (prob < SPK_FR_ON) return SPK_FR_NONE;
        f->open = 1;
        f->speech_start = s0;
        f->speech_end = s1;
        f->voiced = SPK_ASR_HOP;
        f->audio_start = s0 - MS_TO_SAMPLES(SPK_ASR_PREROLL_MS);
        if (f->audio_start < f->floor) f->audio_start = f->floor;
        if (f->audio_start < 0) f->audio_start = 0;
        framer_fill(f, u, 0);
        return SPK_FR_START;
    }
    if (prob >= SPK_FR_OFF) {
        f->speech_end = s1;
        f->voiced += SPK_ASR_HOP;
    }
    if (s1 - f->speech_end >= MS_TO_SAMPLES(SPK_ASR_HOLD_MS)) {
        f->open = 0;
        f->floor = f->speech_end;
        framer_fill(f, u, 0);
        return SPK_FR_CLOSE;
    }
    /* never let the utterance's audio pass 15 s: close before the next frame would */
    if (s1 + SPK_ASR_HOP - f->audio_start > MS_TO_SAMPLES(SPK_ASR_MAX_MS)) {
        f->open = 0;
        f->floor = s1;
        framer_fill(f, u, 1);
        return SPK_FR_CLOSE;
    }
    return SPK_FR_NONE;
}

int spk_framer_flush(spk_framer *f, spk_utterance *u) {
    if (!f || !f->open) return SPK_FR_NONE;
    f->open = 0;
    f->floor = f->pos;
    framer_fill(f, u, 2);
    return SPK_FR_CLOSE;
}

/* ================================================================== session */
#define RING_SLOTS 1024      /* power of two                          */
#define SLOT_CAP   1024      /* samples per slot (one push is split)  */
#define HIST_CAP   (MS_TO_SAMPLES(SPK_ASR_MAX_MS + SPK_ASR_HOLD_MS + SPK_ASR_PREROLL_MS + 1000))
#define FINAL_PAD  MS_TO_SAMPLES(SPK_ASR_TAIL_MS)
#define TEXT_CAP   4096
#define POLL_MS    40

typedef struct {
    int     n;
    int     rate;
    double  t_ms;           /* capture time of pcm[0], ms since start */
    int16_t pcm[SLOT_CAP];
} asr_slot;

struct spk_asr {
    spk_asr_engine eng;
    int  opened;
    char err[256];

    /* ring: the producer owns head, the worker owns tail */
    asr_slot *ring;
    atomic_uint_fast64_t head, tail;
    atomic_int busy;                 /* a producer is inside push */
    atomic_int active, muted;
    atomic_uint_fast64_t pushed, dropped;
    double start_mono_ms;

    /* worker */
    pthread_t thread;
    int thread_running, manual;
    atomic_int stop_req;
    pthread_mutex_t mu;              /* the processing state below */

    void (*on_line)(const spk_asr_line *, void *);
    void *user;
    int partial_ms;

    /* run (continuous audio on one clock) */
    int     run_open, run_rate;
    double  run_anchor_ms;           /* capture time of the run's first sample */
    int64_t run_in;                  /* input samples consumed this run */
    spk_resampler rs;
    float  *conv;                    /* slot -> float */
    float  *rsout;                   /* resampler output */
    int     rsout_cap;
    float   frame[SPK_ASR_HOP];
    int     frame_len;
    spk_framer fr;

    /* 16 kHz audio kept for the open utterance (or the preroll while idle) */
    float  *hist;
    int64_t hist_base, hist_len;     /* covers [hist_base, hist_base + hist_len) */

    /* the open utterance */
    uint64_t next_id, cur_id;
    int64_t  next_partial_at;
    int      partial_sent;
    char     last_text[TEXT_CAP];
    char     text[TEXT_CAP];

    spk_asr_stats stats;
};

spk_asr *spk_asr_create_with_engine(spk_asr_engine engine) {
    if (!engine.open || !engine.vad || !engine.transcribe) {
        if (engine.destroy) engine.destroy(engine.ctx);
        return NULL;
    }
    spk_asr *a = calloc(1, sizeof *a);
    if (!a) { if (engine.destroy) engine.destroy(engine.ctx); return NULL; }
    a->ring = calloc(RING_SLOTS, sizeof(asr_slot));
    a->conv = malloc(sizeof(float) * SLOT_CAP);
    a->hist = malloc(sizeof(float) * (size_t)HIST_CAP);
    if (!a->ring || !a->conv || !a->hist) {
        free(a->ring); free(a->conv); free(a->hist); free(a);
        if (engine.destroy) engine.destroy(engine.ctx);
        return NULL;
    }
    a->eng = engine;
    pthread_mutex_init(&a->mu, NULL);
    return a;
}

spk_asr *spk_asr_create(const spk_asr_paths *paths, char *err, size_t err_len) {
    if (!spk_asr_available()) {
        if (err && err_len) snprintf(err, err_len, "built without Moonshine (define SPARKS_WITH_MOONSHINE)");
        return NULL;
    }
    if (!paths || !paths->encoder || !paths->decoder || !paths->tokenizer || !paths->vad) {
        if (err && err_len) snprintf(err, err_len, "missing ASR model paths");
        return NULL;
    }
    const char *files[4] = { paths->encoder, paths->decoder, paths->tokenizer, paths->vad };
    for (int i = 0; i < 4; i++) {
        if (access(files[i], R_OK) != 0) {
            if (err && err_len) snprintf(err, err_len, "ASR model file missing: %s", files[i]);
            return NULL;
        }
    }
    spk_asr_engine eng;
    if (spk_moonshine_engine(paths, &eng, err, err_len) != 0) return NULL;
    return spk_asr_create_with_engine(eng);
}

void spk_asr_set_manual(spk_asr *a, int manual) {
    if (a && !atomic_load(&a->active)) a->manual = manual ? 1 : 0;
}

const char *spk_asr_last_error(spk_asr *a) { return a ? a->err : ""; }

void spk_asr_get_stats(spk_asr *a, spk_asr_stats *out) {
    if (!a || !out) return;
    pthread_mutex_lock(&a->mu);
    *out = a->stats;
    out->pushed = atomic_load(&a->pushed);
    out->dropped = atomic_load(&a->dropped);
    pthread_mutex_unlock(&a->mu);
}

int spk_asr_open(spk_asr *a) {
    if (!a) return SPK_E_INVALID;
    if (a->opened) return SPK_OK;
    a->err[0] = '\0';
    if (a->eng.open(a->eng.ctx, a->err, sizeof a->err) != 0) {
        if (!a->err[0]) snprintf(a->err, sizeof a->err, "ASR model failed to load");
        return SPK_E_ENGINE;
    }
    a->opened = 1;
    return SPK_OK;
}

/* ------------------------------------------------------------- producer */
static void push_any(spk_asr *a, const int16_t *s16, const float *f32, int count, int rate, double t_ms) {
    if (!a || count <= 0 || (!s16 && !f32)) return;
    if (rate < 8000 || rate > 192000) return;
    if (!atomic_load_explicit(&a->active, memory_order_acquire) || atomic_load(&a->muted)) return;
    if (atomic_exchange_explicit(&a->busy, 1, memory_order_acquire)) {   /* another producer: drop, never wait */
        atomic_fetch_add(&a->dropped, (uint_fast64_t)count);
        return;
    }
    if (!atomic_load_explicit(&a->active, memory_order_acquire)) {       /* stop won the race */
        atomic_store_explicit(&a->busy, 0, memory_order_release);
        return;
    }
    if (t_ms < 0) t_ms = now_ms() - a->start_mono_ms - count * 1000.0 / rate;
    atomic_fetch_add(&a->pushed, (uint_fast64_t)count);
    int off = 0;
    while (off < count) {
        int m = count - off < SLOT_CAP ? count - off : SLOT_CAP;
        uint_fast64_t head = atomic_load_explicit(&a->head, memory_order_relaxed);
        uint_fast64_t tail = atomic_load_explicit(&a->tail, memory_order_acquire);
        if (head - tail >= RING_SLOTS) {   /* worker is behind: drop the rest */
            atomic_fetch_add(&a->dropped, (uint_fast64_t)(count - off));
            break;
        }
        asr_slot *sl = &a->ring[head & (RING_SLOTS - 1)];
        if (s16) {
            memcpy(sl->pcm, s16 + off, sizeof(int16_t) * (size_t)m);
        } else {
            for (int i = 0; i < m; i++) {
                float v = f32[off + i] * 32767.0f;
                sl->pcm[i] = (int16_t)(v > 32767.0f ? 32767 : v < -32768.0f ? -32768 : (int)lrintf(v));
            }
        }
        sl->n = m;
        sl->rate = rate;
        sl->t_ms = t_ms + off * 1000.0 / rate;
        atomic_store_explicit(&a->head, head + 1, memory_order_release);
        off += m;
    }
    atomic_store_explicit(&a->busy, 0, memory_order_release);
}

void spk_asr_push_i16(spk_asr *a, const int16_t *s, int n, int r) { push_any(a, s, NULL, n, r, -1); }
void spk_asr_push_f32(spk_asr *a, const float *s, int n, int r) { push_any(a, NULL, s, n, r, -1); }
void spk_asr_push_i16_at(spk_asr *a, const int16_t *s, int n, int r, double t) { push_any(a, s, NULL, n, r, t < 0 ? 0 : t); }
void spk_asr_push_f32_at(spk_asr *a, const float *s, int n, int r, double t) { push_any(a, NULL, s, n, r, t < 0 ? 0 : t); }

void spk_asr_set_muted(spk_asr *a, int muted) {
    if (a) atomic_store(&a->muted, muted ? 1 : 0);
}

/* --------------------------------------------------------------- worker */
static double run_seconds(const spk_asr *a, int64_t pos16) {
    return (a->run_anchor_ms + pos16 * 1000.0 / SPK_ASR_RATE) / 1000.0;
}

static int decode(spk_asr *a, int64_t from, int64_t to) {
    a->text[0] = '\0';
    if (from < a->hist_base) from = a->hist_base;
    if (to > a->hist_base + a->hist_len) to = a->hist_base + a->hist_len;
    if (to - from < MS_TO_SAMPLES(100)) return 0;
    double t0 = now_ms();
    int rc = a->eng.transcribe(a->eng.ctx, a->hist + (from - a->hist_base), (int)(to - from), a->text, sizeof a->text);
    a->stats.decode_ms += now_ms() - t0;
    if (rc != 0) a->text[0] = '\0';
    return rc;
}

static void deliver(spk_asr *a, const char *text, int64_t speech_start, int64_t end, int final) {
    if (!a->on_line) return;
    spk_asr_line line = {
        a->cur_id, text, run_seconds(a, speech_start), (double)(end - speech_start) / SPK_ASR_RATE, final,
    };
    a->on_line(&line, a->user);
}

static void finish_utterance(spk_asr *a, const spk_utterance *u) {
    a->stats.utterances++;
    int64_t audio_end = a->hist_base + a->hist_len;
    int64_t end = u->speech_end + FINAL_PAD;
    if (end > audio_end) end = audio_end;
    if (u->voiced < MS_TO_SAMPLES(SPK_ASR_MIN_SPEECH_MS) && !a->partial_sent) return;   /* a click or a cough */
    decode(a, u->audio_start, end);
    const char *text = a->text[0] ? a->text : (a->partial_sent ? a->last_text : NULL);
    if (!text || !*text) return;
    deliver(a, text, u->speech_start, u->speech_end, 1);
    a->stats.finals++;
}

static void maybe_partial(spk_asr *a) {
    if (!a->fr.open || a->partial_ms <= 0) return;
    if (a->fr.voiced < MS_TO_SAMPLES(SPK_ASR_MIN_SPEECH_MS)) return;
    int64_t now = a->fr.pos;
    if (now < a->next_partial_at) return;
    double t0 = now_ms();
    decode(a, a->fr.audio_start, a->hist_base + a->hist_len);
    double took = now_ms() - t0;
    /* back off when decoding is slow, so partials never starve the final */
    double gap = a->partial_ms > 2.0 * took ? a->partial_ms : 2.0 * took;
    a->next_partial_at = now + (int64_t)(gap * SPK_ASR_RATE / 1000.0);
    if (!a->text[0] || strcmp(a->text, a->last_text) == 0) return;
    snprintf(a->last_text, sizeof a->last_text, "%s", a->text);
    a->partial_sent = 1;
    deliver(a, a->last_text, a->fr.speech_start, a->hist_base + a->hist_len, 0);
    a->stats.partials++;
}

static void on_start(spk_asr *a, const spk_utterance *u) {
    a->cur_id = ++a->next_id;
    a->partial_sent = 0;
    a->last_text[0] = '\0';
    a->next_partial_at = u->speech_start + MS_TO_SAMPLES(a->partial_ms > 0 ? a->partial_ms : 0);
}

/* Keep only what the open utterance (or the next one's preroll) can use. */
static void hist_trim(spk_asr *a, int64_t incoming) {
    int64_t end = a->hist_base + a->hist_len;
    int64_t keep_from = a->fr.open ? a->fr.audio_start : end - MS_TO_SAMPLES(SPK_ASR_PREROLL_MS) - SPK_ASR_HOP;
    if (a->hist_len + incoming > HIST_CAP) {
        int64_t must = a->hist_base + a->hist_len + incoming - HIST_CAP;
        if (keep_from < must) keep_from = must;   /* cannot happen with the 15 s cap; stay safe */
    }
    if (keep_from <= a->hist_base) return;
    if (keep_from > end) keep_from = end;
    int64_t drop = keep_from - a->hist_base;
    memmove(a->hist, a->hist + drop, sizeof(float) * (size_t)(a->hist_len - drop));
    a->hist_len -= drop;
    a->hist_base = keep_from;
}

/* 16 kHz samples into the history, the VAD and the framer. */
static void feed16(spk_asr *a, const float *x, int n) {
    while (n > 0) {
        int m = SPK_ASR_HOP - a->frame_len;
        if (m > n) m = n;
        hist_trim(a, m);
        memcpy(a->hist + a->hist_len, x, sizeof(float) * (size_t)m);
        a->hist_len += m;
        memcpy(a->frame + a->frame_len, x, sizeof(float) * (size_t)m);
        a->frame_len += m;
        x += m;
        n -= m;
        if (a->frame_len < SPK_ASR_HOP) break;
        a->frame_len = 0;
        float p = a->eng.vad(a->eng.ctx, a->frame);
        if (p < 0) p = 0;
        a->stats.frames++;
        spk_utterance u;
        int ev = spk_framer_step(&a->fr, p, &u);
        if (ev == SPK_FR_START) on_start(a, &u);
        else if (ev == SPK_FR_CLOSE) finish_utterance(a, &u);
        maybe_partial(a);
    }
}

static void end_run(spk_asr *a) {
    if (!a->run_open) return;
    if (a->rsout) {
        int k = spk_resampler_flush(&a->rs, a->rsout, a->rsout_cap);
        if (k > 0) feed16(a, a->rsout, k);
    }
    spk_utterance u;
    if (spk_framer_flush(&a->fr, &u) == SPK_FR_CLOSE) finish_utterance(a, &u);
    spk_resampler_free(&a->rs);
    a->run_open = 0;
}

static void begin_run(spk_asr *a, int rate, double t_ms) {
    if (spk_resampler_init(&a->rs, rate) != 0) return;
    int need = spk_resampler_max_out(&a->rs, SLOT_CAP) + 256;
    if (need < 2 * SLOT_CAP) need = 2 * SLOT_CAP;
    if (need > a->rsout_cap) {
        float *b = realloc(a->rsout, sizeof(float) * (size_t)need);
        if (!b) { spk_resampler_free(&a->rs); return; }
        a->rsout = b;
        a->rsout_cap = need;
    }
    a->run_open = 1;
    a->run_rate = rate;
    a->run_anchor_ms = t_ms;
    a->run_in = 0;
    a->frame_len = 0;
    a->hist_base = 0;
    a->hist_len = 0;
    spk_framer_reset(&a->fr);
    if (a->eng.vad_reset) a->eng.vad_reset(a->eng.ctx);
}

static void process_slot(spk_asr *a, const asr_slot *sl) {
    double expected = a->run_anchor_ms + a->run_in * 1000.0 / (a->run_rate ? a->run_rate : 1);
    if (!a->run_open || sl->rate != a->run_rate || fabs(sl->t_ms - expected) > SPK_ASR_GAP_MS) {
        end_run(a);
        begin_run(a, sl->rate, sl->t_ms);
        if (!a->run_open) return;
    }
    for (int i = 0; i < sl->n; i++) a->conv[i] = sl->pcm[i] / 32768.0f;
    int k = spk_resampler_process(&a->rs, a->conv, sl->n, a->rsout, a->rsout_cap);
    a->run_in += sl->n;
    if (k > 0) feed16(a, a->rsout, k);
}

void spk_asr_pump(spk_asr *a) {
    if (!a) return;
    pthread_mutex_lock(&a->mu);
    for (;;) {
        uint_fast64_t tail = atomic_load_explicit(&a->tail, memory_order_relaxed);
        uint_fast64_t head = atomic_load_explicit(&a->head, memory_order_acquire);
        if (tail == head) break;
        process_slot(a, &a->ring[tail & (RING_SLOTS - 1)]);
        atomic_store_explicit(&a->tail, tail + 1, memory_order_release);
    }
    /* muted: the open utterance ends here; audio after unmute starts a new run */
    if (atomic_load(&a->muted) && a->run_open) end_run(a);
    pthread_mutex_unlock(&a->mu);
}

static void *worker(void *arg) {
    spk_asr *a = arg;
    while (!atomic_load(&a->stop_req)) {
        spk_asr_pump(a);
        sleep_ms(POLL_MS);
    }
    return NULL;
}

int spk_asr_start(spk_asr *a, int partial_ms,
                  void (*on_line)(const spk_asr_line *, void *), void *user) {
    if (!a) return SPK_E_INVALID;
    if (atomic_load(&a->active)) return SPK_OK;
    int rc = spk_asr_open(a);
    if (rc != SPK_OK) return rc;
    pthread_mutex_lock(&a->mu);
    a->on_line = on_line;
    a->user = user;
    a->partial_ms = partial_ms > 0 ? (partial_ms < 100 ? 100 : partial_ms) : 0;
    a->run_open = 0;
    a->run_rate = 0;
    atomic_store(&a->head, 0);
    atomic_store(&a->tail, 0);
    a->start_mono_ms = now_ms();
    pthread_mutex_unlock(&a->mu);
    atomic_store(&a->stop_req, 0);
    atomic_store_explicit(&a->active, 1, memory_order_release);
    if (!a->manual) {
        a->thread_running = pthread_create(&a->thread, NULL, worker, a) == 0;
        if (!a->thread_running) {
            atomic_store(&a->active, 0);
            return SPK_E_ENGINE;
        }
    }
    return SPK_OK;
}

int spk_asr_stop(spk_asr *a) {
    if (!a) return SPK_E_INVALID;
    if (!atomic_load(&a->active)) return SPK_OK;
    atomic_store_explicit(&a->active, 0, memory_order_release);
    while (atomic_load_explicit(&a->busy, memory_order_acquire)) sleep_ms(1);   /* a push in flight finishes its copy */
    atomic_store(&a->stop_req, 1);
    if (a->thread_running) {
        pthread_join(a->thread, NULL);
        a->thread_running = 0;
    }
    /* what was pushed before stop is still transcribed */
    spk_asr_pump(a);
    pthread_mutex_lock(&a->mu);
    end_run(a);
    a->on_line = NULL;
    a->user = NULL;
    if (a->opened && a->eng.close) a->eng.close(a->eng.ctx);
    a->opened = 0;
    pthread_mutex_unlock(&a->mu);
    return SPK_OK;
}

char *spk_asr_transcribe_once(spk_asr *a, const float *samples, int count, int sample_rate) {
    if (!a || !samples || count <= 0 || !a->opened) return NULL;
    spk_resampler rs;
    if (spk_resampler_init(&rs, sample_rate) != 0) return NULL;
    int cap = spk_resampler_max_out(&rs, count) + 16;
    float *pcm = malloc(sizeof(float) * (size_t)cap);
    char *text = malloc(TEXT_CAP);
    char *out = NULL;
    if (pcm && text) {
        int n = spk_resampler_process(&rs, samples, count, pcm, cap);
        n += spk_resampler_flush(&rs, pcm + n, cap - n);
        pthread_mutex_lock(&a->mu);
        int rc = a->eng.transcribe(a->eng.ctx, pcm, n, text, TEXT_CAP);
        pthread_mutex_unlock(&a->mu);
        if (rc == 0) { out = text; text = NULL; }
    }
    spk_resampler_free(&rs);
    free(pcm);
    free(text);
    return out;
}

void spk_asr_free(spk_asr *a) {
    if (!a) return;
    spk_asr_stop(a);
    if (a->opened && a->eng.close) a->eng.close(a->eng.ctx);
    if (a->eng.destroy) a->eng.destroy(a->eng.ctx);
    spk_resampler_free(&a->rs);
    pthread_mutex_destroy(&a->mu);
    free(a->rsout);
    free(a->ring);
    free(a->conv);
    free(a->hist);
    free(a);
}
