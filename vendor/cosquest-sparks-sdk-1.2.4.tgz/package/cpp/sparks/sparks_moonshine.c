/* sparks_moonshine.c: Moonshine Base (English, int8) and Silero VAD over the
 * ONNX Runtime C API. This is the spk_asr_engine behind sparks_asr.c.
 *
 * Model files are Moonshine AI's official ORT-format Base release
 * (download.moonshine.ai/model/base-en/quantized/base-en: encoder_model.ort,
 * decoder_model_merged.ort, tokenizer.bin; MIT) and snakers4's Silero VAD
 * (silero_vad_16k_op15.onnx; MIT). They are downloaded through the model
 * manifest, never bundled.
 *
 * Memory: the .ort files are mmap'd and ONNX Runtime is told to use the
 * mapped bytes for its initializers (session.use_ort_model_bytes_for_
 * initializers) with prepacking off, so the 141 MB of weights stay clean,
 * file-backed pages the OS can drop, not counted against the app. Measured
 * on a Mac: footprint after load 28 MB this way, 197 to 307 MB if ORT copies
 * the weights (which is what Moonshine's own C library does today, and why
 * the SDK runs the models itself). See docs/NATIVE_SDK.md.
 *
 * The decode loop is a port of Moonshine's MoonshineModel::transcribe (core/
 * moonshine-model.cpp, MIT): encoder once, then the merged decoder greedily
 * with its KV cache, at most 6.5 tokens per second of audio. The tokenizer
 * is Moonshine's tokenizer.bin (BinTokenizer). Built only with
 * -DSPARKS_WITH_MOONSHINE; otherwise this file is a stub. */
#define _POSIX_C_SOURCE 200809L
#include "sparks_core.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#if defined(SPARKS_WITH_MOONSHINE)

#if defined(__has_include)
#if __has_include(<onnxruntime/onnxruntime_c_api.h>)
#include <onnxruntime/onnxruntime_c_api.h>      /* onnxruntime-c pod, frameworks */
#elif __has_include(<onnxruntime_c_api.h>)
#include <onnxruntime_c_api.h>                  /* onnxruntime-c pod, static libraries; host test */
#else
#include "onnxruntime_c_api.h"
#endif
#else
#include "onnxruntime_c_api.h"
#endif

#include <fcntl.h>
#include <math.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <unistd.h>

int spk_asr_available(void) { return 1; }

#define MS_START_TOKEN 1
#define MS_EOS_TOKEN   2
#define MS_TOKENS_PER_SECOND 6.5
#define VAD_CONTEXT 64
#define VAD_STATE   (2 * 1 * 128)

enum { F_ENCODER, F_DECODER, F_TOKENIZER, F_VAD, F_COUNT };

typedef struct {
    char *path[F_COUNT];

    const OrtApi *api;
    OrtEnv *env;
    OrtMemoryInfo *mem;
    OrtSession *enc, *dec, *vad;
    void  *map[2];
    size_t map_len[2];

    /* encoder */
    int enc_has_mask;
    /* decoder io, in session order */
    size_t n_in, n_out;
    char **in_names, **out_names;
    int idx_ids, idx_hidden, idx_mask, idx_cache, idx_logits;
    int *past_out;          /* for input i: the output index of its present.*, or -1 */
    int *past_is_self;      /* decoder (self-attention) KV: updated every step */
    int heads, head_dim;

    /* tokenizer: token i = bytes tok_blob[tok_off[i] .. + tok_len[i]] */
    uint8_t *tok_blob;
    uint32_t *tok_off;
    uint16_t *tok_len;
    int n_tok;

    /* VAD */
    float vad_state[VAD_STATE];
    float vad_in[VAD_CONTEXT + SPK_ASR_HOP];
    int64_t vad_sr;
} msh;

/* ORT status -> err; evaluates to non-zero on failure */
static int ort_failed(msh *m, OrtStatus *st, char *err, size_t err_len, const char *what) {
    if (!st) return 0;
    if (err && err_len) snprintf(err, err_len, "%s: %s", what, m->api->GetErrorMessage(st));
    m->api->ReleaseStatus(st);
    return 1;
}
#define TRY(expr, what) do { if (ort_failed(m, (expr), err, err_len, (what))) goto fail; } while (0)

static int map_file(const char *path, void **out, size_t *len) {
    int fd = open(path, O_RDONLY);
    if (fd < 0) return -1;
    struct stat st;
    if (fstat(fd, &st) != 0 || st.st_size <= 0) { close(fd); return -1; }
    void *p = mmap(NULL, (size_t)st.st_size, PROT_READ, MAP_PRIVATE, fd, 0);
    close(fd);
    if (p == MAP_FAILED) return -1;
    *out = p;
    *len = (size_t)st.st_size;
    return 0;
}

static int is_ort_format(const void *p, size_t len) {
    return len > 8 && memcmp((const char *)p + 4, "ORTM", 4) == 0;   /* flatbuffers file identifier */
}

static char *dupstr(const char *s) {
    size_t n = strlen(s) + 1;
    char *d = malloc(n);
    if (d) memcpy(d, s, n);
    return d;
}

/* ------------------------------------------------------------- tokenizer */
static int load_tokenizer(msh *m, char *err, size_t err_len) {
    FILE *f = fopen(m->path[F_TOKENIZER], "rb");
    if (!f) { snprintf(err, err_len, "cannot open tokenizer"); return -1; }
    fseek(f, 0, SEEK_END);
    long n = ftell(f);
    fseek(f, 0, SEEK_SET);
    if (n <= 0 || n > (64L << 20)) { fclose(f); snprintf(err, err_len, "bad tokenizer size"); return -1; }
    m->tok_blob = malloc((size_t)n);
    if (!m->tok_blob || fread(m->tok_blob, 1, (size_t)n, f) != (size_t)n) { fclose(f); snprintf(err, err_len, "cannot read tokenizer"); return -1; }
    fclose(f);
    /* entries: 0 = empty; b < 128: b bytes follow; else (next*128 + b - 128) bytes follow */
    int count = 0;
    for (long i = 0; i < n;) {
        uint8_t b = m->tok_blob[i++];
        size_t len = 0;
        if (b >= 128) { if (i >= n) break; len = (size_t)m->tok_blob[i++] * 128 + b - 128; }
        else len = b;
        if (i + (long)len > n) break;
        i += (long)len;
        count++;
    }
    m->tok_off = malloc(sizeof(uint32_t) * (size_t)count);
    m->tok_len = malloc(sizeof(uint16_t) * (size_t)count);
    if (!m->tok_off || !m->tok_len || count < 3) { snprintf(err, err_len, "bad tokenizer"); return -1; }
    int k = 0;
    for (long i = 0; i < n && k < count;) {
        uint8_t b = m->tok_blob[i++];
        size_t len = b;
        if (b >= 128) len = (size_t)m->tok_blob[i++] * 128 + b - 128;
        m->tok_off[k] = (uint32_t)i;
        m->tok_len[k] = (uint16_t)(len > 65535 ? 65535 : len);
        i += (long)len;
        k++;
    }
    m->n_tok = k;
    return 0;
}

/* Tokens to text: skip special entries ("<...>"), "\xE2\x96\x81" is a space, trim. */
static void detokenize(const msh *m, const int64_t *toks, int n, char *out, size_t cap) {
    size_t o = 0;
    for (int i = 0; i < n; i++) {
        int64_t t = toks[i];
        if (t < 0 || t >= m->n_tok) continue;
        const uint8_t *b = m->tok_blob + m->tok_off[t];
        size_t len = m->tok_len[t];
        if (len == 0 || (len > 2 && b[0] == '<' && b[len - 1] == '>')) continue;
        for (size_t j = 0; j < len && o + 1 < cap;) {
            if (j + 2 < len && b[j] == 0xE2 && b[j + 1] == 0x96 && b[j + 2] == 0x81) { out[o++] = ' '; j += 3; }
            else out[o++] = (char)b[j++];
        }
    }
    out[o] = '\0';
    /* trim */
    size_t s = 0;
    while (out[s] == ' ' || out[s] == '\n' || out[s] == '\t') s++;
    size_t e = strlen(out);
    while (e > s && (out[e - 1] == ' ' || out[e - 1] == '\n' || out[e - 1] == '\t')) e--;
    memmove(out, out + s, e - s);
    out[e - s] = '\0';
}

/* A decoder stuck in a loop: the last block of 2 to 16 tokens repeated three
 * times in a row. Keep one copy (people do say a phrase twice; three times
 * of a whole phrase is the model, not the speaker). */
static int loop_cut(const int64_t *toks, int n) {
    for (int len = 2; len <= 16 && 3 * len <= n; len++) {
        const int64_t *c = toks + n - len, *b = c - len, *a = b - len;
        if (memcmp(a, b, sizeof(int64_t) * (size_t)len) == 0 && memcmp(b, c, sizeof(int64_t) * (size_t)len) == 0)
            return n - 2 * len;   /* length that keeps the first copy */
    }
    return 0;
}

/* ---------------------------------------------------------------- loading */
static OrtSessionOptions *options(msh *m, int threads, int ort_bytes, char *err, size_t err_len) {
    OrtSessionOptions *so = NULL;
    TRY(m->api->CreateSessionOptions(&so), "session options");
    TRY(m->api->SetIntraOpNumThreads(so, threads), "threads");
    TRY(m->api->SetInterOpNumThreads(so, 1), "threads");
    TRY(m->api->DisableCpuMemArena(so), "arena");
    /* no busy-waiting threads between runs: battery */
    TRY(m->api->AddSessionConfigEntry(so, "session.intra_op.allow_spinning", "0"), "spinning");
    TRY(m->api->AddSessionConfigEntry(so, "session.inter_op.allow_spinning", "0"), "spinning");
    if (ort_bytes) {
        TRY(m->api->AddSessionConfigEntry(so, "session.load_model_format", "ORT"), "format");
        TRY(m->api->AddSessionConfigEntry(so, "session.use_ort_model_bytes_directly", "1"), "ort bytes");
        TRY(m->api->AddSessionConfigEntry(so, "session.use_ort_model_bytes_for_initializers", "1"), "ort bytes");
        TRY(m->api->AddSessionConfigEntry(so, "session.disable_prepacking", "1"), "prepacking");
    }
    return so;
fail:
    if (so) m->api->ReleaseSessionOptions(so);
    return NULL;
}

static int open_mapped(msh *m, int which, OrtSession **out, char *err, size_t err_len) {
    if (map_file(m->path[which], &m->map[which], &m->map_len[which]) != 0) {
        snprintf(err, err_len, "cannot map %s", m->path[which]);
        return -1;
    }
    int ort = is_ort_format(m->map[which], m->map_len[which]);
    OrtSessionOptions *so = options(m, 2, ort, err, err_len);
    if (!so) return -1;
    OrtStatus *st = m->api->CreateSessionFromArray(m->env, m->map[which], m->map_len[which], so, out);
    m->api->ReleaseSessionOptions(so);
    return ort_failed(m, st, err, err_len, which == F_ENCODER ? "encoder" : "decoder") ? -1 : 0;
}

static int find_name(char **names, size_t n, const char *want) {
    for (size_t i = 0; i < n; i++) if (strcmp(names[i], want) == 0) return (int)i;
    return -1;
}

static int read_names(msh *m, OrtSession *s, int inputs, char ***out, size_t *count, char *err, size_t err_len) {
    OrtAllocator *al = NULL;
    TRY(m->api->GetAllocatorWithDefaultOptions(&al), "allocator");
    TRY(inputs ? m->api->SessionGetInputCount(s, count) : m->api->SessionGetOutputCount(s, count), "io count");
    *out = calloc(*count ? *count : 1, sizeof(char *));
    if (!*out) goto fail;
    for (size_t i = 0; i < *count; i++) {
        char *nm = NULL;
        TRY(inputs ? m->api->SessionGetInputName(s, i, al, &nm) : m->api->SessionGetOutputName(s, i, al, &nm), "io name");
        (*out)[i] = dupstr(nm);
        OrtStatus *fs = m->api->AllocatorFree(al, nm);
        if (fs) m->api->ReleaseStatus(fs);
        if (!(*out)[i]) goto fail;
    }
    return 0;
fail:
    return -1;
}

static void free_names(char **names, size_t n) {
    if (!names) return;
    for (size_t i = 0; i < n; i++) free(names[i]);
    free(names);
}

static int bind_decoder(msh *m, char *err, size_t err_len) {
    if (read_names(m, m->dec, 1, &m->in_names, &m->n_in, err, err_len) != 0) return -1;
    if (read_names(m, m->dec, 0, &m->out_names, &m->n_out, err, err_len) != 0) return -1;
    m->idx_ids = find_name(m->in_names, m->n_in, "input_ids");
    m->idx_hidden = find_name(m->in_names, m->n_in, "encoder_hidden_states");
    m->idx_mask = find_name(m->in_names, m->n_in, "encoder_attention_mask");
    m->idx_cache = find_name(m->in_names, m->n_in, "use_cache_branch");
    m->idx_logits = find_name(m->out_names, m->n_out, "logits");
    if (m->idx_ids < 0 || m->idx_hidden < 0 || m->idx_cache < 0 || m->idx_logits < 0) {
        snprintf(err, err_len, "decoder is not a Moonshine merged decoder");
        return -1;
    }
    m->past_out = malloc(sizeof(int) * m->n_in);
    m->past_is_self = calloc(m->n_in, sizeof(int));
    if (!m->past_out || !m->past_is_self) return -1;
    int first_past = -1, n_past = 0;
    for (size_t i = 0; i < m->n_in; i++) {
        m->past_out[i] = -1;
        const char *pre = "past_key_values.";
        if (strncmp(m->in_names[i], pre, strlen(pre)) != 0) continue;
        char want[256];
        snprintf(want, sizeof want, "present.%s", m->in_names[i] + strlen(pre));
        m->past_out[i] = find_name(m->out_names, m->n_out, want);
        if (m->past_out[i] < 0) { snprintf(err, err_len, "decoder output %s missing", want); return -1; }
        m->past_is_self[i] = strstr(m->in_names[i], ".decoder.") != NULL;
        if (first_past < 0) first_past = (int)i;
        n_past++;
    }
    if (n_past == 0 || n_past % 4 != 0) { snprintf(err, err_len, "decoder has %d KV inputs", n_past); return -1; }
    /* [batch, heads, seq, head_dim] */
    OrtTypeInfo *ti = NULL;
    const OrtTensorTypeAndShapeInfo *tt = NULL;
    int64_t dims[4] = {0};
    size_t nd = 0;
    TRY(m->api->SessionGetInputTypeInfo(m->dec, (size_t)first_past, &ti), "kv shape");
    TRY(m->api->CastTypeInfoToTensorInfo(ti, &tt), "kv shape");
    TRY(m->api->GetDimensionsCount(tt, &nd), "kv shape");
    if (nd == 4) TRY(m->api->GetDimensions(tt, dims, 4), "kv shape");
    m->api->ReleaseTypeInfo(ti);
    if (nd != 4 || dims[1] <= 0 || dims[3] <= 0) { snprintf(err, err_len, "unexpected KV shape"); return -1; }
    m->heads = (int)dims[1];
    m->head_dim = (int)dims[3];
    return 0;
fail:
    return -1;
}

static void ms_close(void *ctx) {
    msh *m = ctx;
    if (!m->api) return;
    if (m->enc) m->api->ReleaseSession(m->enc);
    if (m->dec) m->api->ReleaseSession(m->dec);
    if (m->vad) m->api->ReleaseSession(m->vad);
    if (m->mem) m->api->ReleaseMemoryInfo(m->mem);
    if (m->env) m->api->ReleaseEnv(m->env);
    m->enc = m->dec = m->vad = NULL;
    m->mem = NULL;
    m->env = NULL;
    for (int i = 0; i < 2; i++) {
        if (m->map[i]) munmap(m->map[i], m->map_len[i]);
        m->map[i] = NULL;
        m->map_len[i] = 0;
    }
    free_names(m->in_names, m->n_in);
    free_names(m->out_names, m->n_out);
    m->in_names = m->out_names = NULL;
    m->n_in = m->n_out = 0;
    free(m->past_out);
    free(m->past_is_self);
    m->past_out = m->past_is_self = NULL;
    free(m->tok_blob);
    free(m->tok_off);
    free(m->tok_len);
    m->tok_blob = NULL;
    m->tok_off = NULL;
    m->tok_len = NULL;
    m->n_tok = 0;
}

static int ms_open(void *ctx, char *err, size_t err_len) {
    msh *m = ctx;
    m->api = OrtGetApiBase()->GetApi(ORT_API_VERSION);
    if (!m->api) { snprintf(err, err_len, "ONNX Runtime API %d unavailable", ORT_API_VERSION); return -1; }
    TRY(m->api->CreateEnv(ORT_LOGGING_LEVEL_ERROR, "sparks-asr", &m->env), "env");
    TRY(m->api->CreateCpuMemoryInfo(OrtDeviceAllocator, OrtMemTypeDefault, &m->mem), "memory info");
    if (open_mapped(m, F_ENCODER, &m->enc, err, err_len) != 0) goto fail;
    if (open_mapped(m, F_DECODER, &m->dec, err, err_len) != 0) goto fail;
    size_t n_enc_in = 0;
    TRY(m->api->SessionGetInputCount(m->enc, &n_enc_in), "encoder inputs");
    m->enc_has_mask = n_enc_in > 1;
    if (bind_decoder(m, err, err_len) != 0) goto fail;
    if (load_tokenizer(m, err, err_len) != 0) goto fail;
    {
        OrtSessionOptions *so = options(m, 1, 0, err, err_len);
        if (!so) goto fail;
        OrtStatus *st = m->api->CreateSession(m->env, m->path[F_VAD], so, &m->vad);
        m->api->ReleaseSessionOptions(so);
        if (ort_failed(m, st, err, err_len, "vad")) goto fail;
    }
    memset(m->vad_state, 0, sizeof m->vad_state);
    memset(m->vad_in, 0, sizeof m->vad_in);
    m->vad_sr = SPK_ASR_RATE;
    return 0;
fail:
    ms_close(m);
    return -1;
}

/* ------------------------------------------------------------------- VAD */
static void ms_vad_reset(void *ctx) {
    msh *m = ctx;
    memset(m->vad_state, 0, sizeof m->vad_state);
    memset(m->vad_in, 0, sizeof m->vad_in);
}

static float ms_vad(void *ctx, const float *frame) {
    msh *m = ctx;
    if (!m->vad) return -1.0f;
    const OrtApi *api = m->api;
    memcpy(m->vad_in + VAD_CONTEXT, frame, sizeof(float) * SPK_ASR_HOP);
    int64_t in_dims[2] = { 1, VAD_CONTEXT + SPK_ASR_HOP };
    int64_t st_dims[3] = { 2, 1, 128 };
    OrtValue *in[3] = { NULL, NULL, NULL }, *out[2] = { NULL, NULL };
    float p = -1.0f;
    OrtStatus *st = api->CreateTensorWithDataAsOrtValue(m->mem, m->vad_in, sizeof m->vad_in, in_dims, 2, ONNX_TENSOR_ELEMENT_DATA_TYPE_FLOAT, &in[0]);
    if (!st) st = api->CreateTensorWithDataAsOrtValue(m->mem, m->vad_state, sizeof m->vad_state, st_dims, 3, ONNX_TENSOR_ELEMENT_DATA_TYPE_FLOAT, &in[1]);
    if (!st) st = api->CreateTensorWithDataAsOrtValue(m->mem, &m->vad_sr, sizeof m->vad_sr, NULL, 0, ONNX_TENSOR_ELEMENT_DATA_TYPE_INT64, &in[2]);
    static const char *in_names[3] = { "input", "state", "sr" };
    static const char *out_names[2] = { "output", "stateN" };
    if (!st) st = api->Run(m->vad, NULL, in_names, (const OrtValue *const *)in, 3, out_names, 2, out);
    if (!st) {
        float *prob = NULL, *state = NULL;
        st = api->GetTensorMutableData(out[0], (void **)&prob);
        if (!st) st = api->GetTensorMutableData(out[1], (void **)&state);
        if (!st && prob && state) {
            p = prob[0];
            memcpy(m->vad_state, state, sizeof m->vad_state);
        }
    }
    if (st) api->ReleaseStatus(st);
    /* context = the last 64 samples of this input */
    memmove(m->vad_in, m->vad_in + SPK_ASR_HOP, sizeof(float) * VAD_CONTEXT);
    for (int i = 0; i < 3; i++) if (in[i]) api->ReleaseValue(in[i]);
    for (int i = 0; i < 2; i++) if (out[i]) api->ReleaseValue(out[i]);
    return p;
}

/* ------------------------------------------------------------- transcribe */
static int ms_transcribe(void *ctx, const float *pcm, int n, char *out, size_t cap) {
    msh *m = ctx;
    if (!out || cap == 0) return SPK_E_INVALID;
    out[0] = '\0';
    if (!m->enc || !m->dec) return SPK_E_NOT_READY;
    if (!pcm || n < SPK_ASR_RATE / 10) return 0;   /* under 100 ms: nothing to say */
    const OrtApi *api = m->api;
    int rc = SPK_E_ENGINE;
    OrtStatus *st = NULL;
    OrtValue *enc_in[2] = { NULL, NULL }, *hidden = NULL, *mask = NULL;
    int64_t *ones = NULL;
    float *zeros = NULL;
    OrtValue **past = calloc(m->n_in, sizeof(OrtValue *));
    OrtValue **dec_in = calloc(m->n_in, sizeof(OrtValue *));
    OrtValue **dec_out = calloc(m->n_out, sizeof(OrtValue *));
    int max_len = (int)ceil((double)n / SPK_ASR_RATE * MS_TOKENS_PER_SECOND);
    if (max_len < 4) max_len = 4;
    int64_t *toks = malloc(sizeof(int64_t) * (size_t)(max_len + 1));
    int ntok = 0;
    if (!past || !dec_in || !dec_out || !toks) goto done;

    /* encoder */
    int64_t audio_dims[2] = { 1, n };
    st = api->CreateTensorWithDataAsOrtValue(m->mem, (void *)pcm, sizeof(float) * (size_t)n, audio_dims, 2, ONNX_TENSOR_ELEMENT_DATA_TYPE_FLOAT, &enc_in[0]);
    if (st) goto done;
    if (m->enc_has_mask || m->idx_mask >= 0) {
        ones = malloc(sizeof(int64_t) * (size_t)n);
        if (!ones) goto done;
        for (int i = 0; i < n; i++) ones[i] = 1;
        st = api->CreateTensorWithDataAsOrtValue(m->mem, ones, sizeof(int64_t) * (size_t)n, audio_dims, 2, ONNX_TENSOR_ELEMENT_DATA_TYPE_INT64, &mask);
        if (st) goto done;
    }
    {
        static const char *enc_names[2] = { "input_values", "attention_mask" };
        static const char *enc_out[1] = { "last_hidden_state" };
        enc_in[1] = mask;
        st = api->Run(m->enc, NULL, enc_names, (const OrtValue *const *)enc_in, m->enc_has_mask ? 2 : 1, enc_out, 1, &hidden);
        enc_in[1] = NULL;
        if (st) goto done;
    }

    /* step-0 KV placeholders: [1, heads, 1, head_dim] zeros (ignored when use_cache_branch is false) */
    size_t kv = (size_t)m->heads * (size_t)m->head_dim;
    zeros = calloc(kv, sizeof(float));
    if (!zeros) goto done;
    int64_t kv_dims[4] = { 1, m->heads, 1, m->head_dim };
    for (size_t i = 0; i < m->n_in; i++) {
        if (m->past_out[i] < 0) continue;
        st = api->CreateTensorWithDataAsOrtValue(m->mem, zeros, sizeof(float) * kv, kv_dims, 4, ONNX_TENSOR_ELEMENT_DATA_TYPE_FLOAT, &past[i]);
        if (st) goto done;
    }

    int64_t token = MS_START_TOKEN;
    uint8_t use_cache = 0;
    int64_t one_dims[2] = { 1, 1 };
    int64_t bool_dims[1] = { 1 };
    for (int step = 0; step < max_len; step++) {
        OrtValue *ids = NULL, *cache = NULL;
        use_cache = step > 0;
        st = api->CreateTensorWithDataAsOrtValue(m->mem, &token, sizeof token, one_dims, 2, ONNX_TENSOR_ELEMENT_DATA_TYPE_INT64, &ids);
        if (!st) st = api->CreateTensorWithDataAsOrtValue(m->mem, &use_cache, 1, bool_dims, 1, ONNX_TENSOR_ELEMENT_DATA_TYPE_BOOL, &cache);
        if (st) { if (ids) api->ReleaseValue(ids); goto done; }
        for (size_t i = 0; i < m->n_in; i++) dec_in[i] = past[i];
        dec_in[m->idx_ids] = ids;
        dec_in[m->idx_hidden] = hidden;
        dec_in[m->idx_cache] = cache;
        if (m->idx_mask >= 0) dec_in[m->idx_mask] = mask;
        memset(dec_out, 0, sizeof(OrtValue *) * m->n_out);
        st = api->Run(m->dec, NULL, (const char *const *)m->in_names, (const OrtValue *const *)dec_in, m->n_in,
                      (const char *const *)m->out_names, m->n_out, dec_out);
        api->ReleaseValue(ids);
        api->ReleaseValue(cache);
        if (st) goto done;

        /* argmax over the last position's logits [1, L, vocab] */
        OrtTensorTypeAndShapeInfo *info = NULL;
        int64_t ld[3] = {0};
        size_t nd = 0;
        float *logits = NULL;
        st = api->GetTensorTypeAndShape(dec_out[m->idx_logits], &info);
        if (!st) st = api->GetDimensionsCount(info, &nd);
        if (!st && nd == 3) st = api->GetDimensions(info, ld, 3);
        if (info) api->ReleaseTensorTypeAndShapeInfo(info);
        if (!st) st = api->GetTensorMutableData(dec_out[m->idx_logits], (void **)&logits);
        if (st || nd != 3 || !logits || ld[2] <= 0) goto done_out;
        const float *row = logits + (size_t)(ld[1] - 1) * (size_t)ld[2];
        int64_t best = 0;
        for (int64_t v = 1; v < ld[2]; v++) if (row[v] > row[best]) best = v;

        /* carry the KV cache: everything after step 0, then only the decoder's own */
        for (size_t i = 0; i < m->n_in; i++) {
            int o = m->past_out[i];
            if (o < 0 || (step > 0 && !m->past_is_self[i])) continue;
            api->ReleaseValue(past[i]);
            past[i] = dec_out[o];
            dec_out[o] = NULL;
        }
        for (size_t j = 0; j < m->n_out; j++) if (dec_out[j]) { api->ReleaseValue(dec_out[j]); dec_out[j] = NULL; }
        if (best == MS_EOS_TOKEN) break;
        toks[ntok++] = best;
        int cut = loop_cut(toks, ntok);
        if (cut > 0) { ntok = cut; break; }
        token = best;
        continue;
    done_out:
        for (size_t j = 0; j < m->n_out; j++) if (dec_out[j]) { api->ReleaseValue(dec_out[j]); dec_out[j] = NULL; }
        goto done;
    }
    detokenize(m, toks, ntok, out, cap);
    rc = 0;

done:
    if (st) api->ReleaseStatus(st);
    if (past) for (size_t i = 0; i < m->n_in; i++) if (past[i]) api->ReleaseValue(past[i]);
    if (enc_in[0]) api->ReleaseValue(enc_in[0]);
    if (mask) api->ReleaseValue(mask);
    if (hidden) api->ReleaseValue(hidden);
    free(past);
    free(dec_in);
    free(dec_out);
    free(toks);
    free(ones);
    free(zeros);
    return rc;
}

static void ms_destroy(void *ctx) {
    msh *m = ctx;
    if (!m) return;
    ms_close(m);
    for (int i = 0; i < F_COUNT; i++) free(m->path[i]);
    free(m);
}

int spk_moonshine_engine(const spk_asr_paths *paths, spk_asr_engine *out, char *err, size_t err_len) {
    if (!paths || !out || !paths->encoder || !paths->decoder || !paths->tokenizer || !paths->vad) {
        if (err && err_len) snprintf(err, err_len, "missing ASR model paths");
        return SPK_E_INVALID;
    }
    msh *m = calloc(1, sizeof *m);
    if (!m) return SPK_E_MEMORY;
    const char *src[F_COUNT] = { paths->encoder, paths->decoder, paths->tokenizer, paths->vad };
    for (int i = 0; i < F_COUNT; i++) {
        m->path[i] = dupstr(src[i]);
        if (!m->path[i]) { ms_destroy(m); return SPK_E_MEMORY; }
    }
    memset(out, 0, sizeof *out);
    out->ctx = m;
    out->open = ms_open;
    out->close = ms_close;
    out->vad = ms_vad;
    out->vad_reset = ms_vad_reset;
    out->transcribe = ms_transcribe;
    out->destroy = ms_destroy;
    return SPK_OK;
}

#else /* !SPARKS_WITH_MOONSHINE */

int spk_asr_available(void) { return 0; }

int spk_moonshine_engine(const spk_asr_paths *paths, spk_asr_engine *out, char *err, size_t err_len) {
    (void)paths;
    if (out) memset(out, 0, sizeof *out);
    if (err && err_len) snprintf(err, err_len, "built without Moonshine (define SPARKS_WITH_MOONSHINE)");
    return SPK_E_NOT_READY;
}

#endif
