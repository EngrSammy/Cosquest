/* sparks_parallel.c: mote_parallel_for for Android, over a small pthread pool.
 *
 * cpp/mote/parallel.c threads the matmul with Grand Central Dispatch on Apple
 * and OpenMP where the build enables it; everywhere else it runs the whole
 * range on the calling thread. The Android build has neither, so until this
 * file every phone ran the model on ONE core: a lite spark.detect job (three
 * model calls, about 900 prompt tokens) took minutes on a budget phone and
 * overran its 30 s lease and 60 s deadline. CMakeLists.txt builds this file
 * instead of cpp/mote/parallel.c (which stays unedited, shared with iOS and
 * the server engine).
 *
 * Design:
 *  - one pool, created on first use: (configured cores - MOTE_RESERVE_CORES)
 *    threads in all, the caller included, at most SPK_POOL_MAX. The reserved
 *    core keeps the UI thread responsive, as on iOS;
 *  - the range is cut into up to 4 chunks per thread and threads take chunks
 *    as they finish (an atomic counter), so the big cores of a big.LITTLE
 *    phone do more of the work instead of waiting for the little ones;
 *  - every pool thread checks in for every call before the caller returns,
 *    so a call's fields never change under a thread still reading them;
 *  - threads spin briefly before sleeping on a condition variable: the
 *    matmul calls come about 200 times per token, each a fraction of a
 *    millisecond, so a full sleep and wake every time would cost more than
 *    it saves;
 *  - one call at a time: a second concurrent caller (none today: one engine
 *    thread runs mote) runs its range on its own thread instead of waiting.
 *
 * Results are identical to the one-thread path: each output row is computed
 * by exactly one thread, in the same order of operations.
 */
#define _GNU_SOURCE
#include "parallel.h"

#include <pthread.h>
#include <stdatomic.h>
#include <unistd.h>

#ifndef MOTE_RESERVE_CORES
#define MOTE_RESERVE_CORES 0
#endif
#define SPK_POOL_MAX 8
#define SPK_CHUNKS_PER_THREAD 4
#define SPK_SPIN 4000

static pthread_mutex_t mu = PTHREAD_MUTEX_INITIALIZER;
static pthread_cond_t cv_work = PTHREAD_COND_INITIALIZER;
static pthread_cond_t cv_done = PTHREAD_COND_INITIALIZER;
static pthread_mutex_t call_mu = PTHREAD_MUTEX_INITIALIZER;   /* one call at a time */
static pthread_once_t once = PTHREAD_ONCE_INIT;

static int pool_threads = 1;           /* threads in all, the caller included */
static atomic_uint generation;         /* bumped once per call */
static atomic_int pending;             /* pool threads that have not finished the current call */
static atomic_int next_chunk;

/* The current call. Written by the caller before `generation` is bumped,
 * stable until every pool thread has checked in (pending == 0). */
static void (*job_fn)(int, int, void *);
static void *job_ctx;
static int job_count, job_chunks;

static inline void cpu_relax(void) {
#if defined(__aarch64__) || defined(__arm__)
    __asm__ __volatile__("yield");
#elif defined(__x86_64__) || defined(__i386__)
    __asm__ __volatile__("pause");
#endif
}

static void run_chunks(void) {
    int c;
    while ((c = atomic_fetch_add(&next_chunk, 1)) < job_chunks) {
        int begin = (int)((long)c * job_count / job_chunks);
        int end = (int)((long)(c + 1) * job_count / job_chunks);
        if (begin < end) job_fn(begin, end, job_ctx);
    }
}

static void *worker(void *arg) {
    (void)arg;
    unsigned seen = 0;
    for (;;) {
        for (int i = 0; i < SPK_SPIN && atomic_load(&generation) == seen; i++) cpu_relax();
        if (atomic_load(&generation) == seen) {
            pthread_mutex_lock(&mu);
            while (atomic_load(&generation) == seen) pthread_cond_wait(&cv_work, &mu);
            pthread_mutex_unlock(&mu);
        }
        seen = atomic_load(&generation);
        run_chunks();
        if (atomic_fetch_sub(&pending, 1) == 1) {
            pthread_mutex_lock(&mu);
            pthread_cond_signal(&cv_done);
            pthread_mutex_unlock(&mu);
        }
    }
    return NULL;
}

static void start_pool(void) {
    long ncpu = sysconf(_SC_NPROCESSORS_CONF);
    if (ncpu < 1) ncpu = sysconf(_SC_NPROCESSORS_ONLN);
    int n = ncpu > 1 ? (int)ncpu : 1;
    if (MOTE_RESERVE_CORES > 0 && n > MOTE_RESERVE_CORES + 1) n -= MOTE_RESERVE_CORES;
    if (n > SPK_POOL_MAX) n = SPK_POOL_MAX;
    pool_threads = 1;
    for (int i = 1; i < n; i++) {
        pthread_t t;
        pthread_attr_t attr;
        pthread_attr_init(&attr);
        pthread_attr_setdetachstate(&attr, PTHREAD_CREATE_DETACHED);
        int ok = pthread_create(&t, &attr, worker, NULL) == 0;
        pthread_attr_destroy(&attr);
        if (!ok) break;   /* run with what we got */
        pool_threads++;
    }
}

void mote_parallel_for(int count, void (*fn)(int, int, void *), void *ctx) {
    if (count <= 0) return;
    pthread_once(&once, start_pool);
    if (pool_threads <= 1 || count < 2 || pthread_mutex_trylock(&call_mu) != 0) {
        fn(0, count, ctx);
        return;
    }
    int chunks = pool_threads * SPK_CHUNKS_PER_THREAD;
    if (chunks > count) chunks = count;
    job_fn = fn;
    job_ctx = ctx;
    job_count = count;
    job_chunks = chunks;
    atomic_store(&next_chunk, 0);
    atomic_store(&pending, pool_threads - 1);
    pthread_mutex_lock(&mu);
    atomic_fetch_add(&generation, 1);
    pthread_cond_broadcast(&cv_work);
    pthread_mutex_unlock(&mu);

    run_chunks();   /* the caller works too */

    for (int i = 0; i < SPK_SPIN && atomic_load(&pending) > 0; i++) cpu_relax();
    if (atomic_load(&pending) > 0) {
        pthread_mutex_lock(&mu);
        while (atomic_load(&pending) > 0) pthread_cond_wait(&cv_done, &mu);
        pthread_mutex_unlock(&mu);
    }
    pthread_mutex_unlock(&call_mu);
}
