// sparks_jni.cpp: the JNI bridge between the Kotlin module
// (com.cosquest.sparks.SparksNative) and the C core (cpp/sparks over cpp/mote).
// The Android counterpart of the C half of ios/RN/SparksModule.mm.
//
// Strings cross as UTF-8 byte arrays, never through NewStringUTF /
// GetStringUTFChars: those use modified UTF-8, which mangles emoji (4-byte
// sequences) and would hand the tokenizer different bytes than iOS does.
// Kotlin decodes with String(bytes, UTF_8), which replaces invalid UTF-8
// (a model can stop mid-sequence) as SPKString does on iOS.
//
// Threads: the engine and the transcriber call back on their own worker
// threads. Those are attached to the JVM on first use and detached when they
// exit (a pthread key destructor).
#include <jni.h>
#include <pthread.h>
#include <sys/auxv.h>

#include <atomic>
#include <cstdint>
#include <cstring>
#include <mutex>
#include <string>
#include <vector>

#include "sparks_core.h"
// mote_lib.h includes error.h (mote_last_error) above its own extern "C"
// block, so the whole header is wrapped here; cpp/mote stays unedited.
extern "C" {
#include "mote_lib.h"
}

#if defined(__aarch64__)
#include <asm/hwcap.h>
#endif

#define SPK_JNI(ret, name) extern "C" JNIEXPORT ret JNICALL Java_com_cosquest_sparks_SparksNative_##name

namespace {

JavaVM *g_vm = nullptr;
pthread_key_t g_detach_key;

void detach_thread(void *) {
  if (g_vm) g_vm->DetachCurrentThread();
}

/// The JNIEnv of this thread, attaching it (once) if it is a native worker.
JNIEnv *env_for_thread() {
  JNIEnv *env = nullptr;
  if (!g_vm) return nullptr;
  jint rc = g_vm->GetEnv(reinterpret_cast<void **>(&env), JNI_VERSION_1_6);
  if (rc == JNI_OK) return env;
  if (rc != JNI_EDETACHED) return nullptr;
  JavaVMAttachArgs args{JNI_VERSION_1_6, const_cast<char *>("sparks-native"), nullptr};
  if (g_vm->AttachCurrentThread(&env, &args) != JNI_OK) return nullptr;
  pthread_setspecific(g_detach_key, env);   // non-null value: the destructor runs at thread exit
  return env;
}

/// A callback must never leave an exception pending on a native thread.
void clear_exception(JNIEnv *env) {
  if (env->ExceptionCheck()) {
    env->ExceptionDescribe();
    env->ExceptionClear();
  }
}

std::string bytes_of(JNIEnv *env, jbyteArray a) {
  if (!a) return std::string();
  jsize n = env->GetArrayLength(a);
  std::string s(static_cast<size_t>(n), '\0');
  if (n > 0) env->GetByteArrayRegion(a, 0, n, reinterpret_cast<jbyte *>(&s[0]));
  return s;
}

jbyteArray to_bytes(JNIEnv *env, const char *s) {
  if (!s) s = "";
  jsize n = static_cast<jsize>(std::strlen(s));
  jbyteArray a = env->NewByteArray(n);
  if (a && n > 0) env->SetByteArrayRegion(a, 0, n, reinterpret_cast<const jbyte *>(s));
  return a;
}

/// Same rule as SPKMessage on iOS: the detail if any, else mote's last error
/// for an engine failure, else the status number.
std::string status_message(int status, const char *detail) {
  if (detail && *detail) return detail;
  if (status == SPK_E_ENGINE) {
    const char *why = mote_last_error();
    if (why && *why) return why;
  }
  return "engine status " + std::to_string(status);
}

// ------------------------------------------------------------------ engine

/// One per module instance. Owns the spk_engine (created on the first load,
/// as on iOS) and a global ref to the Kotlin listener.
struct EngineBox {
  spk_engine *engine = nullptr;
  jobject listener = nullptr;   // SparksNative.EngineListener (global ref)
  jmethodID onPiece = nullptr, onDone = nullptr, onState = nullptr, memoryOK = nullptr;
  std::mutex errMutex;
  std::string lastError;
};

struct Request {
  EngineBox *box;
  jlong jsId;
  bool stream;
};

int on_memory_ok(void *user, int which) {
  auto *box = static_cast<EngineBox *>(user);
  JNIEnv *env = env_for_thread();
  if (!env || !box->listener) return 1;
  jboolean ok = env->CallBooleanMethod(box->listener, box->memoryOK, static_cast<jint>(which));
  if (env->ExceptionCheck()) {
    clear_exception(env);
    return 1;
  }
  return ok ? 1 : 0;
}

int on_piece(const char *piece, void *user) {
  auto *r = static_cast<Request *>(user);
  if (!r->stream) return 1;
  JNIEnv *env = env_for_thread();
  if (!env) return 1;
  jbyteArray p = to_bytes(env, piece);
  env->CallVoidMethod(r->box->listener, r->box->onPiece, r->jsId, p);
  clear_exception(env);
  env->DeleteLocalRef(p);
  return 1;
}

void on_done(const spk_stats *st, const char *text, const float *vec, int dim, void *user) {
  auto *r = static_cast<Request *>(user);
  JNIEnv *env = env_for_thread();
  if (env) {
    jbyteArray message = nullptr, out = nullptr;
    jfloatArray v = nullptr;
    if (st->status != SPK_OK) {
      message = to_bytes(env, status_message(st->status, nullptr).c_str());
    } else if (vec) {
      v = env->NewFloatArray(dim);
      if (v && dim > 0) env->SetFloatArrayRegion(v, 0, dim, vec);
    } else {
      out = to_bytes(env, text);
    }
    jdouble s[6] = {static_cast<jdouble>(st->tokens_out), static_cast<jdouble>(st->tokens_in_est), st->first_token_ms,
                    st->wall_ms, st->run_ms, static_cast<jdouble>(st->preemptions)};
    jdoubleArray stats = env->NewDoubleArray(6);
    if (stats) env->SetDoubleArrayRegion(stats, 0, 6, s);
    env->CallVoidMethod(r->box->listener, r->box->onDone, r->jsId, static_cast<jint>(st->status), message, out, stats, v);
    clear_exception(env);
    if (message) env->DeleteLocalRef(message);
    if (out) env->DeleteLocalRef(out);
    if (v) env->DeleteLocalRef(v);
    if (stats) env->DeleteLocalRef(stats);
  }
  delete r;
}

/// running, queuedWarden, queuedInteractive, queuedBackground, pausedMask,
/// wardenLoaded, sparksLoaded, modelAttached.
void fill_state(const spk_engine_state *s, int attached, jint out[8]) {
  out[0] = s->running;
  out[1] = s->queued[SPK_P_WARDEN];
  out[2] = s->queued[SPK_P_INTERACTIVE];
  out[3] = s->queued[SPK_P_BACKGROUND];
  out[4] = static_cast<jint>(s->paused_mask);
  out[5] = s->loaded[SPK_H_WARDEN] != 0;
  out[6] = s->loaded[SPK_H_SPARKS] != 0;
  out[7] = attached;
}

void on_engine_state(const spk_engine_state *s, void *user) {
  auto *box = static_cast<EngineBox *>(user);
  JNIEnv *env = env_for_thread();
  if (!env) return;
  jint v[8];
  fill_state(s, 1, v);
  jintArray a = env->NewIntArray(8);
  if (!a) return;
  env->SetIntArrayRegion(a, 0, 8, v);
  env->CallVoidMethod(box->listener, box->onState, a);
  clear_exception(env);
  env->DeleteLocalRef(a);
}

spk_backend no_backend() {
  spk_backend none;
  std::memset(&none, 0, sizeof none);
  return none;
}

// -------------------------------------------------------------------- ASR

/// A transcriber plus the Kotlin listener of its running session.
struct AsrBox {
  spk_asr *asr = nullptr;
  jobject listener = nullptr;   // SparksNative.AsrListener (global ref) while a session runs
  jmethodID onLine = nullptr;
};

void on_asr_line(const spk_asr_line *line, void *user) {
  auto *box = static_cast<AsrBox *>(user);
  JNIEnv *env = env_for_thread();
  if (!env || !box->listener) return;
  jbyteArray text = to_bytes(env, line->text);
  env->CallVoidMethod(box->listener, box->onLine, static_cast<jlong>(line->line_id), text, line->start_s,
                      line->duration_s, static_cast<jboolean>(line->final != 0));
  clear_exception(env);
  env->DeleteLocalRef(text);
}

void drop_listener(JNIEnv *env, AsrBox *box) {
  if (box->listener) {
    env->DeleteGlobalRef(box->listener);
    box->listener = nullptr;
  }
}

}  // namespace

extern "C" JNIEXPORT jint JNICALL JNI_OnLoad(JavaVM *vm, void *) {
  g_vm = vm;
  pthread_key_create(&g_detach_key, detach_thread);
  return JNI_VERSION_1_6;
}

// ------------------------------------------------------------------ device

/// The ABI this library was built for; the model tiers need arm64-v8a.
SPK_JNI(jstring, abi)(JNIEnv *env, jclass) {
#if defined(__aarch64__)
  return env->NewStringUTF("arm64-v8a");
#elif defined(__arm__)
  return env->NewStringUTF("armeabi-v7a");
#elif defined(__x86_64__)
  return env->NewStringUTF("x86_64");
#elif defined(__i386__)
  return env->NewStringUTF("x86");
#else
  return env->NewStringUTF("unknown");
#endif
}

/// ARMv8.2 dot product (SDOT/UDOT), from the kernel's hwcaps.
SPK_JNI(jboolean, armDotProd)(JNIEnv *, jclass) {
#if defined(__aarch64__) && defined(HWCAP_ASIMDDP)
  return (getauxval(AT_HWCAP) & HWCAP_ASIMDDP) ? JNI_TRUE : JNI_FALSE;
#else
  return JNI_FALSE;
#endif
}

SPK_JNI(jboolean, asrAvailable)(JNIEnv *, jclass) {
  return spk_asr_available() ? JNI_TRUE : JNI_FALSE;
}

// --------------------------------------------------------- text utilities

/// The repaired JSON object, or null when the text holds none.
SPK_JNI(jbyteArray, jsonRepair)(JNIEnv *env, jclass, jbyteArray raw) {
  std::string in = bytes_of(env, raw);
  std::vector<char> out(in.size() * 2 + 64);
  int rc = spk_json_repair(in.c_str(), out.data(), out.size());
  return rc >= 0 ? to_bytes(env, out.data()) : nullptr;
}

SPK_JNI(jbyteArray, wardenClean)(JNIEnv *env, jclass, jbyteArray raw) {
  std::string in = bytes_of(env, raw);
  std::vector<char> out(in.size() + 1);
  spk_warden_clean(in.c_str(), out.data(), out.size());
  return to_bytes(env, out.data());
}

/// null when the line may be said, else why not ("rejected" if the check gave no reason).
SPK_JNI(jbyteArray, wardenCheck)(JNIEnv *env, jclass, jbyteArray text, jbyteArray moment, jbyteArray input,
                                 jbyteArray place, jint maxWords) {
  std::string t = bytes_of(env, text), m = bytes_of(env, moment), i = bytes_of(env, input), p = bytes_of(env, place);
  char why[160] = {0};
  int bad = spk_warden_check(t.c_str(), m.c_str(), i.c_str(), p.empty() ? nullptr : p.c_str(), maxWords, why, sizeof why);
  if (!bad) return nullptr;
  return to_bytes(env, why[0] ? why : "rejected");
}

// ------------------------------------------------------------------ engine

SPK_JNI(jlong, engineNew)(JNIEnv *env, jclass, jobject listener) {
  auto *box = new EngineBox();
  box->listener = env->NewGlobalRef(listener);
  jclass cls = env->GetObjectClass(listener);
  box->onPiece = env->GetMethodID(cls, "onPiece", "(J[B)V");
  box->onDone = env->GetMethodID(cls, "onDone", "(JI[B[B[D[F)V");
  box->onState = env->GetMethodID(cls, "onEngineState", "([I)V");
  box->memoryOK = env->GetMethodID(cls, "memoryOK", "(I)Z");
  env->DeleteLocalRef(cls);
  if (!box->onPiece || !box->onDone || !box->onState || !box->memoryOK) {
    env->DeleteGlobalRef(box->listener);
    delete box;
    return 0;   // NoSuchMethodError is pending for the caller
  }
  return reinterpret_cast<jlong>(box);
}

/// Fails queued requests with E_CANCELLED (their on_done runs), then frees.
SPK_JNI(void, engineFree)(JNIEnv *env, jclass, jlong h) {
  auto *box = reinterpret_cast<EngineBox *>(h);
  if (!box) return;
  if (box->engine) {
    spk_set_observer(box->engine, nullptr, nullptr);
    spk_engine_free(box->engine);
    box->engine = nullptr;
  }
  env->DeleteGlobalRef(box->listener);
  delete box;
}

/// Attach a model (first load creates the engine; later loads swap the
/// backend, waiting for the running request) and open the Warden handle,
/// which validates the file and reports its shape into info[5].
/// Returns SPK_OK or a SPK_E_* status; engineLastError has the detail.
SPK_JNI(jint, engineLoad)(JNIEnv *env, jclass, jlong h, jbyteArray modelPath, jbyteArray tokenizerPath,
                          jint pausedMask, jboolean preloadSparks, jintArray info) {
  auto *box = reinterpret_cast<EngineBox *>(h);
  std::string model = bytes_of(env, modelPath), tok = bytes_of(env, tokenizerPath);
  auto fail = [&](int rc, const std::string &why) {
    std::lock_guard<std::mutex> lock(box->errMutex);
    box->lastError = why;
    return static_cast<jint>(rc);
  };
  spk_backend be = spk_mote_backend(model.c_str(), tok.c_str(), on_memory_ok, box);
  if (!be.generate) return fail(SPK_E_MEMORY, "could not allocate the engine backend");
  if (!box->engine) {
    box->engine = spk_engine_create(be);
    if (!box->engine) return fail(SPK_E_MEMORY, "could not start the engine thread");
    spk_set_paused(box->engine, static_cast<unsigned>(pausedMask));
    spk_set_observer(box->engine, on_engine_state, box);
  } else {
    spk_engine_set_backend(box->engine, be);
  }
  int out[SPK_INFO_COUNT] = {0};
  char err[256] = {0};
  int rc = spk_engine_info(box->engine, SPK_H_WARDEN, out, err, sizeof err);
  if (rc != SPK_OK) {
    spk_engine_set_backend(box->engine, no_backend());
    return fail(rc, status_message(rc, err));
  }
  if (preloadSparks) spk_preload(box->engine, SPK_H_SPARKS, err, sizeof err);   // best effort
  jint v[SPK_INFO_COUNT];
  for (int i = 0; i < SPK_INFO_COUNT; i++) v[i] = out[i];
  env->SetIntArrayRegion(info, 0, SPK_INFO_COUNT, v);
  return SPK_OK;
}

SPK_JNI(jbyteArray, engineLastError)(JNIEnv *env, jclass, jlong h) {
  auto *box = reinterpret_cast<EngineBox *>(h);
  std::lock_guard<std::mutex> lock(box->errMutex);
  return to_bytes(env, box->lastError.c_str());
}

/// Detach the model: cancels queued work, closes both handles.
SPK_JNI(void, engineDetach)(JNIEnv *, jclass, jlong h) {
  auto *box = reinterpret_cast<EngineBox *>(h);
  if (box->engine) spk_engine_set_backend(box->engine, no_backend());
}

/// Unload one handle; deferred until idle if it is busy.
SPK_JNI(void, engineUnload)(JNIEnv *, jclass, jlong h, jint which) {
  auto *box = reinterpret_cast<EngineBox *>(h);
  if (box->engine && which >= 0 && which < SPK_H_COUNT) spk_unload(box->engine, which);
}

SPK_JNI(jboolean, engineAttached)(JNIEnv *, jclass, jlong h) {
  auto *box = reinterpret_cast<EngineBox *>(h);
  return box->engine && spk_engine_has_backend(box->engine) ? JNI_TRUE : JNI_FALSE;
}

/// Submit a generate (embed = false) or embed request. Returns the engine id
/// (> 0), or a negative SPK_E_* status, in which case onDone will not run.
SPK_JNI(jlong, engineSubmit)(JNIEnv *env, jclass, jlong h, jlong jsId, jint priority, jbyteArray prompt,
                             jbyteArray schema, jbyteArray stop, jfloat temperature, jfloat topP,
                             jfloat repeatPenalty, jint maxTokens, jlong seed, jboolean stream, jboolean embed) {
  auto *box = reinterpret_cast<EngineBox *>(h);
  if (!box->engine) return SPK_E_NOT_READY;
  std::string p = bytes_of(env, prompt), sc = bytes_of(env, schema), st = bytes_of(env, stop);
  auto *ctx = new Request{box, jsId, stream == JNI_TRUE};
  spk_request r;
  std::memset(&r, 0, sizeof r);
  r.priority = priority;
  r.prompt = p.c_str();   // copied by spk_submit
  r.embed = embed ? 1 : 0;
  if (!embed) {
    r.schema = sc.empty() ? nullptr : sc.c_str();
    r.stop = st.empty() ? nullptr : st.c_str();
    r.params.temperature = temperature;
    r.params.topp = topP;
    r.params.repeat_penalty = repeatPenalty;
    r.params.max_tokens = maxTokens;
    r.params.seed = static_cast<unsigned long long>(seed);
    r.on_piece = ctx->stream ? on_piece : nullptr;
  }
  r.on_done = on_done;
  r.user = ctx;
  int64_t id = spk_submit(box->engine, &r);
  if (id < 0) delete ctx;
  return static_cast<jlong>(id);
}

SPK_JNI(void, engineCancel)(JNIEnv *, jclass, jlong h, jlong id) {
  auto *box = reinterpret_cast<EngineBox *>(h);
  if (box->engine && id > 0) spk_cancel(box->engine, id);
}

SPK_JNI(void, engineSetPaused)(JNIEnv *, jclass, jlong h, jint mask) {
  auto *box = reinterpret_cast<EngineBox *>(h);
  if (box->engine) spk_set_paused(box->engine, static_cast<unsigned>(mask));
}

SPK_JNI(jintArray, engineState)(JNIEnv *env, jclass, jlong h) {
  auto *box = reinterpret_cast<EngineBox *>(h);
  spk_engine_state s;
  std::memset(&s, 0, sizeof s);
  s.running = -1;
  int attached = 0;
  if (box->engine) {
    spk_engine_get_state(box->engine, &s);
    attached = spk_engine_has_backend(box->engine);
  }
  jint v[8];
  fill_state(&s, attached, v);
  jintArray a = env->NewIntArray(8);
  if (a) env->SetIntArrayRegion(a, 0, 8, v);
  return a;
}

// ------------------------------------------------------------ transcription

/// A transcriber over the four verified files. Throws IllegalStateException
/// (and returns 0) when this build has no runtime or a path is missing.
SPK_JNI(jlong, asrCreate)(JNIEnv *env, jclass, jbyteArray encoder, jbyteArray decoder, jbyteArray tokenizer,
                          jbyteArray vad) {
  std::string e = bytes_of(env, encoder), d = bytes_of(env, decoder), t = bytes_of(env, tokenizer),
              v = bytes_of(env, vad);
  spk_asr_paths p = {e.c_str(), d.c_str(), t.c_str(), v.c_str()};
  char err[256] = {0};
  spk_asr *a = spk_asr_create(&p, err, sizeof err);
  if (!a) {
    jclass ex = env->FindClass("java/lang/IllegalStateException");
    if (ex) env->ThrowNew(ex, err[0] ? err : "could not create the transcriber");
    return 0;
  }
  auto *box = new AsrBox();
  box->asr = a;
  return reinterpret_cast<jlong>(box);
}

/// Load the models and start a run; lines go to listener.onLine on the worker
/// thread. Returns SPK_OK or a status (asrLastError has the detail).
SPK_JNI(jint, asrStart)(JNIEnv *env, jclass, jlong h, jint partialMs, jobject listener) {
  auto *box = reinterpret_cast<AsrBox *>(h);
  drop_listener(env, box);
  jclass cls = env->GetObjectClass(listener);
  box->onLine = env->GetMethodID(cls, "onLine", "(J[BDDZ)V");
  env->DeleteLocalRef(cls);
  if (!box->onLine) return SPK_E_INVALID;
  box->listener = env->NewGlobalRef(listener);
  spk_asr_set_muted(box->asr, 0);
  int rc = spk_asr_start(box->asr, partialMs, on_asr_line, box);
  if (rc != SPK_OK) drop_listener(env, box);
  return rc;
}

SPK_JNI(jbyteArray, asrLastError)(JNIEnv *env, jclass, jlong h) {
  auto *box = reinterpret_cast<AsrBox *>(h);
  return to_bytes(env, spk_asr_last_error(box->asr));
}

/// SparksAudioSink: audio-thread safe. Pins the array, copies into the ring, returns.
SPK_JNI(void, asrPushI16)(JNIEnv *env, jclass, jlong h, jshortArray samples, jint count, jint sampleRate) {
  auto *box = reinterpret_cast<AsrBox *>(h);
  if (!box || !samples || count <= 0) return;
  jsize len = env->GetArrayLength(samples);
  if (count > len) count = len;
  void *p = env->GetPrimitiveArrayCritical(samples, nullptr);
  if (!p) return;
  spk_asr_push_i16(box->asr, static_cast<const int16_t *>(p), count, sampleRate);
  env->ReleasePrimitiveArrayCritical(samples, p, JNI_ABORT);
}

SPK_JNI(void, asrPushF32)(JNIEnv *env, jclass, jlong h, jfloatArray samples, jint count, jint sampleRate) {
  auto *box = reinterpret_cast<AsrBox *>(h);
  if (!box || !samples || count <= 0) return;
  jsize len = env->GetArrayLength(samples);
  if (count > len) count = len;
  void *p = env->GetPrimitiveArrayCritical(samples, nullptr);
  if (!p) return;
  spk_asr_push_f32(box->asr, static_cast<const float *>(p), count, sampleRate);
  env->ReleasePrimitiveArrayCritical(samples, p, JNI_ABORT);
}

/// The JS testing path (asrPush): 16 kHz mono PCM16LE as base64, decoded in C as on iOS.
SPK_JNI(void, asrPushBase64)(JNIEnv *env, jclass, jlong h, jbyteArray base64, jdouble startMs) {
  auto *box = reinterpret_cast<AsrBox *>(h);
  std::string b64 = bytes_of(env, base64);
  if (b64.empty()) return;
  std::vector<uint8_t> bytes(spk_b64_decoded_max(b64.size()));
  int n = spk_b64_decode(b64.c_str(), b64.size(), bytes.data(), bytes.size());
  if (n <= 1) return;
  std::vector<int16_t> samples(static_cast<size_t>(n) / 2);
  int count = spk_pcm16le_to_i16(bytes.data(), static_cast<size_t>(n), samples.data(), static_cast<int>(samples.size()));
  spk_asr_push_i16_at(box->asr, samples.data(), count, 16000, startMs);
}

SPK_JNI(void, asrSetMuted)(JNIEnv *, jclass, jlong h, jboolean muted) {
  auto *box = reinterpret_cast<AsrBox *>(h);
  spk_asr_set_muted(box->asr, muted ? 1 : 0);
}

/// Delivers the open utterance as final, joins the worker, releases the
/// models; then drops the session's listener.
SPK_JNI(void, asrStop)(JNIEnv *env, jclass, jlong h) {
  auto *box = reinterpret_cast<AsrBox *>(h);
  spk_asr_stop(box->asr);
  drop_listener(env, box);
}

SPK_JNI(void, asrFree)(JNIEnv *env, jclass, jlong h) {
  auto *box = reinterpret_cast<AsrBox *>(h);
  if (!box) return;
  spk_asr_free(box->asr);
  drop_listener(env, box);
  delete box;
}
