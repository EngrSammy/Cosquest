/**
 * @cosquest/sparks-sdk: public TypeScript API.
 *
 * This file is NORMATIVE. docs/API.md reproduces the regions below verbatim
 * (scripts/sync-api-doc.mjs keeps them in step; CI runs it with --check).
 * Wire shapes in the "protocol" region match schemas/*.json one to one.
 *
 * Implementation: createSparks runs the real SDK (src/impl) over the native
 * TurboModule (src/NativeSparks.ts, ios/RN). See docs/NATIVE_SDK.md for what
 * is real and what is pending. Without the native module (Expo Go, web)
 * createSparks rejects with E_NOT_INITIALIZED; use @cosquest/sparks-sdk-mock.
 */
import NativeSparks from './NativeSparks';
import { createNativeSparks } from './impl/sdk';
import { setErrorClass } from './impl/runtime';

// #region core
/** Semantic version of this API surface. */
export const SDK_VERSION = '1.2.3';
/** Version of the SDK <-> backend wire protocol (the `v` field of every envelope). */
export const PROTOCOL_VERSION = 1;

export type UserId = string;
export type DeviceId = string;
export type ChatId = string;
export type MessageId = string;
export type SparkId = string;
export type CallId = string;
export type JobId = string;
export type SegmentId = string;
export type TopicId = string;
export type SpanId = string;
/** RFC 3339 timestamp in UTC, e.g. "2026-10-11T14:03:22.120Z". */
export type IsoTimestamp = string;
/** Milliseconds. For call timing, milliseconds since the call's `startedAt` on the server clock. */
export type Millis = number;

export type Unsubscribe = () => void;

/** Structurally compatible with the global AbortSignal in React Native. */
export interface AbortSignalLike {
  readonly aborted: boolean;
  addEventListener(type: 'abort', listener: () => void): void;
  removeEventListener(type: 'abort', listener: () => void): void;
}

/**
 * What this phone can run.
 * - full: the 1.7B model (Qwen3-1.7B with the Sparks and Orchestrator skills, int4, ~0.97 GB).
 * - lite: the 0.6B model (Qwen3-0.6B with the same skills, int4, ~0.34 GB).
 * - none: no model; the phone still chats, calls and transcribes, and its AI
 *   jobs are done by another member's phone.
 */
export type DeviceTier = 'full' | 'lite' | 'none';

/**
 * What the player is doing, set by the host. Background AI work runs only in
 * 'idle' and 'map'. 'trivia' also pauses this user's call transcription,
 * because the call is muted for them during a trivia lock.
 */
export type GameState = 'idle' | 'map' | 'battle' | 'ar' | 'trivia' | 'background';
// #endregion core

// #region errors
export type SparksErrorCode =
  | 'E_NOT_IMPLEMENTED'          // stub build only
  | 'E_NOT_INITIALIZED'          // called before createSparks resolved, or after shutdown
  | 'E_ALREADY_INITIALIZED'      // createSparks called twice in one process
  | 'E_INVALID_ARGUMENT'         // a parameter failed validation; details.field names it
  | 'E_DEVICE_UNSUPPORTED'       // tier is 'none'; the call needs a local model
  | 'E_MODEL_NOT_READY'          // model not downloaded, verified and loaded
  | 'E_MODEL_DOWNLOAD_FAILED'    // network or HTTP failure; retryable
  | 'E_MODEL_CHECKSUM_MISMATCH'  // downloaded bytes do not hash to the manifest sha256
  | 'E_MODEL_INCOMPATIBLE'       // .mq format version newer than this engine supports
  | 'E_INSUFFICIENT_STORAGE'     // free space below file size + 500 MB
  | 'E_INSUFFICIENT_MEMORY'      // the OS refused the allocation or memory pressure is critical
  | 'E_BUSY'                     // the scheduler queue for this priority is full
  | 'E_PREEMPTED'                // a higher-priority job took the engine; safe to retry
  | 'E_PAUSED'                   // game state or app state forbids this work now
  | 'E_CANCELLED'                // the caller aborted
  | 'E_TIMEOUT'                  // deadline passed
  | 'E_GRAMMAR_UNSTARTED'        // constrained output would have been mostly invented (mote -1)
  | 'E_NO_MATCH'                 // nothing scored above the threshold
  | 'E_TRANSCRIPTION_UNAVAILABLE'// ASR model failed to load or the audio source is unavailable
  | 'E_PERMISSION_DENIED'        // microphone permission not granted
  | 'E_CONSENT_REQUIRED'         // transcription started before the user accepted the notice
  | 'E_LEASE_EXPIRED'            // a job result arrived after its lease ended
  | 'E_LEASE_CONFLICT'           // the job is leased to another device
  | 'E_DECRYPT_FAILED'           // a sealed payload did not open with this device's key
  | 'E_PAYLOAD_INVALID'          // a backend message failed schema validation
  | 'E_TRANSPORT'                // the host transport rejected a send
  | 'E_ENGINE'                   // the inference engine failed; details.engineMessage has mote_last_error()
  | 'E_INTERNAL';                // a bug; please report with details

export interface SparksErrorInfo {
  code: SparksErrorCode;
  message: string;
  /** True when the same call may succeed later without any change by the caller. */
  retryable: boolean;
  details?: Record<string, string | number | boolean | null>;
}

export class SparksError extends Error implements SparksErrorInfo {
  readonly code: SparksErrorCode;
  readonly retryable: boolean;
  readonly details?: Record<string, string | number | boolean | null>;
  constructor(info: SparksErrorInfo) {
    super(info.message);
    this.name = 'SparksError';
    this.code = info.code;
    this.retryable = info.retryable;
    this.details = info.details;
  }
}
// #endregion errors
setErrorClass(SparksError);

// #region config
export interface SparksConfig {
  /** The signed-in user. Every local store is scoped to (userId, sessionId). */
  userId: UserId;
  /** The app login session. A new session id after logout opens a fresh, empty local store. */
  sessionId: string;
  /** Host-implemented bridge to the backend. See SparksTransport. */
  transport: SparksTransport;
  /** Model manifest URL, e.g. "https://<costquest-prod>/v1/model". */
  modelManifestUrl: string;
  /** Supplies a bearer token if the manifest or model files need one. */
  getAuthToken?: () => Promise<string>;
  /** Allow the model download on cellular data. Default false (Wi-Fi only). */
  allowCellularDownload?: boolean;
  /** Accept AI jobs leased by the backend. Default true. */
  acceptJobs?: boolean;
  /** BCP-47 locale for transcription and generated text. Default "en-US". English only in v1. */
  locale?: string;
  /** Overrides tier detection. Testing only; ignored in release builds. */
  forceTier?: DeviceTier;
  logLevel?: 'silent' | 'error' | 'warn' | 'info' | 'debug';
}

/**
 * The SDK never opens its own socket to the chat backend. The host app owns
 * auth and the realtime connection; it forwards backend messages to
 * `SparksSdk.receive` and delivers the SDK's outbound messages with `send`.
 */
export interface SparksTransport {
  /**
   * Deliver one message to the backend. Resolve when the backend (or the
   * host's socket layer) has accepted it; reject if it could not be sent.
   * On rejection the SDK retries with exponential backoff (1 s, 2 s, 4 s ...
   * capped at 60 s) while the message is still meaningful (see DATA_CONTRACT).
   */
  send(message: SdkToBackend): Promise<void>;
}

export interface DeviceCapabilities {
  tier: DeviceTier;
  platform: 'ios' | 'android';
  osVersion: string;
  deviceModel: string;
  ramBytes: number;
  /** ARM dot-product instructions (SDOT). Required for 'full' on Android. */
  armDotProd: boolean;
  /**
   * True when this build links the speech runtime and the Moonshine Base files
   * from the manifest's `asr` entry are downloaded and verified (`model.ensure()`).
   */
  transcription: boolean;
  /** Why the tier is lower than 'full', if it is. */
  tierReason?: 'ram' | 'cpu' | 'os' | 'storage' | 'forced' | 'manifest';
}
// #endregion config

// #region model
export type ModelPhase =
  | 'unsupported'      // tier 'none'
  | 'not_downloaded'
  | 'checking'         // fetching the manifest
  | 'downloading'
  | 'download_paused'  // waiting for Wi-Fi, storage or the app to return to foreground
  | 'verifying'        // hashing the downloaded file
  | 'ready'            // on disk and verified, not in memory
  | 'loading'
  | 'loaded'
  | 'error';

export interface ModelFileInfo {
  file: string;
  url: string;
  bytes: number;
  sha256: string;
}

export interface ModelVariantInfo {
  /** e.g. "AIMM 1.7B". */
  label: string;
  tier: Exclude<DeviceTier, 'none'>;
  model: ModelFileInfo;
  tokenizer: ModelFileInfo;
  minRamBytes: number;
}

export interface ModelStatus {
  phase: ModelPhase;
  tier: DeviceTier;
  /** The variant chosen for this phone, if any. */
  variant?: ModelVariantInfo;
  /** First 12 hex characters of the model's sha256: the model version. */
  version?: string;
  bytesDownloaded?: number;
  bytesTotal?: number;
  /** A newer verified version is waiting to be swapped in on next load. */
  updatePending?: boolean;
  error?: SparksErrorInfo;
}

export interface ModelApi {
  status(): ModelStatus;
  /** Fetch manifest, pick variant, download if needed, verify. Resolves at 'ready' or 'loaded'. */
  ensure(options?: { allowCellular?: boolean; signal?: AbortSignalLike }): Promise<ModelStatus>;
  /** Map the model into memory. Idempotent. */
  load(): Promise<ModelStatus>;
  /** Release model memory (KV caches and mapping). Files stay on disk. */
  unload(): Promise<void>;
  /** Re-read the manifest now (normally done at start and every 24 h). */
  checkForUpdate(): Promise<ModelStatus>;
  cancelDownload(): void;
  /** Delete downloaded model files. Releases the model first. */
  deleteFiles(): Promise<void>;
}
// #endregion model

// #region orchestrator
/**
 * The Orchestrator: the in-game persona voiced by the on-phone model (the
 * QLM). It writes short spoken lines for game moments, from facts the game
 * gives it, checked so it never invents a name or number. It is NOT the Game
 * Warden: the Game Warden is a separate server-side agent commanded by AIM
 * and is not part of this SDK. (The model's own training prompt still calls
 * the persona "Warden"; that internal name does not change.)
 */
/** Host-defined voice style, e.g. "arcade" or "mythic". Must be one the shipped model was trained on. */
export type OrchestratorStyle = string;

export interface SpeakOptions {
  /** 0.5 to 2.0, default 1.0. */
  rate?: number;
  /** 0.5 to 2.0, default 1.0. */
  pitch?: number;
  /** Duck game audio while speaking. Default true. */
  duckOthers?: boolean;
}

export interface OrchestratorSayRequest {
  /** The game moment, e.g. "arrive", "correct", "wrong", "streak", "level", "legend", "recap". */
  moment: string;
  /** The ONLY facts the line may use. Any number or name in the output that is not here rejects the line. */
  facts: Record<string, string | number>;
  style: OrchestratorStyle;
  /** Authored line returned when the model is absent, slow, or its line is rejected. Required. */
  fallback: string;
  /** Default 18. Lines are for speaking aloud in-game, so keep them short. */
  maxWords?: number;
  /** Return the fallback if no accepted line by then. Default 2500 ms. */
  deadlineMs?: number;
  /** Speak the result with on-device TTS. Default false. */
  speak?: boolean | SpeakOptions;
  /** Key for the pre-generation cache. Default: hash of moment + style + facts. */
  cacheKey?: string;
  signal?: AbortSignalLike;
}

export interface OrchestratorLine {
  text: string;
  moment: string;
  /** False when the authored fallback was used. */
  fromModel: boolean;
  /** Lines the checker rejected before this one (0 or 1; one retry, then fallback). */
  rejected: number;
  /** Served from the pre-generation cache. */
  cached: boolean;
  firstTokenMs?: number;
  tokensPerSecond?: number;
}

export interface OrchestratorApi {
  /** Write (or fetch from cache), check, optionally speak. Never rejects for model reasons: it falls back. */
  say(request: OrchestratorSayRequest): Promise<OrchestratorLine>;
  /** Pre-generate into the cache at the Orchestrator's priority (the highest) so a later say() is instant. */
  prepare(request: OrchestratorSayRequest): Promise<void>;
  /** Speak arbitrary text with on-device TTS. */
  speak(text: string, options?: SpeakOptions): Promise<void>;
  stopSpeaking(): void;
}

/** @deprecated Since 1.2: use OrchestratorStyle. Removed in 1.3. */
export type WardenStyle = OrchestratorStyle;
/** @deprecated Since 1.2: use OrchestratorSayRequest. Removed in 1.3. */
export type WardenSayRequest = OrchestratorSayRequest;
/** @deprecated Since 1.2: use OrchestratorLine. Removed in 1.3. */
export type WardenLine = OrchestratorLine;
/** @deprecated Since 1.2: use OrchestratorApi. Removed in 1.3. */
export type WardenApi = OrchestratorApi;
// #endregion orchestrator

// #region sparks-types
export interface ChatMember {
  userId: UserId;
  displayName: string;
  /** Faction rank name, e.g. "sergeant". Visual only; carries no permissions. */
  rank?: string;
  /**
   * Role designations used for role pings, e.g. "front-end". The model reads
   * these names, so use readable labels ("front-end", "quartermaster"), not
   * codes ("r_17"). Pings match a role by its exact string.
   */
  roles: string[];
  isAdmin: boolean;
}

export type ChatMessageKind = 'text' | 'voice' | 'media' | 'poll' | 'system';

export interface ChatMessage {
  messageId: MessageId;
  chatId: ChatId;
  /** Per-chat sequence number assigned by the backend, strictly increasing. */
  seq: number;
  senderId: UserId;
  kind: ChatMessageKind;
  /** Plain text. For voice notes, the transcript if one exists; for media, the caption. */
  text: string;
  sentAt: IsoTimestamp;
  replyToMessageId?: MessageId;
  /** The Spark this message belongs to, if any. */
  sparkId?: SparkId | null;
  /** Revival index of the Spark when this message was added (drives its colour marker). */
  sparkRevivalIndex?: number;
  /** Posted from inside the Spark panel (explicit membership, no AI needed). */
  postedInSpark?: boolean;
  deleted?: boolean;
}

export type SparkState = 'active' | 'dormant';

export interface Seam {
  /** The first message after the silence. */
  beforeMessageId: MessageId;
  gapMs: Millis;
  /** 'fold': quiet visual break, no text. 'labeled': break with `label`. */
  kind: 'fold' | 'labeled';
  /** e.g. "3 weeks later", "11 months later", "a year later". Null for folds. */
  label: string | null;
}

export interface SparkSummary {
  text: string;
  /** Highest chat seq the summary covers. */
  basedOnSeq: number;
  updatedAt: IsoTimestamp;
  /**
   * True when newer messages exist that the last summary round could not fold
   * in faithfully: `text` is the previous summary, and the next round (after
   * more messages) tries again with them. Absent or false: up to date.
   */
  stale?: boolean;
}

export interface Spark {
  sparkId: SparkId;
  chatId: ChatId;
  /** 2 to 6 words, at most 48 characters, e.g. "Spider-Man uniform". */
  subject: string;
  state: SparkState;
  pinned: boolean;
  /** 0 for a new Spark; +1 each revival. Colour = gradient(revivalIndex), an unbounded scale. */
  revivalIndex: number;
  summary: SparkSummary | null;
  messageCount: number;
  participantIds: UserId[];
  seams: Seam[];
  createdBy: { kind: 'bot' } | { kind: 'member'; userId: UserId };
  createdAt: IsoTimestamp;
  lastMessageAt: IsoTimestamp;
  /** Set when an admin merged this Spark into another. */
  mergedInto?: SparkId;
  /** Monotonic; increases on every change. Use it to drop out-of-order events. */
  version: number;
}

export type SparkEventKind =
  | 'created' | 'revived' | 'subject_changed' | 'summary_updated'
  | 'message_added' | 'dormant' | 'pinned' | 'unpinned' | 'merged' | 'deleted';

export interface SparkTopicEvent {
  kind: SparkEventKind;
  chatId: ChatId;
  spark: Spark;
  /** For 'message_added' and 'created'/'revived': the messages that joined. */
  messageIds?: MessageId[];
  /** Users the backend pinged for this Spark (role pings), if any. */
  pingedUserIds?: UserId[];
}

export interface SparkMatch {
  sparkId: SparkId;
  subject: string;
  state: SparkState;
  /** 0 to 1. Comparable only within one call. */
  score: number;
  method: 'embedding' | 'llm' | 'lexical';
}

export type StartSparkResolution = 'auto' | 'new' | { attachTo: SparkId };

export interface StartSparkRequest {
  chatId: ChatId;
  seedMessageId: MessageId;
  subject: string;
  /** 'auto' (default): check for duplicates first and return 'needs_choice' if any. */
  resolution?: StartSparkResolution;
}

export type StartSparkResult =
  | { status: 'created'; spark: Spark }
  | { status: 'attached'; spark: Spark }
  | { status: 'needs_choice'; candidates: SparkMatch[] };

export interface MergeSuggestion {
  sourceSparkId: SparkId;
  targetSparkId: SparkId;
  score: number;
  /** One sentence for the admin, e.g. "Both are about the uniform order deadline." */
  reason: string;
}

export interface RolePingSuggestion {
  role: string;
  userIds: UserId[];
  /** 0 to 1. The backend applies pings at or above its threshold (default 0.75). */
  confidence: number;
  reason: string;
}

export interface RelatedMessage {
  message: ChatMessage;
  score: number;
}

export interface IngestResult {
  stored: number;
  /** Outgoing messages by this user that were tagged and a hint queued. */
  hinted: number;
}
// #endregion sparks-types

// #region sparks-api
export interface SparksApi {
  /**
   * Give the SDK messages the user can see (decrypted, in any order; duplicates
   * by messageId are ignored). They go into the encrypted local store. For
   * messages sent by this user, the SDK asks the model which active Spark the
   * message belongs to (assign_message, background priority, with the last
   * few messages as context) and sends `message.spark_hint`. A phone without
   * a usable model, or with background work paused, does not hint: the
   * backend then sorts the message with a spark.assign job on another phone.
   * Call it for every message the app renders.
   */
  ingest(chatId: ChatId, messages: ChatMessage[], options?: { members?: ChatMember[] }): Promise<IngestResult>;
  /** Replace the member list (names, ranks, roles, admin flags) for a chat. */
  setMembers(chatId: ChatId, members: ChatMember[]): Promise<void>;
  /** The local mirror of the backend's Sparks for a chat, from received spark events. */
  getSparks(chatId: ChatId): Spark[];
  /** Fires for every backend-confirmed Spark change. The backend is the source of truth. */
  onTopic(listener: (event: SparkTopicEvent) => void): Unsubscribe;
  /** Summarize a Spark locally now. Does not post; use for "catch me up" views. */
  summarize(sparkId: SparkId, options?: { sinceSeq?: number; maxWords?: number; signal?: AbortSignalLike }): Promise<SparkSummary>;
  /**
   * Find active and dormant Sparks that a typed subject (and optional seed
   * text) duplicates. Local. With a model, the trained match_existing task
   * decides among the closest Sparks: at most one result, method 'llm', its
   * confidence as the score (floor 0.6; `minScore` does not apply). Without
   * one, subjects are compared lexically (method 'lexical', at or above
   * `minScore`, default thresholds.duplicateMinScore).
   */
  matchExisting(
    chatId: ChatId,
    query: { subject: string; seedText?: string },
    options?: { limit?: number; includeDormant?: boolean; minScore?: number },
  ): Promise<SparkMatch[]>;
  /** Manual "Start a Spark". Never merges silently: duplicates come back as 'needs_choice'. */
  startSpark(request: StartSparkRequest): Promise<StartSparkResult>;
  /** Pairs of Sparks an admin might merge. Suggestions only; merging is an admin action. */
  suggestMerges(chatId: ChatId, options?: { limit?: number }): Promise<MergeSuggestion[]>;
  /** Roles relevant to a Spark, from the chat's role designations. */
  suggestRolePings(sparkId: SparkId): Promise<RolePingSuggestion[]>;
  /** PROVISIONAL (requirements pending from Mark): earlier messages related to a query. Local. */
  findRelated(chatId: ChatId, query: string, options?: { limit?: number }): Promise<RelatedMessage[]>;
}
// #endregion sparks-api

// #region calls-types
/** One interface, one implementation in v1: Moonshine Base, downloaded with the model (manifest `asr`), not bundled. */
export type TranscriptionEngineId = 'moonshine-base';

/**
 * 'external' (recommended): the call stack feeds this user's mic audio to the
 * SDK through the native audio sink (SparksAudioSink in Swift/Kotlin), so the
 * SDK never opens a second capture. 'microphone': the SDK taps the input
 * itself (only when the call stack allows a shared input).
 */
export type AudioSource = 'external' | 'microphone';

export interface CommandContext {
  /** Rank names in order, lowest first, e.g. ["private", "corporal", "sergeant", ...]. */
  ranks: string[];
  roles: string[];
  groups: { groupId: string; name: string }[];
  members: { userId: UserId; displayName: string }[];
  /** Whether this user may issue targeted calls (decided by the backend). */
  canIssue: boolean;
}

export interface StartTranscriptionOptions {
  callId: CallId;
  chatId: ChatId;
  /** Server time the call started; segment times are relative to it. */
  callStartedAt: IsoTimestamp;
  audioSource?: AudioSource;
  /** Emit partial (non-final) local segments for live captions. Partials are never posted. Default true. */
  partials?: boolean;
  /** Listen for leader voice commands in this user's speech. False or omitted: off. */
  commands?: CommandContext | false;
}

export interface TranscriptionSession {
  readonly callId: CallId;
  readonly engine: TranscriptionEngineId;
  readonly startedAt: IsoTimestamp;
  /** Mute stops transcribing without stopping the session (used for trivia lock and opt-out). */
  setMuted(muted: boolean): void;
  stop(): Promise<void>;
}

export interface AudioFrame {
  /** 16-bit signed little-endian PCM, mono, 16 kHz, base64. Testing path only. */
  pcm16Base64: string;
  /** Capture time of the first sample, ms since callStartedAt. */
  startMs: Millis;
}

export interface TranscriptSegment {
  segmentId: SegmentId;
  callId: CallId;
  /** The speaker: always the owner of the device that transcribed it. */
  userId: UserId;
  deviceId: DeviceId;
  startMs: Millis;
  endMs: Millis;
  text: string;
  final: boolean;
  locale: string;
  confidence?: number;
  engine: TranscriptionEngineId;
  origin: 'local' | 'remote';
}

export interface TopicShift {
  callId: CallId;
  topicId: TopicId;
  title: string;
  /** Index into the topic palette; a returning topic keeps its colour. */
  colorIndex: number;
  startedAtMs: Millis;
  /** The call came back to an earlier topic. */
  returning: boolean;
}

export type CommandAction = 'targeted_call_start' | 'targeted_call_end' | 'faction_alert' | 'private_call_request';

/** Flat on purpose: it is produced under a compiled JSON grammar (mote_grammar). */
export interface CallCommandIntent {
  action: CommandAction;
  targetType?: 'rank' | 'role' | 'group' | 'user';
  /** A value from the CommandContext lists (rank name, role, groupId or userId). */
  target?: string;
  /** For rank targets: include ranks above the target. Default false. */
  includeHigher?: boolean;
}

export interface CallCommandEvent {
  callId: CallId;
  intent: CallCommandIntent;
  utterance: string;
  segmentId: SegmentId;
  /** The host must show a cancellable confirmation, then call confirmCommand or let it lapse. */
  expiresAt: IsoTimestamp;
  commandId: string;
}

export interface PinSuggestion {
  callId: CallId;
  userId: UserId;
  reason: 'engagement' | 'addressed' | 'topic_lead';
  score: number;
}

export interface OutlineActionItem {
  text: string;
  ownerUserId?: UserId;
}

export interface OutlineTopic {
  topicId: TopicId;
  title: string;
  colorIndex: number;
  /** Logical position, 0-based. Not chronological. */
  order: number;
  summary: string;
  points: string[];
  decisions: string[];
  actionItems: OutlineActionItem[];
  spans: { startMs: Millis; endMs: Millis }[];
  speakerIds: UserId[];
}

export interface CallOutline {
  callId: CallId;
  chatId: ChatId;
  title: string;
  summary: string;
  startedAt: IsoTimestamp;
  endedAt: IsoTimestamp;
  topics: OutlineTopic[];
  segmentCount: number;
  generatedAt: IsoTimestamp;
  generatedBy: { deviceIds: DeviceId[]; modelVersion: string };
}

export interface OutlineInput {
  callId: CallId;
  chatId: ChatId;
  startedAt: IsoTimestamp;
  endedAt: IsoTimestamp;
  segments: TranscriptSegment[];
  topics: TopicShift[];
  participants: ChatMember[];
}

export interface TranscriptionNotice {
  /** Increment when the text changes; consent is recorded against it. */
  version: number;
  title: string;
  body: string;
  acceptLabel: string;
  declineLabel: string;
  /** Short label for the always-visible in-call indicator. */
  indicatorLabel: string;
}

export interface ConsentDecision {
  noticeVersion: number;
  decision: 'accepted' | 'declined';
  /** 'always' remembers the choice for future calls; 'call' applies to one call. */
  scope: 'always' | 'call';
  callId?: CallId;
}

export interface ConsentState {
  noticeVersion: number;
  decision: 'accepted' | 'declined' | 'unset';
  scope?: 'always' | 'call';
  decidedAt?: IsoTimestamp;
}
// #endregion calls-types

// #region calls-api
export interface CallsApi {
  /** Start transcribing THIS user's speech. Rejects E_CONSENT_REQUIRED until consent is 'accepted'. */
  startTranscription(options: StartTranscriptionOptions): Promise<TranscriptionSession>;
  stopTranscription(callId: CallId): Promise<void>;
  /** Testing path. Production audio goes native to native through SparksAudioSink. */
  pushAudio(callId: CallId, frame: AudioFrame): void;
  /** Local segments (partial and final) and remote finals relayed by the backend. */
  onSegment(listener: (segment: TranscriptSegment) => void): Unsubscribe;
  /** Backend-confirmed topic changes (proposed by the call's scribe device). */
  onTopicShift(listener: (shift: TopicShift) => void): Unsubscribe;
  /** A leader command heard in this user's own speech. */
  onCommand(listener: (event: CallCommandEvent) => void): Unsubscribe;
  /** Send a heard command to the backend after the user did not cancel it. */
  confirmCommand(commandId: string): Promise<void>;
  onPinSuggestion(listener: (suggestion: PinSuggestion) => void): Unsubscribe;
  /** Parse one utterance into an intent. Null when it is not a command. Local. */
  parseCommand(utterance: string, context: CommandContext): Promise<CallCommandIntent | null>;
  /** Build an outline locally from a full transcript (used by the job runner and the demo). */
  outline(input: OutlineInput, options?: { signal?: AbortSignalLike }): Promise<CallOutline>;
  getTranscriptionNotice(): TranscriptionNotice;
  getConsent(callId?: CallId): ConsentState;
  recordConsent(decision: ConsentDecision): Promise<void>;
}
// #endregion calls-api

// #region events
export type JobType =
  | 'spark.detect'
  | 'spark.assign'
  | 'spark.summarize'
  | 'spark.rolepings'
  | 'call.scribe'
  | 'call.outline.map'
  | 'call.outline.reduce';

export type JobOutcome = 'succeeded' | 'rejected' | 'released' | 'failed' | 'cancelled';

export interface JobInfo {
  jobId: JobId;
  type: JobType;
  attempt: number;
  startedAt: IsoTimestamp;
}

export interface SchedulerState {
  /**
   * The session currently using the engine. 'warden' is the Orchestrator's
   * lane (the highest priority); the value keeps its 1.0 name until 2.0.
   */
  running: 'warden' | 'interactive' | 'background' | null;
  queued: { warden: number; interactive: number; background: number };
  paused: boolean;
  pausedReason?: 'game_state' | 'app_background' | 'low_battery' | 'low_power_mode' | 'thermal' | 'memory';
}

export interface SparksEventMap {
  'model.status': ModelStatus;
  'scheduler': SchedulerState;
  'job.started': JobInfo;
  'job.finished': JobInfo & { outcome: JobOutcome; error?: SparksErrorInfo };
  'spark': SparkTopicEvent;
  /** A chat's Sparks were filled or replaced from the backend (catch-up after install or first open), not from a single change. Re-read getSparks. */
  'sparks.synced': { chatId: ChatId };
  'call.segment': TranscriptSegment;
  'call.topicShift': TopicShift;
  'call.command': CallCommandEvent;
  'call.pinSuggestion': PinSuggestion;
  'call.outlineReady': CallOutline;
  /** Every line the Orchestrator produced (model or fallback). */
  'orchestrator.line': OrchestratorLine;
  /** @deprecated Since 1.2: listen to 'orchestrator.line' (same payload, emitted alongside). Removed in 1.3. */
  'warden.line': OrchestratorLine;
  'error': SparksErrorInfo;
}
// #endregion events

// #region protocol
/** Every SDK <-> backend message. `id` is a UUIDv4 unique per message (used for dedupe). */
export interface Envelope<T extends string, P> {
  v: 1;
  type: T;
  id: string;
  ts: IsoTimestamp;
  payload: P;
}

/** HPKE (RFC 9180) base mode: DHKEM(X25519, HKDF-SHA256), HKDF-SHA256, AES-256-GCM. */
export interface SealedPayload {
  alg: 'hpke-x25519-sha256-aes256gcm';
  /** Key id of the recipient device key (from device.register). */
  kid: string;
  /** base64url, encapsulated ephemeral public key (32 bytes). */
  enc: string;
  /** base64url, ciphertext with the 16-byte tag appended. */
  ct: string;
}

export interface DeviceRegisterPayload {
  deviceId: DeviceId;
  userId: UserId;
  sessionId: string;
  /** 'server': the opt-in server fallback worker (docs/guides/SERVER_WORKER.md); the backend accepts it only from a device its host vouches for. */
  platform: 'ios' | 'android' | 'server';
  osVersion: string;
  appVersion: string;
  sdkVersion: string;
  tier: DeviceTier;
  modelVersion: string | null;
  transcription: boolean;
  /** base64url X25519 public key (32 bytes). */
  publicKey: string;
  kid: string;
}

export interface DeviceHeartbeatPayload {
  deviceId: DeviceId;
  foreground: boolean;
  gameState: GameState;
  modelLoaded: boolean;
  batteryLevel: number | null;
  charging: boolean;
  lowPowerMode: boolean;
  thermal: 'nominal' | 'fair' | 'serious' | 'critical';
  activeJobIds: JobId[];
  /** Accepting new jobs right now (all gates passed). */
  available: boolean;
}

export interface SparkHintPayload {
  chatId: ChatId;
  messageId: MessageId;
  seq: number;
  /** The active Spark this message belongs to, or null (it stays in the main chat). */
  sparkId: SparkId | null;
  /** 'model': 1 when the model chose a Spark, 0 for null (the task gives no confidence). 'embedding': cosine similarity. */
  score: number;
  /**
   * How the author's phone decided.
   * - 'model' (SDK 1.2+): the trained assign_message task, over the active
   *   Sparks and the last few messages. The backend takes `sparkId` as is.
   * - 'embedding' (SDK 1.1): cosine similarity. Still accepted; the backend
   *   applies `assignMinScore` to it.
   * - 'llm': reserved (no SDK sends it); treated like 'embedding'.
   */
  method: 'model' | 'embedding' | 'llm';
}

export interface SparkCreatePayload {
  clientRequestId: string;
  chatId: ChatId;
  seedMessageId: MessageId;
  subject: string;
  resolution: 'new' | { attachTo: SparkId };
}

export interface JobAckPayload {
  jobId: JobId;
  leaseToken: string;
  accepted: boolean;
  reason?: 'busy' | 'paused' | 'unsupported' | 'decrypt_failed';
}

export interface JobProgressPayload {
  jobId: JobId;
  leaseToken: string;
  /** 0 to 1. Each progress message extends the lease by the type's TTL. */
  progress: number;
}

export interface JobResultPayload {
  jobId: JobId;
  leaseToken: string;
  type: JobType;
  idempotencyKey: string;
  output: JobOutput;
  metrics: { wallMs: number; tokensIn: number; tokensOut: number; modelVersion: string; tier: DeviceTier };
}

export interface JobReleasePayload {
  jobId: JobId;
  leaseToken: string;
  reason: 'preempted' | 'paused' | 'app_background' | 'low_battery' | 'thermal' | 'error';
  error?: SparksErrorInfo;
}

export interface CallSegmentPayload {
  segment: Omit<TranscriptSegment, 'origin' | 'final'> & { final: true };
}

export interface CallTopicProposalPayload {
  callId: CallId;
  jobId: JobId;
  leaseToken: string;
  title: string;
  /** Set when the call returned to an earlier topic. */
  returningToTopicId: TopicId | null;
  startedAtMs: Millis;
  confidence: number;
}

export interface CallCommandPayload {
  commandId: string;
  callId: CallId;
  issuerUserId: UserId;
  segmentId: SegmentId;
  utterance: string;
  intent: CallCommandIntent;
}

export interface CallConsentPayload {
  userId: UserId;
  noticeVersion: number;
  decision: 'accepted' | 'declined';
  scope: 'always' | 'call';
  callId: CallId | null;
  decidedAt: IsoTimestamp;
}

export interface ContextRequestPayload {
  scope: 'chat' | 'call';
  chatId?: ChatId;
  callId?: CallId;
  /** Chat scope: return messages with seq > sinceSeq. */
  sinceSeq?: number;
  limit?: number;
}

export type SdkToBackend =
  | Envelope<'device.register', DeviceRegisterPayload>
  | Envelope<'device.heartbeat', DeviceHeartbeatPayload>
  | Envelope<'message.spark_hint', SparkHintPayload>
  | Envelope<'spark.create', SparkCreatePayload>
  | Envelope<'job.ack', JobAckPayload>
  | Envelope<'job.progress', JobProgressPayload>
  | Envelope<'job.result', JobResultPayload>
  | Envelope<'job.release', JobReleasePayload>
  | Envelope<'call.segment', CallSegmentPayload>
  | Envelope<'call.topic_proposal', CallTopicProposalPayload>
  | Envelope<'call.command', CallCommandPayload>
  | Envelope<'call.consent', CallConsentPayload>
  | Envelope<'context.request', ContextRequestPayload>;

export interface SparksThresholds {
  /** Embedding floor and margin for tagging a message to an active Spark (SDK 1.1 'embedding' hints only; SDK 1.2 hints come from the model). */
  assignMinScore: number;
  assignMinMargin: number;
  /** Score at or above which startSpark('auto') returns needs_choice. */
  duplicateMinScore: number;
  rolePingMinConfidence: number;
  /** Scribe cadence. */
  scribeIntervalMs: number;
  scribeMinNewSegments: number;
}

export interface DeviceRegisteredPayload {
  deviceId: DeviceId;
  serverTime: IsoTimestamp;
  thresholds: SparksThresholds;
}

export interface JobOfferPayload {
  jobId: JobId;
  type: JobType;
  leaseToken: string;
  leaseExpiresAt: IsoTimestamp;
  idempotencyKey: string;
  attempt: number;
  /** Absolute deadline after which the result is useless. */
  deadline: IsoTimestamp;
  /** Plaintext is a JobInput for `type`. */
  input: SealedPayload;
}

export interface JobCancelPayload {
  jobId: JobId;
  reason: 'superseded' | 'deadline' | 'reassigned' | 'call_ended';
}

export interface JobVerdictPayload {
  jobId: JobId;
  accepted: boolean;
  reason?: 'stale' | 'lease_expired' | 'duplicate' | 'invalid' | 'rule_check_failed';
}

export interface SparkEventPayload extends SparkTopicEvent {}

export interface SparkSnapshotPayload {
  chatId: ChatId;
  sparks: Spark[];
}

export interface CallSegmentRelayPayload {
  segment: Omit<TranscriptSegment, 'origin' | 'final'> & { final: true };
}

export interface CallEngagementPayload {
  callId: CallId;
  /** 0 to 1 per participant, for orbital placement. Updated every 2 s while anyone speaks. */
  scores: { userId: UserId; score: number }[];
  pinSuggestion: PinSuggestion | null;
}

export interface CallCommandAppliedPayload {
  commandId: string;
  callId: CallId;
  accepted: boolean;
  reason?: 'not_permitted' | 'unknown_target' | 'expired';
  targetUserIds?: UserId[];
}

export interface CallOutlineReadyPayload {
  outline: CallOutline;
}

export interface ContextBundlePayload {
  bundleId: string;
  scope: 'chat' | 'call';
  /** Plaintext is a ContextBundle. */
  sealed: SealedPayload;
}

export type BackendToSdk =
  | Envelope<'device.registered', DeviceRegisteredPayload>
  | Envelope<'job.offer', JobOfferPayload>
  | Envelope<'job.cancel', JobCancelPayload>
  | Envelope<'job.verdict', JobVerdictPayload>
  | Envelope<'spark.event', SparkEventPayload>
  | Envelope<'spark.snapshot', SparkSnapshotPayload>
  | Envelope<'call.segment', CallSegmentRelayPayload>
  | Envelope<'call.topic_shift', TopicShift>
  | Envelope<'call.engagement', CallEngagementPayload>
  | Envelope<'call.command_applied', CallCommandAppliedPayload>
  | Envelope<'call.outline_ready', CallOutlineReadyPayload>
  | Envelope<'context.bundle', ContextBundlePayload>;

/** One file in the model manifest. Field names follow the existing CostQuest backend. */
export interface ManifestFile {
  file: string;
  url: string;
  bytes: number;
  sha256: string;
}

/**
 * GET {modelManifestUrl}: the CostQuest /v1/model response. The SDK requests it
 * with `mq=<n>` appended, n being the newest `.mq` format its engine reads (5 in
 * SDK 1.2), so a server can leave variants an older SDK cannot load out of the
 * manifest it gives that SDK. `mq_version` and `tier` are optional; without
 * `tier` the SDK infers it from the label.
 */
export interface ModelManifest {
  /** First 12 hex characters of the preferred model's sha256. */
  version: string;
  label: string;
  model: ManifestFile;
  tokenizer: ManifestFile;
  min_ram_bytes: number;
  /** Best first. The phone picks the first whose min_ram_bytes it meets. */
  variants: {
    label: string;
    model: ManifestFile;
    tokenizer: ManifestFile;
    min_ram_bytes: number;
    /**
     * `.mq` format version of `model` (its header's second int32). The SDK
     * skips a variant newer than its engine reads. Absent: readable by every SDK.
     */
    mq_version?: number;
    tier?: 'full' | 'lite';
  }[];
  /**
   * Call transcription files. Optional: without it transcription stays off.
   * `model.ensure()` downloads and verifies them like the model, on every tier
   * (tier 'none' phones transcribe too), and keeps them across model updates.
   */
  asr?: AsrManifest;
}

/** Moonshine Base (English, int8, ONNX Runtime format) and the Silero voice activity detector. */
export interface AsrManifest {
  engine: 'moonshine-base';
  /** encoder_model.ort */
  encoder: ManifestFile;
  /** decoder_model_merged.ort */
  decoder: ManifestFile;
  /** tokenizer.bin */
  tokenizer: ManifestFile;
  /** silero_vad_16k_op15.onnx */
  vad: ManifestFile;
}

/** A Spark as a job sees it: enough to match against, no message bodies. */
export interface SparkCatalogEntry {
  sparkId: SparkId;
  subject: string;
  state: SparkState;
  summary: string | null;
  lastMessageAt: IsoTimestamp;
}

export interface OutlineSpanSummary {
  spanId: SpanId;
  title: string;
  summary: string;
  points: string[];
  decisions: string[];
  actionItems: OutlineActionItem[];
  startMs: Millis;
  endMs: Millis;
  speakerIds: UserId[];
}

/** Plaintext inside JobOfferPayload.input, by job type. */
export type JobInput =
  | { type: 'spark.detect'; chatId: ChatId; tipMessageId: MessageId; members: ChatMember[]; window: ChatMessage[]; context: ChatMessage[]; catalog: SparkCatalogEntry[] }
  | { type: 'spark.assign'; chatId: ChatId; messages: ChatMessage[]; active: SparkCatalogEntry[] }
  | { type: 'spark.summarize'; chatId: ChatId; sparkId: SparkId; subject: string; previousSummary: string | null; previousBasedOnSeq: number | null; messages: ChatMessage[]; members: ChatMember[] }
  | { type: 'spark.rolepings'; chatId: ChatId; sparkId: SparkId; subject: string; summary: string | null; roles: { role: string; userIds: UserId[] }[]; recent: ChatMessage[] }
  | { type: 'call.scribe'; callId: CallId; chatId: ChatId; callStartedAt: IsoTimestamp; participants: ChatMember[]; topics: TopicShift[]; recentSegments: TranscriptSegment[] }
  | { type: 'call.outline.map'; callId: CallId; spanId: SpanId; topicTitle: string; segments: TranscriptSegment[]; participants: ChatMember[] }
  | { type: 'call.outline.reduce'; callId: CallId; chatId: ChatId; startedAt: IsoTimestamp; endedAt: IsoTimestamp; spans: OutlineSpanSummary[] };

/** JobResultPayload.output, by job type. */
export type JobOutput =
  | { type: 'spark.detect'; verdict: 'new' | 'revive' | 'attach' | 'none'; subject: string | null; sparkId: SparkId | null; memberMessageIds: MessageId[]; confidence: number }
  | { type: 'spark.assign'; assignments: { messageId: MessageId; sparkId: SparkId | null; score: number }[] }
  /**
   * `stale: true` (SDK 1.2+): the model kept the previous summary although
   * enough new messages exist, even after one stricter retry. `summary` is
   * then the previous summary (empty when there was none); the backend keeps
   * its stored summary, marks it stale and retries in the next round.
   */
  | { type: 'spark.summarize'; summary: string; basedOnSeq: number; stale?: boolean }
  | { type: 'spark.rolepings'; pings: RolePingSuggestion[] }
  | { type: 'call.scribe'; proposals: number }
  | { type: 'call.outline.map'; span: OutlineSpanSummary }
  | { type: 'call.outline.reduce'; title: string; summary: string; topics: { title: string; spanIds: SpanId[]; summary: string; points: string[]; decisions: string[]; actionItems: OutlineActionItem[] }[] };

/** Plaintext inside ContextBundlePayload.sealed. */
export type ContextBundle =
  | { scope: 'chat'; userId: UserId; sessionId: string; chatId: ChatId; members: ChatMember[]; messages: ChatMessage[]; sparks: Spark[]; untilSeq: number; hasMore: boolean }
  | { scope: 'call'; userId: UserId; sessionId: string; callId: CallId; chatId: ChatId; startedAt: IsoTimestamp; endedAt: IsoTimestamp | null; segments: TranscriptSegment[]; topics: TopicShift[]; outline: CallOutline | null };
// #endregion protocol

// #region root
export interface SparksSdk {
  readonly version: string;
  readonly deviceId: DeviceId;
  readonly model: ModelApi;
  /** The in-game persona voiced by the on-phone model (see OrchestratorApi). */
  readonly orchestrator: OrchestratorApi;
  /** @deprecated Since 1.2: use `orchestrator` (the same object). Removed in 1.3. */
  readonly warden: OrchestratorApi;
  readonly sparks: SparksApi;
  readonly calls: CallsApi;
  /** Hand every backend message for the SDK to it, in arrival order. Never throws; bad input emits 'error'. */
  receive(message: BackendToSdk): void;
  /** Tell the SDK what the player is doing. Call on every change. */
  setGameState(state: GameState): void;
  getCapabilities(): Promise<DeviceCapabilities>;
  on<E extends keyof SparksEventMap>(event: E, listener: (payload: SparksEventMap[E]) => void): Unsubscribe;
  /** Logout: delete the local store, device key and caches; unregister. Model files stay. */
  wipe(): Promise<void>;
  /** Stop jobs (releasing leases), stop transcription, unload the model. */
  shutdown(): Promise<void>;
}

/**
 * Create the SDK (one per process). Resolves once the local store is open and
 * `device.register` has been accepted by `transport.send`. It does NOT wait
 * for the backend's `device.registered` (the host can only call `receive` on
 * the instance this returns): thresholds use their defaults until it arrives,
 * and the host buffers backend messages that arrive before this resolves and
 * replays them to `receive()`. The model may still be downloading. Rejects
 * with E_ALREADY_INITIALIZED on a second call.
 */
export function createSparks(config: SparksConfig): Promise<SparksSdk> {
  return createNativeSparks(config, NativeSparks);
}
// #endregion root
