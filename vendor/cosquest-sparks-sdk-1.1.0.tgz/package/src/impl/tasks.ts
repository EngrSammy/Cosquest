/**
 * The on-device model's tasks: prompt rendering, strict output parsing and
 * the rules the app keeps enforcing, per the model's task contract
 * (docs/MODEL_TASKS.md). Prompts must stay byte-compatible with what the
 * weights were trained on, so change them only together with a retrained model.
 *
 * Pure: no runtime imports, no I/O. The SDK passes a `Generate` function.
 */
import type {
  CallCommandIntent, ChatMember, ChatMessage, CommandContext, OutlineActionItem, RolePingSuggestion,
  SparkCatalogEntry, TopicShift, TranscriptSegment,
} from '../index';

// ------------------------------------------------------------------ prompts

/** Sparks system prompt (common.py SYSTEM), shared by every Sparks task so mote reuses the cached prefix. */
export const SPARKS_SYSTEM =
  'You are the Sparks bot inside CosQuest group chats and calls. Do the task named on the first ' +
  'line using only the given input. Reply with one line of compact JSON and nothing else.';
/** Warden system prompt (warden/eval_voice.py SYS). */
export const WARDEN_SYSTEM =
  'You are the Warden, the voice of CostQuest. Speak one line in the given style, using only the given facts.';

export type SparksTask =
  | 'subject_line' | 'running_summary' | 'match_existing' | 'assign_message'
  | 'call_outline' | 'topic_shift' | 'command_parse' | 'role_ping';

/** Max new tokens per task (common.py MAX_TOKENS). */
export const MAX_TOKENS: Record<SparksTask, number> = {
  subject_line: 24, running_summary: 120, match_existing: 24, assign_message: 16,
  call_outline: 700, topic_shift: 30, command_parse: 60, role_ping: 30,
};

export const COMMAND_ACTIONS = [
  'targeted_call_start', 'targeted_call_end', 'faction_alert', 'private_call_request',
  'pin', 'unpin', 'mute', 'remove', 'call_end', 'none',
] as const;

/** Qwen3 chat template with thinking off, exactly as the weights were tuned and evaluated. */
export function chatPrompt(system: string, user: string): string {
  return `<|im_start|>system\n${system}<|im_end|>\n<|im_start|>user\n${user}<|im_end|>\n<|im_start|>assistant\n<think>\n\n</think>\n\n`;
}

export function sparksPrompt(task: SparksTask, body: string): string {
  return chatPrompt(SPARKS_SYSTEM, `task: ${task}\n${body}`);
}

/** Whitespace-collapse and cut (common.py clean). */
export function clean(t: string, n = 300): string {
  const s = String(t).replace(/\s+/g, ' ').trim();
  return s.length <= n ? s : `${s.slice(0, n).trimEnd()}…`;
}

export interface Line { id?: string; who: string; text: string }

/** `Name: text` or `[id] Name: text`, one per line (common.py lines). */
export function lines(rows: Line[], cut = 300): string {
  return rows.map((r) => `${r.id ? `[${r.id}] ` : ''}${r.who}: ${clean(r.text, cut)}`).join('\n');
}

export function words(s: string | null | undefined): string[] {
  return (s ?? '').match(/[A-Za-z0-9][A-Za-z0-9'\-]*/g) ?? [];
}

export function nameOf(members: { userId: string; displayName: string }[], userId: string): string {
  return members.find((m) => m.userId === userId)?.displayName ?? userId;
}

export function messageLines(msgs: ChatMessage[], members: ChatMember[]): string {
  return lines(msgs.map((m) => ({ who: nameOf(members, m.senderId), text: m.text })));
}

// ------------------------------------------------------------- strict parse

/**
 * common.py parse(): drop a leading <think> block, take the outermost {...},
 * JSON.parse it. No repair: a model output that is not JSON is a failure and
 * the caller falls back (no Spark, no shift, not a command).
 */
export function parseStrict(text: string | null | undefined): Record<string, unknown> | null {
  let t = (text ?? '').trim().replace(/^<think>[\s\S]*?<\/think>\s*/, '');
  const a = t.indexOf('{'), b = t.lastIndexOf('}');
  if (a < 0 || b < a) return null;
  t = t.slice(a, b + 1);
  try {
    const o: unknown = JSON.parse(t);
    return o && typeof o === 'object' && !Array.isArray(o) ? (o as Record<string, unknown>) : null;
  } catch {
    return null;
  }
}

const isStr = (v: unknown): v is string => typeof v === 'string';
const isNum = (v: unknown): v is number => typeof v === 'number' && Number.isFinite(v);

// ----------------------------------------------------------- facts check

const STOP = new Set(`I A An The They He She It We You Everyone Someone Somebody Anyone Nobody Group Members Member Spark Sparks
Bot Chat Call Topic Plans Plan Both All Some Most Many Several Others Other One Two Three Four Five Six Seven Eight Nine
Ten Later Then Also After Before Earlier There This That These Those Their His Her Its Our No Yes Meanwhile Next Last New
Faction Players Player People Friends Team Leader Leaders If When While Since As To In On At For With From By Of And But Or
So AM PM OK Okay Plus However Instead Finally Still Not Only Just Each Every Mr Ms Discussion Discussed Talk Talked
Participants Participant Speakers Speaker Agreed Decided Asked Suggested Said Mentioned Confirmed Noted Shared
Proposed Planned Offered Wants Will Would Can Could Should May Might Must Is Are Was Were Has Have Had Be Been
Several Another Any Who What Where Why How Which First Second Third Final Next`.split(/\s+/));
const NUMW = 'zero one two three four five six seven eight nine ten eleven twelve'.split(' ');
const CONTEXT = new Set(['cosquest', 'sparks', 'comicverse', 'anime', 'realm', 'gaming', 'guild', 'fantasy', 'order', 'sci', 'fi', 'scifi',
  'fleet', 'faction', 'shrine', 'omega', 'sergeant', 'corporal', 'private', 'lieutenant', 'captain', 'commander', 'xp']);
const norm = (s: string) => s.toLowerCase().replace(/[^a-z0-9]/g, '');
const cap1 = (s: string) => s.charAt(0).toUpperCase() + s.slice(1).toLowerCase();
const dropS = (s: string) => (s.endsWith('s') ? s.slice(0, -1) : s);

/**
 * The training pipeline's facts check: capitalised words and numbers in `summary`
 * that never appear in `source`. Empty means faithful.
 */
export function unsupported(summary: string, source: string, names: string[] = []): string[] {
  const nameSet = new Set(names.map(norm));
  const initial = new Set(summary.trim().split(/(?<=[.!?])\s+/).map((s) => s.split(/\s+/)[0]).filter(Boolean).map(norm));
  const srcWords = words(source);
  const srcTokens = new Set([...srcWords.map(norm), ...srcWords.map((w) => dropS(norm(w)))]);
  const srcCat = norm(source);
  const srcNums = new Set(source.match(/\d+/g) ?? []);
  NUMW.forEach((w, i) => { if (new RegExp(`\\b${w}\\b`).test(source.toLowerCase())) srcNums.add(String(i)); });
  const bad: string[] = [];
  for (const w of words(summary)) {
    const base = w.replace(/'s$|'$/, '');
    if (/^\d[\d'\-]*$/.test(base)) {
      for (const n of base.match(/\d+/g) ?? []) if (!srcNums.has(n)) bad.push(n);
      continue;
    }
    if (!/^[A-Z]/.test(base) || STOP.has(base) || STOP.has(cap1(base)) || base.length === 1) continue;
    const n = norm(base);
    if (CONTEXT.has(n) || (initial.has(n) && !nameSet.has(n))) continue;
    if (!n || srcTokens.has(n) || srcTokens.has(dropS(n)) || (n.length >= 4 && srcCat.includes(n))) continue;
    bad.push(base);
  }
  for (const n of summary.match(/\d+/g) ?? []) if (!srcNums.has(n) && !bad.includes(n)) bad.push(n);
  return bad;
}

// ------------------------------------------------------------- the tasks

export type Generate = (task: SparksTask, prompt: string) => Promise<string>;

/** Opaque Spark ids become s1..sN for the model (it was trained on short ids) and back. */
export function aliasSparks<T extends { sparkId: string }>(entries: T[]): { rows: (T & { alias: string })[]; resolve: (a: unknown) => string | null } {
  const rows = entries.map((e, i) => ({ ...e, alias: `s${i + 1}` }));
  return { rows, resolve: (a) => (isStr(a) ? rows.find((r) => r.alias === a)?.sparkId ?? null : null) };
}

function sparkListing(e: { alias: string; subject: string; summary: string | null }): string {
  return `${e.subject} — ${e.summary ?? ''}`.replace(/[ —]+$/, '');
}

/** 1. subject_line: 2-5 words, or null. Outputs over 5 words are rejected (MODEL_TASKS.md). */
export async function subjectLine(gen: Generate, msgs: Line[]): Promise<string | null> {
  const o = parseStrict(await gen('subject_line', sparksPrompt('subject_line', `messages:\n${lines(msgs.slice(-10))}`)));
  if (!o || !('subject' in o)) return null;
  const s = o.subject;
  if (!isStr(s)) return null;
  const subject = s.trim();
  const n = words(subject).length;
  if (n < 1 || n > 5 || subject.length > 48) return null;
  return subject;
}

/**
 * 2. running_summary over at most 12 new lines per call (training shape);
 * longer inputs fold in batches. A summary that fails the facts check keeps
 * the previous one (MODEL_TASKS.md). Returns null only when there is no previous
 * summary and no batch produced a faithful one.
 */
export async function runningSummary(gen: Generate, previous: string | null, msgs: Line[], names: string[]): Promise<string | null> {
  let summary = previous;
  for (let i = 0; i < msgs.length; i += 12) {
    const batch = msgs.slice(i, i + 12);
    const body = `summary: ${summary ?? '(none)'}\nnew messages:\n${lines(batch)}`;
    const o = parseStrict(await gen('running_summary', sparksPrompt('running_summary', body)));
    const s = o && isStr(o.summary) ? o.summary.trim() : null;
    if (!s || words(s).length > 70 || s.length > 600) continue;
    const source = `${summary ?? ''}\n${batch.map((m) => `${m.who}: ${m.text}`).join('\n')}`;
    if (unsupported(s, source, names).length) continue;
    summary = s;
  }
  return summary;
}

export interface MatchCandidate { sparkId: string; subject: string; state: 'active' | 'dormant'; summary: string | null }

/** 3. match_existing. mode revival: candidate messages; manual: a typed subject plus seed message. */
export async function matchExisting(
  gen: Generate,
  candidate: { mode: 'revival'; messages: Line[] } | { mode: 'manual'; subject: string; seed: Line | null },
  existing: MatchCandidate[],
): Promise<{ sparkId: string | null; confidence: number } | null> {
  if (!existing.length) return { sparkId: null, confidence: 1 };
  const { rows, resolve } = aliasSparks(existing);
  const cand = candidate.mode === 'revival'
    ? `messages:\n${lines(candidate.messages)}`
    : `subject typed: ${candidate.subject}\nseed message:\n${candidate.seed ? `${candidate.seed.who}: ${candidate.seed.text}` : ''}`;
  const listing = rows.map((r) => `[${r.alias}] (${r.state}) ${sparkListing(r)}`).join('\n');
  const body = `mode: ${candidate.mode}\ncandidate ${cand}\nexisting sparks:\n${listing}`;
  const o = parseStrict(await gen('match_existing', sparksPrompt('match_existing', body)));
  if (!o || !('sparkId' in o) || !isNum(o.confidence) || !(o.sparkId === null || isStr(o.sparkId))) return null;
  const confidence = Math.max(0, Math.min(1, o.confidence));
  return { sparkId: o.sparkId === null ? null : resolve(o.sparkId), confidence };
}

/** 4. assign_message: which active Spark a new message belongs to, or null (main feed). */
export async function assignMessage(gen: Generate, active: SparkCatalogEntry[], recent: Line[], message: Line): Promise<string | null | undefined> {
  if (!active.length) return null;
  const { rows, resolve } = aliasSparks(active);
  const listing = rows.map((r) => `[${r.alias}] ${sparkListing(r)}`).join('\n');
  const body = `sparks:\n${listing}\nrecent:\n${lines(recent.slice(-3))}\nnew message:\n${message.who}: ${message.text}`;
  const o = parseStrict(await gen('assign_message', sparksPrompt('assign_message', body)));
  if (!o || !('sparkId' in o) || !(o.sparkId === null || isStr(o.sparkId))) return undefined;   // undefined = model failed
  return o.sparkId === null ? null : resolve(o.sparkId);
}

export interface OutlineGroup { title: string; summary: string; spanIds: string[] }

/** 5. call_outline over `[tN] Speaker: text` lines; ids are the line labels. Returns groups in logical order. */
export async function callOutline(gen: Generate, rows: Line[]): Promise<OutlineGroup[] | null> {
  const o = parseStrict(await gen('call_outline', sparksPrompt('call_outline', `transcript:\n${lines(rows, 400)}`)));
  if (!o || !Array.isArray(o.topics) || !o.topics.length) return null;
  const out: OutlineGroup[] = [];
  for (const t of o.topics as unknown[]) {
    const x = t as Record<string, unknown>;
    if (!x || !isStr(x.title) || !isStr(x.summary) || !Array.isArray(x.spanIds)) return null;
    out.push({ title: x.title.trim(), summary: x.summary.trim(), spanIds: (x.spanIds as unknown[]).filter(isStr) });
  }
  return out;
}

/** 6. topic_shift: null on a model failure (treated as no shift). */
export async function topicShift(gen: Generate, current: string, earlier: string[], last: Line[]): Promise<{ shift: false } | { shift: true; title: string; returning: boolean } | null> {
  const body = `current topic: ${current}\nearlier topics: ${earlier.join(', ') || '(none)'}\nlast segments:\n${lines(last.slice(-6), 400)}`;
  const o = parseStrict(await gen('topic_shift', sparksPrompt('topic_shift', body)));
  if (!o || typeof o.shift !== 'boolean') return null;
  if (!o.shift) return { shift: false };
  if (!isStr(o.title) || typeof o.returning !== 'boolean') return null;
  const title = o.title.trim();
  const n = words(title).length;
  if (n < 1 || n > 6 || title.length > 48) return null;
  return { shift: true, title, returning: o.returning };
}

/** Cheap gate before command_parse: utterances that cannot be a command never reach the model. */
const COMMAND_TRIGGER = /\b(call(ing|s)?|alert|all hands|stand down|everyone back|back to (the )?main|private(ly)?|pin|unpin|mute|remove|kick|end (the )?call|hang up|and (above|up|higher))\b/i;
export const looksLikeCommand = (utterance: string) => COMMAND_TRIGGER.test(utterance);

/**
 * 7. command_parse, then mapped onto the SDK's CommandAction (v0.1 keeps four
 * actions; pin, unpin, mute, remove, call_end and none map to null). Targets
 * resolve against the CommandContext: rank names stay rank names, member
 * names become userIds, roles and groups resolve to their ids. Anything that
 * does not resolve is null: never act on a guess.
 */
export async function commandParse(gen: Generate, utterance: string, ctx: CommandContext, speaker: { name: string; rank: string }): Promise<CallCommandIntent | null> {
  if (!looksLikeCommand(utterance)) return null;
  const body = `speaker: ${speaker.name} (${speaker.rank})\nranks: ${ctx.ranks.join(', ')}\nmembers: ${ctx.members.map((m) => m.displayName).join(', ')}\nsaid: ${clean(utterance, 400)}`;
  const o = parseStrict(await gen('command_parse', sparksPrompt('command_parse', body)));
  return o ? commandFromModel(o, ctx) : null;
}

export function commandFromModel(o: Record<string, unknown>, ctx: CommandContext): CallCommandIntent | null {
  const action = o.action;
  if (!isStr(action) || !(COMMAND_ACTIONS as readonly string[]).includes(action)) return null;
  if (action === 'targeted_call_end' || action === 'faction_alert') return { action };
  if (action !== 'targeted_call_start' && action !== 'private_call_request') return null;   // pin/unpin/mute/remove/call_end/none
  const tt = o.targetType, target = o.target;
  if (!isStr(tt) || !isStr(target)) return null;
  const t = target.trim().toLowerCase();
  const sing = (w: string) => w.replace(/ies$/, 'y').replace(/s$/, '');
  if (tt === 'rank' && action === 'targeted_call_start') {
    const rank = ctx.ranks.find((r) => r.toLowerCase() === t || sing(r.toLowerCase()) === sing(t));
    return rank ? { action, targetType: 'rank', target: rank, includeHigher: o.includeHigher === true } : null;
  }
  if (tt === 'user') {
    const exact = ctx.members.filter((m) => m.displayName.toLowerCase() === t);
    const first = ctx.members.filter((m) => m.displayName.split(/\s+/)[0].toLowerCase() === t);
    const hit = exact.length === 1 ? exact[0] : first.length === 1 ? first[0] : null;   // ambiguous names do nothing
    return hit ? { action, targetType: 'user', target: hit.userId } : null;
  }
  if (tt === 'role' && action === 'targeted_call_start') {
    const role = ctx.roles.find((r) => r.toLowerCase() === t || sing(r.toLowerCase()) === sing(t));
    return role ? { action, targetType: 'role', target: role } : null;
  }
  if (tt === 'group' && action === 'targeted_call_start') {
    const g = ctx.groups.find((x) => x.groupId === target || x.name.toLowerCase() === t || sing(x.name.toLowerCase()) === sing(t));
    return g ? { action, targetType: 'group', target: g.groupId } : null;
  }
  return null;
}

/**
 * Flat JSON schema for command_parse under mote's grammar (an optional
 * constrained mode; the trained contract is greedy and unconstrained).
 * mote admits at most 64 enum values of at most 63 bytes.
 */
export function commandSchema(ctx: CommandContext): string {
  const targets = [...new Set([...ctx.ranks, ...ctx.members.map((m) => m.displayName)])]
    .filter((v) => v.length > 0 && v.length < 64 && !/["\\]/.test(v)).slice(0, 64);
  return JSON.stringify({
    type: 'object',
    properties: {
      action: { type: 'string', enum: [...COMMAND_ACTIONS] },
      targetType: { type: 'string', enum: ['rank', 'user', 'role', 'group'] },
      target: targets.length ? { type: 'string', enum: targets } : { type: 'string', maxLength: 48 },
      includeHigher: { type: 'boolean' },
    },
    required: ['action'],
  });
}

/** 8. role_ping. Roles come back as written; matched loosely (case, spaces, dashes). */
export async function rolePing(gen: Generate, subject: string, summary: string | null, roles: { role: string; userIds: string[]; names: string[] }[]): Promise<RolePingSuggestion[] | null> {
  if (!roles.length) return [];
  const rl = [...roles].sort((a, b) => a.role.localeCompare(b.role)).map((r) => `${r.role}: ${r.names.join(', ')}`).join('; ');
  const o = parseStrict(await gen('role_ping', sparksPrompt('role_ping', `spark: ${subject}\nsummary: ${summary ?? '(none)'}\nroles: ${rl}`)));
  if (!o || !Array.isArray(o.roles) || !(o.roles as unknown[]).every(isStr)) return null;
  const key = (s: string) => s.toLowerCase().replace(/[\s\-_]/g, '');
  const out: RolePingSuggestion[] = [];
  for (const name of o.roles as string[]) {
    const r = roles.find((x) => key(x.role) === key(name));
    if (r && !out.some((p) => p.role === r.role)) {
      out.push({ role: r.role, userIds: r.userIds, confidence: 0.8, reason: `Sparks matched "${subject}" to ${r.role}` });
    }
  }
  return out;
}

// -------------------------------------------------------------- Warden

/** The fact line the Warden was trained on: "moment: x | style: y | k: v ...". */
export function wardenInput(moment: string, style: string, facts: Record<string, string | number>): string {
  const parts = [`moment: ${moment}`, `style: ${style}`];
  for (const [k, v] of Object.entries(facts)) parts.push(`${k}: ${String(v).replace(/\s*\|\s*/g, ' ')}`);
  return parts.join(' | ');
}

export const wardenPrompt = (input: string) => chatPrompt(WARDEN_SYSTEM, input);

/** Warden sampling, as evaluated (eval_voice.py). */
export const WARDEN_SAMPLING = { temperature: 0.75, topP: 0.9, repeatPenalty: 1.1, maxTokens: 70 } as const;

// ------------------------------------------------- deterministic extraction

const DECISION = /\b(let's|lets|we'll|we will|decided|agreed|going with|locked in|final answer)\b/i;
const ACTION_RE = /\b(i'll|i will|i can|i've got|i got it|will bring|need to|has to|by (monday|tuesday|wednesday|thursday|friday|saturday|sunday|tonight|tomorrow))\b/i;
const sentence = (s: string) => { const t = s.trim().replace(/\s+/g, ' '); return t ? t.charAt(0).toUpperCase() + t.slice(1).replace(/[.!?]*$/, '') : t; };

/**
 * Decisions and action items lifted verbatim from the transcript (the model
 * was not trained to produce them; quoting the speaker cannot invent facts).
 */
export function decisionsAndActions(segments: TranscriptSegment[]): { decisions: string[]; actionItems: OutlineActionItem[] } {
  const decisions = segments.filter((s) => DECISION.test(s.text)).map((s) => clean(sentence(s.text), 200)).slice(0, 3);
  const actionItems = segments.filter((s) => ACTION_RE.test(s.text) && !DECISION.test(s.text))
    .map((s) => ({ text: clean(sentence(s.text), 200), ownerUserId: s.userId })).slice(0, 4);
  return { decisions, actionItems };
}

/** Segments as `[tN] Name: text` rows with the label map back to segments. */
export function segmentRows(segments: TranscriptSegment[], members: { userId: string; displayName: string }[]) {
  const sorted = [...segments].sort((a, b) => a.startMs - b.startMs);
  const rows = sorted.map((s, i) => ({ id: `t${i + 1}`, who: nameOf(members, s.userId), text: s.text }));
  return { sorted, rows, byLabel: new Map(rows.map((r, i) => [r.id, sorted[i]])) };
}

/** Topic titles the scribe has seen, latest first, excluding the current one. */
export function earlierTitles(topics: TopicShift[], current: string | null): string[] {
  const out: string[] = [];
  for (const t of topics) if (t.title !== current && !out.includes(t.title)) out.push(t.title);
  return out;
}
