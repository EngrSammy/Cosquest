/**
 * The local store (PRIVACY §1, §3): chat history, members, the Spark mirror,
 * consent and the Warden cache, in memory and persisted through the native
 * encrypted store (AES-256-GCM files; key in the iOS Keychain or the
 * Android Keystore) per (userId, sessionId) scope. 30 days rolling, 2,000 messages per chat.
 */
import type { ChatId, ChatMember, ChatMessage, ConsentState, MessageId, Spark, SparkId, WardenLine } from '../index';
import { g } from './runtime';

export interface StoreBackend {
  get(name: string): Promise<string | null>;
  set(name: string, value: string | null): Promise<void>;
  wipe(): Promise<void>;
}

const RETENTION_MS = 30 * 24 * 3600 * 1000;
const MAX_MESSAGES_PER_CHAT = 2000;
const WARDEN_CACHE_CAP = 400;

interface ChatState {
  messages: Map<MessageId, ChatMessage>;
  members: ChatMember[];
  sparks: Map<SparkId, Spark>;
}

export class LocalStore {
  private chats = new Map<ChatId, ChatState>();
  private loading = new Map<ChatId, Promise<ChatState>>();
  private dirty = new Set<string>();
  private flushTimer: unknown = null;
  consents = new Map<string, ConsentState>();
  warden = new Map<string, WardenLine>();
  /** Chats this store has ever held, so wipe and load can find them. */
  private index = new Set<ChatId>();

  constructor(private backend: StoreBackend) {}

  async open(): Promise<void> {
    const [consents, warden, index] = await Promise.all([
      this.backend.get('consents'), this.backend.get('warden'), this.backend.get('chats'),
    ]);
    for (const [k, v] of parse<[string, ConsentState][]>(consents, [])) this.consents.set(k, v);
    for (const [k, v] of parse<[string, WardenLine][]>(warden, [])) this.warden.set(k, v);
    for (const c of parse<ChatId[]>(index, [])) this.index.add(c);
  }

  /** In-memory view (sync); empty until `chat()` has loaded it. */
  peek(chatId: ChatId): ChatState {
    let s = this.chats.get(chatId);
    if (!s) { s = { messages: new Map(), members: [], sparks: new Map() }; this.chats.set(chatId, s); }
    return s;
  }

  chatIds(): ChatId[] { return [...new Set([...this.index, ...this.chats.keys()])]; }

  /** Load a chat from disk once, merging anything already received in memory. */
  async chat(chatId: ChatId): Promise<ChatState> {
    const existing = this.loading.get(chatId);
    if (existing) return existing;
    const p = (async () => {
      const s = this.peek(chatId);
      if (!this.index.has(chatId)) return s;
      const [msgs, members, sparks] = await Promise.all([
        this.backend.get(`chat:${chatId}:messages`), this.backend.get(`chat:${chatId}:members`), this.backend.get(`chat:${chatId}:sparks`),
      ]);
      for (const m of parse<ChatMessage[]>(msgs, [])) if (!s.messages.has(m.messageId)) s.messages.set(m.messageId, m);
      if (!s.members.length) s.members = parse<ChatMember[]>(members, []);
      for (const sp of parse<Spark[]>(sparks, [])) {
        const cur = s.sparks.get(sp.sparkId);
        if (!cur || cur.version < sp.version) s.sparks.set(sp.sparkId, sp);
      }
      return s;
    })();
    this.loading.set(chatId, p);
    return p;
  }

  touch(chatId: ChatId, what: 'messages' | 'members' | 'sparks'): void {
    if (!this.index.has(chatId)) { this.index.add(chatId); this.dirty.add('chats'); }
    this.dirty.add(`chat:${chatId}:${what}`);
    this.schedule();
  }

  touchGlobal(name: 'consents' | 'warden'): void { this.dirty.add(name); this.schedule(); }

  private schedule(): void {
    if (this.flushTimer) return;
    this.flushTimer = g.setTimeout(() => { this.flushTimer = null; void this.flush(); }, 2000);
  }

  async flush(): Promise<void> {
    const names = [...this.dirty];
    this.dirty.clear();
    const now = Date.now();
    for (const name of names) {
      let value: string;
      if (name === 'consents') value = JSON.stringify([...this.consents]);
      else if (name === 'warden') {
        const all = [...this.warden];
        value = JSON.stringify(all.slice(Math.max(0, all.length - WARDEN_CACHE_CAP)));
      } else if (name === 'chats') value = JSON.stringify([...this.index]);
      else {
        const [, chatId, what] = name.split(':');
        const s = this.peek(chatId);
        if (what === 'messages') {
          const keep = [...s.messages.values()]
            .filter((m) => now - Date.parse(m.sentAt) < RETENTION_MS)
            .sort((a, b) => a.seq - b.seq)
            .slice(-MAX_MESSAGES_PER_CHAT);
          if (keep.length !== s.messages.size) s.messages = new Map(keep.map((m) => [m.messageId, m]));
          value = JSON.stringify(keep);
        } else if (what === 'members') value = JSON.stringify(s.members);
        else value = JSON.stringify([...s.sparks.values()]);
      }
      try { await this.backend.set(name, value); } catch (e) { g.console.warn('[sparks] store write failed', name, e); }
    }
  }

  /** Bound the in-memory Warden cache too (oldest out). */
  putWarden(key: string, line: WardenLine): void {
    this.warden.delete(key);
    this.warden.set(key, line);
    while (this.warden.size > WARDEN_CACHE_CAP) this.warden.delete(this.warden.keys().next().value as string);
    this.touchGlobal('warden');
  }

  async wipe(): Promise<void> {
    if (this.flushTimer) { g.clearTimeout(this.flushTimer); this.flushTimer = null; }
    this.dirty.clear();
    this.chats.clear(); this.loading.clear(); this.index.clear(); this.consents.clear(); this.warden.clear();
    await this.backend.wipe();
  }
}

function parse<T>(s: string | null, fallback: T): T {
  if (!s) return fallback;
  try { return JSON.parse(s) as T; } catch { return fallback; }
}
