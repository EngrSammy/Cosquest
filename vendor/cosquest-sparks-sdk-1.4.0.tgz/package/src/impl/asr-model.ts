/**
 * Which speech model a phone runs (SDK 1.4). Pure functions, tested in test/asr-model.mts.
 *
 * The manifest's `asr` entry is Moonshine Base (what SDKs before 1.4 read) and, from 1.4, a
 * `streaming` list of Moonshine Streaming models. Small is the default on every phone. Medium is
 * opt-in (`SparksConfig.speechModel: 'medium'`) and then used only on a phone that can run it
 * during a call: at least MEDIUM_MIN_RAM_BYTES of RAM (with the usual 0.85 tolerance: phones
 * report less than their marketed RAM) and MEDIUM_MIN_CORES cores. The manifest can raise or lower
 * those floors per model (`min_ram_bytes`, `min_cores`). Without a `streaming` list the phone
 * runs Base. A native build before 10400 has no streaming runner; it is also the one that does
 * not report `cpuCores`, so a phone without `cpuCores` gets Base only.
 *
 * Why these floors (docs/PERFORMANCE.md §1c): on an x86 proxy with 2 cores, medium costs about
 * twice small's decode time per utterance; a phone's big cores are 2 to 3 times slower than that
 * proxy, so medium keeps up with speech only on recent high-end phones. 8 GB and 6 cores is the
 * iPhone 15 Pro and every iPhone 16 / 17 (A17 Pro and newer), and Android flagships; 6 GB iPhones
 * (12 Pro to 14) and mid-range Android stay on small.
 */
import type { AsrManifest, AsrStreamingModel, ManifestFile } from '../index';

const GiB = 2 ** 30;
export const MEDIUM_MIN_RAM_BYTES = 8 * GiB;
export const MEDIUM_MIN_CORES = 6;
/**
 * Download budget per streaming model (all its files, the shared VAD aside): an entry over it is
 * skipped, so a manifest mistake cannot push a far larger download onto every phone. The
 * releases are 142.3 MB (small) and 269.1 MB (medium); docs/UPGRADE-1.4.md.
 */
export const SPEECH_MAX_BYTES = { small: 160e6, medium: 300e6 } as const;
/** The same tolerance as the tier gate (SPK_RAM_TOLERANCE). */
export const RAM_TOLERANCE = 0.85;

export type SpeechModelSize = 'base' | 'small' | 'medium';

export interface SpeechDevice {
  ramBytes: number;
  /** Absent: a native build before 10400 (no streaming runner). <= 0: unknown core count. */
  cpuCores?: number;
}

/** True when this phone may run medium (the opt-in is checked by the caller). */
export function canRunMedium(dev: SpeechDevice, entry?: Pick<AsrStreamingModel, 'min_ram_bytes' | 'min_cores'>): boolean {
  const ram = entry?.min_ram_bytes ?? MEDIUM_MIN_RAM_BYTES;
  const cores = entry?.min_cores ?? MEDIUM_MIN_CORES;
  if (!dev.cpuCores || dev.cpuCores <= 0) return false;
  return dev.ramBytes >= RAM_TOLERANCE * ram && dev.cpuCores >= cores;
}

/**
 * The speech models to try, best first: the first whose files download and verify is used; if
 * every download fails the phone keeps whatever verified model it already has.
 */
export function speechCandidates(asr: AsrManifest | undefined, dev: SpeechDevice, want: 'small' | 'medium' = 'small'): SpeechModelSize[] {
  if (!asr) return [];
  const streamingRunner = typeof dev.cpuCores === 'number';
  const listed = new Set((asr.streaming ?? []).filter((s) => s?.engine === 'moonshine-streaming' && streamingComplete(s) && withinBudget(s)).map((s) => s.size));
  const out: SpeechModelSize[] = [];
  const medium = (asr.streaming ?? []).find((s) => s?.size === 'medium');
  if (streamingRunner && want === 'medium' && listed.has('medium') && canRunMedium(dev, medium)) out.push('medium');
  if (streamingRunner && listed.has('small')) out.push('small');
  if (asr.engine === 'moonshine-base' && asr.encoder && asr.decoder && asr.tokenizer && asr.vad) out.push('base');
  return out;
}

function withinBudget(s: AsrStreamingModel): boolean {
  const max = SPEECH_MAX_BYTES[s.size as 'small' | 'medium'];
  if (!max) return false;
  const files = [s.frontend, s.frontend_weights, s.encoder, s.adapter, s.cross_kv, s.decoder, s.tokenizer, s.config];   // decoder_alt replaces decoder
  return files.reduce((n, f) => n + (f?.bytes ?? 0), 0) <= max;
}

function streamingComplete(s: AsrStreamingModel): boolean {
  return !!(s.frontend && s.encoder && s.adapter && s.cross_kv && s.decoder && s.tokenizer && s.config);
}

/** What the native transcriber is given: paths in this order, '' for an absent optional file. */
export const ASR_FILE_KEYS = ['encoder', 'decoder', 'tokenizer', 'vad', 'frontend', 'frontendWeights', 'adapter', 'crossKv', 'config'] as const;
export type AsrFileKey = (typeof ASR_FILE_KEYS)[number];

/** One chosen speech model: its files by native key (Base sets the first four). */
export interface SpeechModelFiles {
  size: SpeechModelSize;
  files: Partial<Record<AsrFileKey, ManifestFile>>;
  /** The manifest's decoder_alt: tried when files.decoder fails to download or verify. */
  decoderAlt?: ManifestFile;
}

export function speechFiles(asr: AsrManifest, size: SpeechModelSize): SpeechModelFiles | null {
  if (size === 'base') {
    if (!asr.encoder || !asr.decoder || !asr.tokenizer || !asr.vad) return null;
    return { size, files: { encoder: asr.encoder, decoder: asr.decoder, tokenizer: asr.tokenizer, vad: asr.vad } };
  }
  const s = (asr.streaming ?? []).find((x) => x?.size === size && x.engine === 'moonshine-streaming');
  if (!s || !streamingComplete(s) || !asr.vad) return null;
  const files: SpeechModelFiles['files'] = {
    encoder: s.encoder, decoder: s.decoder, tokenizer: s.tokenizer, vad: asr.vad,
    frontend: s.frontend, adapter: s.adapter, crossKv: s.cross_kv, config: s.config,
  };
  if (s.frontend_weights) files.frontendWeights = s.frontend_weights;
  return s.decoder_alt ? { size, files, decoderAlt: s.decoder_alt } : { size, files };
}

/** Every sha256 the chosen model needs (to keep on disk). */
export function speechShas(m: SpeechModelFiles | null): string[] {
  return m ? ASR_FILE_KEYS.flatMap((k) => (m.files[k] ? [m.files[k]!.sha256] : [])) : [];
}

/** Total download size of the files not yet on disk. */
export function speechBytes(m: SpeechModelFiles): number {
  return ASR_FILE_KEYS.reduce((n, k) => n + (m.files[k]?.bytes ?? 0), 0);
}
