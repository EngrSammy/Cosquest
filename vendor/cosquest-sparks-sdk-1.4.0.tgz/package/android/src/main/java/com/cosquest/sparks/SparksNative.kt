package com.cosquest.sparks

import android.util.Log

/**
 * The JNI surface of libcosquestsparks.so (src/main/cpp/sparks_jni.cpp): the
 * mote engine under the C scheduler, the C text utilities and the
 * transcriber. Strings go in and out as UTF-8 byte arrays (see the bridge).
 * Internal: hosts use [SparksAudioSink]; JS uses the TurboModule.
 */
internal object SparksNative {
  /** False when the library failed to load (an ABI the app did not ship); the module then reports tier none. */
  val loaded: Boolean = try {
    System.loadLibrary("cosquestsparks")
    true
  } catch (e: Throwable) {
    Log.w("Sparks", "libcosquestsparks.so did not load: ${e.message}")
    false
  }

  /** Called on engine threads. */
  interface EngineListener {
    fun onPiece(jsId: Long, piece: ByteArray)
    /** stats: tokensOut, tokensInEstimate, firstTokenMs, wallMs, runMs, preemptions. */
    fun onDone(jsId: Long, status: Int, message: ByteArray?, text: ByteArray?, stats: DoubleArray, vec: FloatArray?)
    /** running, queuedWarden, queuedInteractive, queuedBackground, pausedMask, wardenLoaded, sparksLoaded, modelAttached. */
    fun onEngineState(state: IntArray)
    /** Memory budget for opening handle `which`. */
    fun memoryOK(which: Int): Boolean
  }

  /** Called on the transcriber's worker thread (and inside asrStop for the last final). */
  interface AsrListener {
    fun onLine(lineId: Long, text: ByteArray, startS: Double, durationS: Double, isFinal: Boolean, confidence: Double)
  }

  // SPK_* from sparks_core.h
  const val SPK_OK = 0
  const val SPK_E_PAUSED = -10
  const val SPK_E_CANCELLED = -11
  const val SPK_E_BUSY = -12
  const val SPK_E_ENGINE = -13
  const val SPK_E_MEMORY = -14
  const val SPK_E_GRAMMAR = -15
  const val SPK_E_NOT_READY = -16
  const val SPK_E_INVALID = -17
  const val SPK_H_COUNT = 2

  /** SPK_E_* to the JS SparksErrorCode (as SPKCode in SparksModule.mm). */
  fun code(status: Int): String = when (status) {
    SPK_E_PAUSED -> "E_PAUSED"
    SPK_E_CANCELLED -> "E_CANCELLED"
    SPK_E_BUSY -> "E_BUSY"
    SPK_E_MEMORY -> "E_INSUFFICIENT_MEMORY"
    SPK_E_GRAMMAR -> "E_GRAMMAR_UNSTARTED"
    SPK_E_NOT_READY -> "E_MODEL_NOT_READY"
    SPK_E_INVALID -> "E_INVALID_ARGUMENT"
    else -> "E_ENGINE"
  }

  fun utf8(s: String): ByteArray = s.toByteArray(Charsets.UTF_8)
  fun str(b: ByteArray?): String = if (b == null) "" else String(b, Charsets.UTF_8)

  // device
  @JvmStatic external fun abi(): String
  @JvmStatic external fun armDotProd(): Boolean
  /** {kernel (0 C, 1 NEON, 2 SDOT), matmul threads, native build}. */
  @JvmStatic external fun cpuInfo(): IntArray?
  @JvmStatic external fun asrAvailable(): Boolean

  // text utilities
  @JvmStatic external fun jsonRepair(raw: ByteArray): ByteArray?
  @JvmStatic external fun wardenClean(raw: ByteArray): ByteArray
  @JvmStatic external fun wardenCheck(text: ByteArray, moment: ByteArray, input: ByteArray, place: ByteArray?, maxWords: Int): ByteArray?

  // engine
  @JvmStatic external fun engineNew(listener: EngineListener): Long
  @JvmStatic external fun engineFree(h: Long)
  @JvmStatic external fun engineLoad(h: Long, modelPath: ByteArray, tokenizerPath: ByteArray, pausedMask: Int, preloadSparks: Boolean, info: IntArray): Int
  @JvmStatic external fun engineLastError(h: Long): ByteArray
  @JvmStatic external fun engineDetach(h: Long)
  @JvmStatic external fun engineUnload(h: Long, which: Int)
  @JvmStatic external fun engineAttached(h: Long): Boolean
  @JvmStatic external fun engineSubmit(
    h: Long, jsId: Long, priority: Int, prompt: ByteArray, schema: ByteArray?, stop: ByteArray?,
    temperature: Float, topP: Float, repeatPenalty: Float, maxTokens: Int, seed: Long, stream: Boolean, embed: Boolean,
  ): Long
  @JvmStatic external fun engineCancel(h: Long, id: Long)
  @JvmStatic external fun engineSetPaused(h: Long, mask: Int)
  @JvmStatic external fun engineState(h: Long): IntArray

  // transcription
  /**
   * Paths in UTF-8. Moonshine Base: the first four, the rest empty. Moonshine Streaming (native
   * 10400): all; an empty frontendWeights means the weights are inside the frontend.
   */
  @JvmStatic external fun asrCreate(
    encoder: ByteArray, decoder: ByteArray, tokenizer: ByteArray, vad: ByteArray,
    frontend: ByteArray, frontendWeights: ByteArray, adapter: ByteArray, crossKv: ByteArray, config: ByteArray,
  ): Long
  @JvmStatic external fun asrStart(h: Long, partialMs: Int, listener: AsrListener): Int
  @JvmStatic external fun asrLastError(h: Long): ByteArray
  @JvmStatic external fun asrPushI16(h: Long, samples: ShortArray, count: Int, sampleRate: Int)
  @JvmStatic external fun asrPushF32(h: Long, samples: FloatArray, count: Int, sampleRate: Int)
  @JvmStatic external fun asrPushBase64(h: Long, base64: ByteArray, startMs: Double)
  @JvmStatic external fun asrSetMuted(h: Long, muted: Boolean)
  /** Phrases (UTF-8) the transcriber leans towards; returns how many were kept, or <0. */
  @JvmStatic external fun asrSetVocabulary(h: Long, phrases: Array<ByteArray>): Int
  @JvmStatic external fun asrStop(h: Long)
  @JvmStatic external fun asrFree(h: Long)
}
