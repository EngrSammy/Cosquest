/* sparks_moonshine_streaming.c: Moonshine Streaming (small, medium; English,
 * int8, MIT) and Silero VAD over the ONNX Runtime C API. The spk_asr_engine
 * behind sparks_asr.c from SDK 1.4 (sparks_moonshine.c runs Moonshine Base).
 *
 * Model files are Moonshine AI's official ORT-format streaming releases
 * (download.moonshine.ai/model/{small,medium}-streaming-en/quantized_26_08_21):
 * frontend.model.ort + frontend.weights.ort, encoder.ort, adapter.ort,
 * cross_kv.ort, decoder_kv.ort, tokenizer.bin, streaming_config.json. They
 * are downloaded through the model manifest, never bundled.
 *
 * The model, per utterance:
 *   audio -> frontend (stateful: 80-sample frames, two strided convolutions;
 *            one feature per 20 ms)
 *         -> encoder over a sliding window (16 frames of left context per
 *            layer); a frame is final once 16 later frames exist (lookahead)
 *         -> adapter (with the frame's position) -> decoder memory
 *         -> cross_kv (the decoder's cross-attention K/V over the memory)
 *         -> decoder_kv, greedy, with its self-attention cache.
 * This is a port of Moonshine's MoonshineStreamingModel (core/moonshine-
 * streaming-model.cpp, MIT) in C, with the Sparks pipeline's interface.
 *
 * Streaming inside the one-shot interface: sparks_asr.c hands transcribe the
 * utterance from its start every time (partials, then the final). When the
 * samples extend the previous call's, only the new ones go through the
 * frontend and the encoder; frames still inside the lookahead are encoded
 * provisionally for this call only. The previous call's tokens are then a
 * draft: one decoder pass checks them all, the agreed prefix is kept (its
 * cache trimmed to it) and decoding goes on from the first disagreement, so a
 * partial costs a few decoder steps instead of a whole decode. The final
 * ends at end of speech + 300 ms, before the last partial's end: it rolls the
 * stream back (frames whose lookahead lies inside the shorter audio are kept,
 * the tail is encoded again) and keeps the draft. A new utterance starts the
 * frontend and encoder again. Greedy decoding gives the same tokens either
 * way (up to float rounding on near ties; the int8 decoder quantizes its
 * activations per call, so a batched draft check and step-by-step decoding
 * can differ in the last digits).
 *
 * Vocabulary biasing, name snapping, the loop guard and confidence are the
 * same as Base's (sparks_vocab.c): the tokenizer is the same file. Two guards
 * more, for these models' own failure modes (measured on Nigerian
 * conversations and Pidgin, ACCENT.md "1.4.0"): a block of 8+ tokens said
 * twice in a row is cut to one copy (language-model takeover: "I am very
 * happy to be able to speak to you today. I am very happy ..."), and a line
 * that opens with a list marker ("1.", often followed by end of text for a
 * whole sentence) is decoded again without that first token, which stays
 * banned for the rest of the utterance so partials and the final agree.
 *
 * Memory: the .ort files are mmap'd and used in place, as for Base. The
 * frontend's weights are a separate file whose session outputs them; they are
 * dequantized once at open (float32: 31 MB small, 47 MB medium) and are the
 * runner's main dirty memory, with the decoder caches (a few MB). */
#define _POSIX_C_SOURCE 200809L
#include "sparks_core.h"

#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* ------------------------------------------------ config and helpers (no ORT) */
static const char *json_value(const char *json, const char *key) {
    char pat[64];
    snprintf(pat, sizeof pat, "\"%s\"", key);
    const char *p = strstr(json, pat);
    if (!p) return NULL;
    p += strlen(pat);
    while (isspace((unsigned char)*p)) p++;
    if (*p != ':') return NULL;
    p++;
    while (isspace((unsigned char)*p)) p++;
    return p;
}

static int json_int(const char *json, const char *key, int *out) {
    const char *p = json_value(json, key);
    if (!p) return -1;
    char *end = NULL;
    long v = strtol(p, &end, 10);
    if (end == p || v <= 0 || v > 1 << 24) return -1;
    *out = (int)v;
    return 0;
}

void spk_ms_bias_weights(const spk_ms_stream_config *c, float *first, float *next, float *first_short) {
    int small = c && c->decoder_dim > 0 && c->decoder_dim < 640;
    *first = small ? SPK_MS_SMALL_BIAS_FIRST : SPK_BIAS_FIRST;
    *next = small ? SPK_MS_SMALL_BIAS_NEXT : SPK_BIAS_NEXT;
    *first_short = small ? SPK_MS_SMALL_BIAS_FIRST_SHORT : SPK_BIAS_FIRST_SHORT;
}

int spk_ms_stream_config_parse(const char *json, spk_ms_stream_config *c) {
    if (!json || !c) return -1;
    memset(c, 0, sizeof *c);
    struct { const char *k; int *v; } f[] = {
        { "encoder_dim", &c->encoder_dim }, { "decoder_dim", &c->decoder_dim }, { "depth", &c->depth },
        { "nheads", &c->nheads }, { "head_dim", &c->head_dim }, { "vocab_size", &c->vocab_size },
        { "bos_id", &c->bos_id }, { "eos_id", &c->eos_id }, { "frame_len", &c->frame_len },
        { "total_lookahead", &c->total_lookahead }, { "d_model_frontend", &c->d_model_frontend },
        { "c1", &c->c1 }, { "c2", &c->c2 },
    };
    for (size_t i = 0; i < sizeof f / sizeof f[0]; i++)
        if (json_int(json, f[i].k, f[i].v) != 0) return -1;
    c->sample_buffer = c->frame_len - 1;
    const char *sb = json_value(json, "sample_buffer");   /* [1, 79] */
    if (sb && *sb == '[') {
        const char *comma = strchr(sb, ',');
        const char *close = strchr(sb, ']');
        if (comma && close && comma < close) {
            long v = strtol(comma + 1, NULL, 10);
            if (v > 0 && v < 1 << 16) c->sample_buffer = (int)v;
        }
    }
    return c->sample_buffer > 0 ? 0 : -1;
}

void spk_ms_kv_prefix(const float *src, int blocks, int len, int keep, int head_dim, float *dst) {
    size_t row = (size_t)keep * (size_t)head_dim;
    for (int b = 0; b < blocks; b++)
        memcpy(dst + (size_t)b * row, src + (size_t)b * (size_t)len * (size_t)head_dim, sizeof(float) * row);
}

int spk_ms_draft_accept(const int64_t *draft, int n, const int64_t *pred) {
    int a = 0;
    while (a < n && pred[a] == draft[a]) a++;
    return a;
}

int spk_ms_list_marker(const char *text) {
    if (!text) return 0;
    size_t d = 0;
    while (text[d] >= '0' && text[d] <= '9') d++;
    return d > 0 && text[d] == '.' && (text[d + 1] == '\0' || text[d + 1] == ' ');
}

int spk_ms_repeat_cut(const int64_t *toks, int n, int min_len) {
    if (!toks || min_len < 1) return 0;
    for (int len = min_len; 2 * len <= n; len++)
        if (memcmp(toks + n - 2 * len, toks + n - len, sizeof(int64_t) * (size_t)len) == 0) return n - len;
    return 0;
}

#if defined(SPARKS_WITH_MOONSHINE)

#include "sparks_moonshine_internal.h"

#include <math.h>
#include <sys/mman.h>

#define MS_TOKENS_PER_SECOND 6.5
#define MS_THREADS 2            /* SPK_CALL_THREADS: a call stays smooth */
#define MS_CHUNK   1280         /* frontend input granularity, samples (80 ms) */
#define MS_FEAT    320          /* samples per frontend feature (20 ms): MS_CHUNK gives 4 */
#define MS_REPEAT  8            /* spk_ms_repeat_cut: a block this long said twice is a takeover */

enum { S_FRONTEND, S_ENCODER, S_ADAPTER, S_CROSS, S_DECODER, S_COUNT };
enum { P_FRONTEND, P_FWEIGHTS, P_ENCODER, P_ADAPTER, P_CROSS, P_DECODER, P_TOKENIZER, P_CONFIG, P_VAD, P_COUNT };

typedef struct {
    char    *name;
    float   *data;
    int64_t  shape[8];
    size_t   rank, count;
    OrtValue *value;            /* over data */
} fweight;

typedef struct {
    char *path[P_COUNT];

    const OrtApi *api;
    OrtEnv *env;
    OrtMemoryInfo *mem;
    OrtSession *s[S_COUNT];
    void  *map[S_COUNT];
    size_t map_len[S_COUNT];
    spk_ms_stream_config cfg;
    fweight *fw;                /* frontend weights (split pair) */
    int      n_fw;

    /* tokenizer (sparks_vocab.c) and vocabulary biasing */
    spk_vocab *vocab;
    spk_bias  *bias;
    char     **phrases;
    int        n_phrases;
    float      conf;

    spk_silero vad;

    /* the utterance being transcribed */
    float   *seen;              /* samples fed to the frontend */
    int      seen_n, seen_cap;
    float   *sbuf;              /* frontend state */
    int64_t  sbuf_len, frame_count;
    float   *conv1, *conv2;
    float   *feat;              /* frontend features [feat_n][encoder_dim] */
    int      feat_n, feat_cap;
    int      enc_done;          /* features whose encoder output is final */
    int64_t  pos;               /* adapter position of the next final frame */
    float   *memory;            /* [mem_n final + prov_n provisional][decoder_dim] */
    int      mem_n, mem_cap, prov_n, prov_feat;
    int64_t *draft;             /* the previous call's tokens */
    int      draft_n, draft_cap;
    int      fe_stale;          /* rolled back: the frontend state is past seen_n */
    int64_t  ban0;              /* a list-marker first token, banned for this utterance (-1: none) */
    int      no_rollback;       /* features stopped being one per MS_FEAT samples */
} mss;

static char *dupstr(const char *s) {
    size_t n = strlen(s) + 1;
    char *d = malloc(n);
    if (d) memcpy(d, s, n);
    return d;
}

/* Grow *p to hold need elements of size elem. 0, or -1. */
static int grow(void **p, int *cap, int need, size_t elem) {
    if (need <= *cap) return 0;
    int c = *cap ? *cap : 256;
    while (c < need) c *= 2;
    void *q = realloc(*p, (size_t)c * elem);
    if (!q) return -1;
    *p = q;
    *cap = c;
    return 0;
}

static char *read_text(const char *path) {
    FILE *f = fopen(path, "rb");
    if (!f) return NULL;
    char *buf = malloc(65536);
    size_t n = buf ? fread(buf, 1, 65535, f) : 0;
    fclose(f);
    if (buf) buf[n] = '\0';
    return buf;
}

#define TRY(expr, what) do { if (spk_ms_failed(m->api, (expr), err, err_len, (what))) goto fail; } while (0)

static void stream_reset(mss *m) {
    m->seen_n = 0;
    if (m->sbuf) memset(m->sbuf, 0, sizeof(float) * (size_t)m->cfg.sample_buffer);
    if (m->conv1) memset(m->conv1, 0, sizeof(float) * (size_t)m->cfg.d_model_frontend * 4);
    if (m->conv2) memset(m->conv2, 0, sizeof(float) * (size_t)m->cfg.c1 * 4);
    m->sbuf_len = m->frame_count = 0;
    m->feat_n = m->enc_done = 0;
    m->pos = 0;
    m->mem_n = m->prov_n = 0;
    m->prov_feat = -1;
    m->fe_stale = 0;
}

/* Back to the first `usable` samples of this utterance (the final ends before
 * the last partial did). The frontend is causal and gives one feature per
 * MS_FEAT samples, and a frame's encoder output depends on features up to
 * total_lookahead after it, so frames whose lookahead lies inside the shorter
 * audio stay exactly as a fresh run would make them; the rest is encoded
 * again by encode(). The frontend state is past that point now: extending
 * this utterance again starts over (fe_stale). 0, or -1 to start over now. */
static int stream_rollback(mss *m, int usable) {
    if (m->no_rollback || usable % MS_FEAT != 0) return -1;
    int nf = usable / MS_FEAT;
    if (nf > m->feat_n) return -1;
    int keep = nf - m->cfg.total_lookahead;
    if (keep < 0) keep = 0;
    if (keep < m->enc_done) {
        m->enc_done = keep;
        m->mem_n = keep;
        m->pos = keep;
    }
    m->feat_n = nf;
    m->seen_n = usable;
    m->prov_n = 0;
    m->prov_feat = -1;
    m->fe_stale = 1;
    return 0;
}

/* ---------------------------------------------------------------- loading */
static int load_frontend_weights(mss *m, char *err, size_t err_len) {
    if (!m->path[P_FWEIGHTS]) return 0;   /* weights inside the frontend */
    OrtSession *ws = NULL;
    void *map = NULL;
    size_t map_len = 0;
    OrtValue **out = NULL;
    char **names = NULL;
    size_t n = 0;
    int rc = -1;
    OrtAllocator *al = NULL;
    if (spk_ms_open_mapped(m->api, m->env, m->path[P_FWEIGHTS], 1, &ws, &map, &map_len, "frontend weights", err, err_len) != 0) goto done;
    if (spk_ms_failed(m->api, m->api->GetAllocatorWithDefaultOptions(&al), err, err_len, "allocator")) goto done;
    if (spk_ms_failed(m->api, m->api->SessionGetOutputCount(ws, &n), err, err_len, "frontend weights")) goto done;
    if (n == 0 || n > 64) { snprintf(err, err_len, "frontend weights: %zu outputs", n); goto done; }
    names = calloc(n, sizeof(char *));
    out = calloc(n, sizeof(OrtValue *));
    m->fw = calloc(n, sizeof(fweight));
    if (!names || !out || !m->fw) goto done;
    for (size_t i = 0; i < n; i++) {
        char *nm = NULL;
        if (spk_ms_failed(m->api, m->api->SessionGetOutputName(ws, i, al, &nm), err, err_len, "frontend weights")) goto done;
        names[i] = dupstr(nm);
        OrtStatus *fs = m->api->AllocatorFree(al, nm);
        if (fs) m->api->ReleaseStatus(fs);
        if (!names[i]) goto done;
    }
    if (spk_ms_failed(m->api, m->api->Run(ws, NULL, NULL, NULL, 0, (const char *const *)names, n, out), err, err_len, "frontend weights")) goto done;
    for (size_t i = 0; i < n; i++) {
        fweight *w = &m->fw[i];
        OrtTensorTypeAndShapeInfo *info = NULL;
        ONNXTensorElementDataType t = ONNX_TENSOR_ELEMENT_DATA_TYPE_UNDEFINED;
        float *src = NULL;
        OrtStatus *st = m->api->GetTensorTypeAndShape(out[i], &info);
        if (!st) st = m->api->GetTensorElementType(info, &t);
        if (!st) st = m->api->GetDimensionsCount(info, &w->rank);
        if (!st && w->rank <= 8) st = m->api->GetDimensions(info, w->shape, w->rank);
        if (info) m->api->ReleaseTensorTypeAndShapeInfo(info);
        if (!st) st = m->api->GetTensorMutableData(out[i], (void **)&src);
        if (spk_ms_failed(m->api, st, err, err_len, "frontend weights")) goto done;
        if (t != ONNX_TENSOR_ELEMENT_DATA_TYPE_FLOAT || w->rank > 8 || !src) { snprintf(err, err_len, "frontend weight %s is not float", names[i]); goto done; }
        w->count = 1;
        for (size_t d = 0; d < w->rank; d++) w->count *= (size_t)w->shape[d];
        w->data = malloc(sizeof(float) * (w->count ? w->count : 1));
        w->name = names[i];
        names[i] = NULL;
        m->n_fw++;
        if (!w->data) goto done;
        memcpy(w->data, src, sizeof(float) * w->count);
        if (spk_ms_failed(m->api, m->api->CreateTensorWithDataAsOrtValue(m->mem, w->data, sizeof(float) * w->count, w->shape, w->rank,
                          ONNX_TENSOR_ELEMENT_DATA_TYPE_FLOAT, &w->value), err, err_len, "frontend weights")) goto done;
    }
    rc = 0;
done:
    if (out) for (size_t i = 0; i < n; i++) if (out[i]) m->api->ReleaseValue(out[i]);
    if (names) for (size_t i = 0; i < n; i++) free(names[i]);
    free(names);
    free(out);
    if (ws) m->api->ReleaseSession(ws);
    if (map) munmap(map, map_len);
    return rc;
}

static void free_frontend_weights(mss *m) {
    for (int i = 0; i < m->n_fw; i++) {
        if (m->fw[i].value) m->api->ReleaseValue(m->fw[i].value);
        free(m->fw[i].data);
        free(m->fw[i].name);
    }
    free(m->fw);
    m->fw = NULL;
    m->n_fw = 0;
}

static void ms_close(void *ctx) {
    mss *m = ctx;
    if (!m->api) return;
    free_frontend_weights(m);
    for (int i = 0; i < S_COUNT; i++) {
        if (m->s[i]) m->api->ReleaseSession(m->s[i]);
        m->s[i] = NULL;
        if (m->map[i]) munmap(m->map[i], m->map_len[i]);
        m->map[i] = NULL;
        m->map_len[i] = 0;
    }
    spk_silero_close(&m->vad);
    if (m->mem) m->api->ReleaseMemoryInfo(m->mem);
    if (m->env) m->api->ReleaseEnv(m->env);
    m->mem = NULL;
    m->env = NULL;
    spk_vocab_free(m->vocab);
    m->vocab = NULL;
    if (m->bias) spk_bias_set(m->bias, NULL, NULL, 0);
    free(m->seen); free(m->sbuf); free(m->conv1); free(m->conv2); free(m->feat); free(m->memory); free(m->draft);
    m->seen = m->sbuf = m->conv1 = m->conv2 = m->feat = m->memory = NULL;
    m->draft = NULL;
    m->seen_cap = m->feat_cap = m->mem_cap = m->draft_cap = 0;
    m->seen_n = m->feat_n = m->mem_n = m->prov_n = m->draft_n = 0;
}

static int ms_open(void *ctx, char *err, size_t err_len) {
    mss *m = ctx;
    m->api = OrtGetApiBase()->GetApi(ORT_API_VERSION);
    if (!m->api) { snprintf(err, err_len, "ONNX Runtime API %d unavailable", ORT_API_VERSION); return -1; }
    char *json = read_text(m->path[P_CONFIG]);
    int bad = !json || spk_ms_stream_config_parse(json, &m->cfg) != 0;
    free(json);
    if (bad) { snprintf(err, err_len, "cannot read streaming_config.json"); m->api = NULL; return -1; }
    { float f, n, fs; spk_ms_bias_weights(&m->cfg, &f, &n, &fs); spk_bias_set_weights(m->bias, f, n, fs); }
    TRY(m->api->CreateEnv(ORT_LOGGING_LEVEL_ERROR, "sparks-asr", &m->env), "env");
    TRY(m->api->CreateCpuMemoryInfo(OrtDeviceAllocator, OrtMemTypeDefault, &m->mem), "memory info");
    static const int which[S_COUNT] = { P_FRONTEND, P_ENCODER, P_ADAPTER, P_CROSS, P_DECODER };
    static const char *what[S_COUNT] = { "frontend", "encoder", "adapter", "cross_kv", "decoder" };
    for (int i = 0; i < S_COUNT; i++)
        if (spk_ms_open_mapped(m->api, m->env, m->path[which[i]], MS_THREADS, &m->s[i], &m->map[i], &m->map_len[i], what[i], err, err_len) != 0) goto fail;
    if (load_frontend_weights(m, err, err_len) != 0) goto fail;
    m->vocab = spk_vocab_load(m->path[P_TOKENIZER]);
    if (!m->vocab) { snprintf(err, err_len, "cannot read tokenizer"); goto fail; }
    if (m->bias && m->n_phrases > 0) spk_bias_set(m->bias, m->vocab, (const char *const *)m->phrases, m->n_phrases);
    if (spk_silero_open(&m->vad, m->api, m->env, m->mem, m->path[P_VAD], err, err_len) != 0) goto fail;
    m->sbuf = calloc((size_t)m->cfg.sample_buffer, sizeof(float));
    m->conv1 = calloc((size_t)m->cfg.d_model_frontend * 4, sizeof(float));
    m->conv2 = calloc((size_t)m->cfg.c1 * 4, sizeof(float));
    if (!m->sbuf || !m->conv1 || !m->conv2) { snprintf(err, err_len, "out of memory"); goto fail; }
    stream_reset(m);
    m->draft_n = 0;
    m->ban0 = -1;
    return 0;
fail:
    ms_close(m);
    return -1;
}

static void ms_vad_reset(void *ctx) { spk_silero_reset(&((mss *)ctx)->vad); }
static float ms_vad(void *ctx, const float *frame) { return spk_silero_prob(&((mss *)ctx)->vad, frame); }

/* ------------------------------------------------------------- the model */
static void release_all(const OrtApi *api, OrtValue **v, int n) {
    for (int i = 0; i < n; i++) if (v[i]) { api->ReleaseValue(v[i]); v[i] = NULL; }
}

static int dims_of(const OrtApi *api, OrtValue *v, int64_t *d, size_t want) {
    OrtTensorTypeAndShapeInfo *info = NULL;
    size_t nd = 0;
    OrtStatus *st = api->GetTensorTypeAndShape(v, &info);
    if (!st) st = api->GetDimensionsCount(info, &nd);
    if (!st && nd == want) st = api->GetDimensions(info, d, nd);
    if (info) api->ReleaseTensorTypeAndShapeInfo(info);
    if (st) { api->ReleaseStatus(st); return -1; }
    return nd == want ? 0 : -1;
}

/* samples -> features (appended), frontend state carried */
static int frontend(mss *m, const float *pcm, int n) {
    const OrtApi *api = m->api;
    const spk_ms_stream_config *c = &m->cfg;
    int nin = 6 + m->n_fw, rc = -1;
    OrtValue **in = calloc((size_t)nin, sizeof(OrtValue *));
    const char **names = calloc((size_t)nin, sizeof(char *));
    OrtValue *out[6] = { NULL };
    if (!in || !names) goto done;
    int64_t a_dims[2] = { 1, n }, sb_dims[2] = { 1, c->sample_buffer }, one[1] = { 1 };
    int64_t c1_dims[3] = { 1, c->d_model_frontend, 4 }, c2_dims[3] = { 1, c->c1, 4 };
    OrtStatus *st = api->CreateTensorWithDataAsOrtValue(m->mem, (void *)pcm, sizeof(float) * (size_t)n, a_dims, 2, ONNX_TENSOR_ELEMENT_DATA_TYPE_FLOAT, &in[0]);
    if (!st) st = api->CreateTensorWithDataAsOrtValue(m->mem, m->sbuf, sizeof(float) * (size_t)c->sample_buffer, sb_dims, 2, ONNX_TENSOR_ELEMENT_DATA_TYPE_FLOAT, &in[1]);
    if (!st) st = api->CreateTensorWithDataAsOrtValue(m->mem, &m->sbuf_len, sizeof(int64_t), one, 1, ONNX_TENSOR_ELEMENT_DATA_TYPE_INT64, &in[2]);
    if (!st) st = api->CreateTensorWithDataAsOrtValue(m->mem, m->conv1, sizeof(float) * (size_t)c->d_model_frontend * 4, c1_dims, 3, ONNX_TENSOR_ELEMENT_DATA_TYPE_FLOAT, &in[3]);
    if (!st) st = api->CreateTensorWithDataAsOrtValue(m->mem, m->conv2, sizeof(float) * (size_t)c->c1 * 4, c2_dims, 3, ONNX_TENSOR_ELEMENT_DATA_TYPE_FLOAT, &in[4]);
    if (!st) st = api->CreateTensorWithDataAsOrtValue(m->mem, &m->frame_count, sizeof(int64_t), one, 1, ONNX_TENSOR_ELEMENT_DATA_TYPE_INT64, &in[5]);
    if (st) { api->ReleaseStatus(st); goto done; }
    static const char *base_in[6] = { "audio_chunk", "sample_buffer", "sample_len", "conv1_buffer", "conv2_buffer", "frame_count" };
    static const char *out_names[6] = { "features", "sample_buffer_out", "sample_len_out", "conv1_buffer_out", "conv2_buffer_out", "frame_count_out" };
    for (int i = 0; i < 6; i++) names[i] = base_in[i];
    for (int i = 0; i < m->n_fw; i++) { names[6 + i] = m->fw[i].name; in[6 + i] = m->fw[i].value; }
    st = api->Run(m->s[S_FRONTEND], NULL, names, (const OrtValue *const *)in, (size_t)nin, out_names, 6, out);
    if (st) { api->ReleaseStatus(st); goto done; }
    int64_t fd[3];
    float *feat = NULL, *sb = NULL, *c1v = NULL, *c2v = NULL;
    int64_t *sl = NULL, *fc = NULL;
    if (dims_of(api, out[0], fd, 3) != 0 || fd[2] != c->encoder_dim) goto done;
    st = api->GetTensorMutableData(out[0], (void **)&feat);
    if (!st) st = api->GetTensorMutableData(out[1], (void **)&sb);
    if (!st) st = api->GetTensorMutableData(out[2], (void **)&sl);
    if (!st) st = api->GetTensorMutableData(out[3], (void **)&c1v);
    if (!st) st = api->GetTensorMutableData(out[4], (void **)&c2v);
    if (!st) st = api->GetTensorMutableData(out[5], (void **)&fc);
    if (st) { api->ReleaseStatus(st); goto done; }
    int nf = (int)fd[1];
    if (nf > 0) {
        if (grow((void **)&m->feat, &m->feat_cap, (m->feat_n + nf) * c->encoder_dim, sizeof(float)) != 0) goto done;
        memcpy(m->feat + (size_t)m->feat_n * (size_t)c->encoder_dim, feat, sizeof(float) * (size_t)nf * (size_t)c->encoder_dim);
        m->feat_n += nf;
    }
    memcpy(m->sbuf, sb, sizeof(float) * (size_t)c->sample_buffer);
    m->sbuf_len = *sl;
    memcpy(m->conv1, c1v, sizeof(float) * (size_t)c->d_model_frontend * 4);
    memcpy(m->conv2, c2v, sizeof(float) * (size_t)c->c1 * 4);
    m->frame_count = *fc;
    rc = 0;
done:
    for (int i = 0; i < 6 && in; i++) if (in[i]) api->ReleaseValue(in[i]);   /* the weights' values are kept */
    release_all(api, out, 6);
    free(in);
    free(names);
    return rc;
}

/* Encode what is new: frames with their full lookahead become final memory;
 * the rest is encoded into a provisional tail for this call. Returns the
 * memory length to decode over (final + provisional), or <0. */
static int encode(mss *m) {
    const OrtApi *api = m->api;
    const spk_ms_stream_config *c = &m->cfg;
    int total = m->feat_n;
    if (total == 0) return 0;
    if (m->prov_feat == total) return m->mem_n + m->prov_n;   /* nothing new since the last call */
    int stable = total - c->total_lookahead;
    if (stable < m->enc_done) stable = m->enc_done;
    int start = m->enc_done - 16 * c->depth;   /* the encoder's left context */
    if (start < 0) start = 0;
    int wsize = total - start, rc = -1;
    OrtValue *fin = NULL, *enc = NULL, *ain[2] = { NULL, NULL }, *mem = NULL;
    int64_t f_dims[3] = { 1, wsize, c->encoder_dim };
    OrtStatus *st = api->CreateTensorWithDataAsOrtValue(m->mem, m->feat + (size_t)start * (size_t)c->encoder_dim,
                                                        sizeof(float) * (size_t)wsize * (size_t)c->encoder_dim, f_dims, 3, ONNX_TENSOR_ELEMENT_DATA_TYPE_FLOAT, &fin);
    static const char *e_in[1] = { "features" }, *e_out[1] = { "encoded" };
    if (!st) st = api->Run(m->s[S_ENCODER], NULL, e_in, (const OrtValue *const *)&fin, 1, e_out, 1, &enc);
    if (st) { api->ReleaseStatus(st); goto done; }
    int64_t ed[3];
    float *encoded = NULL;
    if (dims_of(api, enc, ed, 3) != 0 || ed[1] != wsize || ed[2] != c->encoder_dim) goto done;
    st = api->GetTensorMutableData(enc, (void **)&encoded);
    if (st) { api->ReleaseStatus(st); goto done; }
    /* adapter over [enc_done, total): positions pos, pos + 1, ... */
    int nnew = total - m->enc_done;
    int64_t a_dims[3] = { 1, nnew, c->encoder_dim }, p_dims[1] = { 1 };
    st = api->CreateTensorWithDataAsOrtValue(m->mem, encoded + (size_t)(m->enc_done - start) * (size_t)c->encoder_dim,
                                             sizeof(float) * (size_t)nnew * (size_t)c->encoder_dim, a_dims, 3, ONNX_TENSOR_ELEMENT_DATA_TYPE_FLOAT, &ain[0]);
    if (!st) st = api->CreateTensorWithDataAsOrtValue(m->mem, &m->pos, sizeof(int64_t), p_dims, 1, ONNX_TENSOR_ELEMENT_DATA_TYPE_INT64, &ain[1]);
    static const char *a_in[2] = { "encoded", "pos_offset" }, *a_out[1] = { "memory" };
    if (!st) st = api->Run(m->s[S_ADAPTER], NULL, a_in, (const OrtValue *const *)ain, 2, a_out, 1, &mem);
    if (st) { api->ReleaseStatus(st); goto done; }
    int64_t md[3];
    float *rows = NULL;
    if (dims_of(api, mem, md, 3) != 0 || md[1] != nnew || md[2] != c->decoder_dim) goto done;
    st = api->GetTensorMutableData(mem, (void **)&rows);
    if (st) { api->ReleaseStatus(st); goto done; }
    if (grow((void **)&m->memory, &m->mem_cap, (m->mem_n + nnew) * c->decoder_dim, sizeof(float)) != 0) goto done;
    memcpy(m->memory + (size_t)m->mem_n * (size_t)c->decoder_dim, rows, sizeof(float) * (size_t)nnew * (size_t)c->decoder_dim);
    int final_new = stable - m->enc_done;
    m->mem_n += final_new;
    m->prov_n = nnew - final_new;
    m->pos += final_new;
    m->enc_done = stable;
    m->prov_feat = total;
    rc = m->mem_n + m->prov_n;
done:
    if (fin) api->ReleaseValue(fin);
    if (enc) api->ReleaseValue(enc);
    release_all(api, ain, 2);
    if (mem) api->ReleaseValue(mem);
    return rc;
}

/* The decoder's choice from one logits row: argmax, then vocabulary biasing
 * (a boosted token wins if it is within its boost of the best); *lp gets the
 * chosen token's log-probability under the unbiased logits. */
static int64_t pick(mss *m, const float *row, const int64_t *hyp, int nhyp, double *lp, int64_t forced) {
    int V = m->cfg.vocab_size;
    int64_t ban = nhyp == 0 ? m->ban0 : -1, best = ban == 0 ? 1 : 0;
    for (int v = best + 1; v < V; v++) if (v != ban && row[v] > row[best]) best = v;
    float mx = row[best];
    if (forced < 0 && spk_bias_count(m->bias) > 0) {
        int32_t bt[SPK_BIAS_MAX_PHRASES];
        float bw[SPK_BIAS_MAX_PHRASES];
        int nb = spk_bias_boosts(m->bias, hyp, nhyp, bt, bw, SPK_BIAS_MAX_PHRASES);
        float top = row[best];
        for (int i = 0; i < nb; i++)
            if (bt[i] >= 0 && bt[i] < V && row[bt[i]] + bw[i] > top) { top = row[bt[i]] + bw[i]; best = bt[i]; }
    }
    int64_t chosen = forced >= 0 ? forced : best;
    double z = 0;
    for (int v = 0; v < V; v++) z += exp((double)row[v] - mx);
    *lp = (double)row[chosen] - mx - log(z);
    return chosen;
}

typedef struct {
    OrtValue *k, *v;            /* self-attention cache, [depth, 1, nheads, len, head_dim] */
    float *own[2];              /* our buffers under k, v after a trim (else ORT's outputs) */
    int len;
} kvself;

static void kv_free(const OrtApi *api, kvself *kv) {
    if (kv->k) api->ReleaseValue(kv->k);
    if (kv->v) api->ReleaseValue(kv->v);
    free(kv->own[0]);
    free(kv->own[1]);
    memset(kv, 0, sizeof *kv);
}

/* One decoder pass over toks[0..n) after the cache; logits [n][vocab] stay in
 * *logits_out (release it). The cache grows by n. */
static int decoder_run(mss *m, kvself *kv, OrtValue *const cross[2], const int64_t *toks, int n, OrtValue **logits_out) {
    const OrtApi *api = m->api;
    const spk_ms_stream_config *c = &m->cfg;
    static float empty[1];
    OrtValue *tok = NULL, *in[5], *out[3] = { NULL, NULL, NULL };
    int64_t t_dims[2] = { 1, n };
    OrtStatus *st = api->CreateTensorWithDataAsOrtValue(m->mem, (void *)toks, sizeof(int64_t) * (size_t)n, t_dims, 2, ONNX_TENSOR_ELEMENT_DATA_TYPE_INT64, &tok);
    if (!st && !kv->k) {   /* an empty cache: len 0 */
        int64_t e_dims[5] = { c->depth, 1, c->nheads, 0, c->head_dim };
        st = api->CreateTensorWithDataAsOrtValue(m->mem, empty, 0, e_dims, 5, ONNX_TENSOR_ELEMENT_DATA_TYPE_FLOAT, &kv->k);
        if (!st) st = api->CreateTensorWithDataAsOrtValue(m->mem, empty, 0, e_dims, 5, ONNX_TENSOR_ELEMENT_DATA_TYPE_FLOAT, &kv->v);
        kv->len = 0;
    }
    if (st) { api->ReleaseStatus(st); if (tok) api->ReleaseValue(tok); return -1; }
    in[0] = tok; in[1] = kv->k; in[2] = kv->v; in[3] = cross[0]; in[4] = cross[1];
    static const char *d_in[5] = { "token", "k_self", "v_self", "out_k_cross", "out_v_cross" };
    static const char *d_out[3] = { "logits", "out_k_self", "out_v_self" };
    st = api->Run(m->s[S_DECODER], NULL, d_in, (const OrtValue *const *)in, 5, d_out, 3, out);
    api->ReleaseValue(tok);
    if (st) { api->ReleaseStatus(st); return -1; }
    int64_t kd[5];
    if (dims_of(api, out[1], kd, 5) != 0 || kd[3] != kv->len + n) { release_all(api, out, 3); return -1; }
    kv_free(api, kv);
    kv->k = out[1];
    kv->v = out[2];
    kv->len = (int)kd[3];
    *logits_out = out[0];
    return 0;
}

/* Keep the first `keep` positions of the cache (the agreed part of a draft). */
static int kv_trim(mss *m, kvself *kv, int keep) {
    const OrtApi *api = m->api;
    const spk_ms_stream_config *c = &m->cfg;
    if (keep >= kv->len) return 0;
    int blocks = c->depth * c->nheads;
    size_t cnt = (size_t)blocks * (size_t)keep * (size_t)c->head_dim;
    kvself t = { NULL, NULL, { malloc(sizeof(float) * (cnt ? cnt : 1)), malloc(sizeof(float) * (cnt ? cnt : 1)) }, keep };
    if (!t.own[0] || !t.own[1]) { kv_free(api, &t); return -1; }
    OrtValue *src[2] = { kv->k, kv->v };
    int64_t dims[5] = { c->depth, 1, c->nheads, keep, c->head_dim };
    for (int i = 0; i < 2; i++) {
        float *p = NULL;
        OrtStatus *st = api->GetTensorMutableData(src[i], (void **)&p);
        if (!st) {
            spk_ms_kv_prefix(p, blocks, kv->len, keep, c->head_dim, t.own[i]);
            st = api->CreateTensorWithDataAsOrtValue(m->mem, t.own[i], sizeof(float) * cnt, dims, 5, ONNX_TENSOR_ELEMENT_DATA_TYPE_FLOAT, i ? &t.v : &t.k);
        }
        if (st) { api->ReleaseStatus(st); kv_free(api, &t); return -1; }
    }
    kv_free(api, kv);
    *kv = t;
    return 0;
}

/* Base's loop guard (a block three times), then a long block twice. */
static int cut_of(const int64_t *toks, int n) {
    int cut = spk_ms_loop_cut(toks, n);
    return cut > 0 ? cut : spk_ms_repeat_cut(toks, n, MS_REPEAT);
}

/* Greedy decode over memory rows [0, mem_len), starting from the draft. */
static int decode(mss *m, int mem_len, int max_len, int64_t *toks, int *ntok_out) {
    const OrtApi *api = m->api;
    const spk_ms_stream_config *c = &m->cfg;
    int V = c->vocab_size, rc = -1, ntok = 0, lp_n = 0;
    double lp_sum = 0, lp = 0;
    OrtValue *mem = NULL, *cross[2] = { NULL, NULL }, *logits = NULL;
    kvself kv = { 0 };
    int64_t *seq = malloc(sizeof(int64_t) * (size_t)(max_len + 2));
    int64_t *pred = malloc(sizeof(int64_t) * (size_t)(max_len + 2));
    if (!seq || !pred) goto done;
    int64_t m_dims[3] = { 1, mem_len, c->decoder_dim };
    OrtStatus *st = api->CreateTensorWithDataAsOrtValue(m->mem, m->memory, sizeof(float) * (size_t)mem_len * (size_t)c->decoder_dim, m_dims, 3, ONNX_TENSOR_ELEMENT_DATA_TYPE_FLOAT, &mem);
    static const char *x_in[1] = { "memory" }, *x_out[2] = { "k_cross", "v_cross" };
    if (!st) st = api->Run(m->s[S_CROSS], NULL, x_in, (const OrtValue *const *)&mem, 1, x_out, 2, cross);
    if (st) { api->ReleaseStatus(st); goto done; }

    /* one pass over BOS + draft */
    int nd = m->draft_n < max_len ? m->draft_n : max_len;
    seq[0] = c->bos_id;
    if (nd > 0) memcpy(seq + 1, m->draft, sizeof(int64_t) * (size_t)nd);
    if (decoder_run(m, &kv, cross, seq, nd + 1, &logits) != 0) goto done;
    float *lg = NULL;
    st = api->GetTensorMutableData(logits, (void **)&lg);
    if (st) { api->ReleaseStatus(st); goto done; }
    /* row t: the choice after draft[0..t) */
    int a = 0;
    for (; a <= nd; a++) {
        pred[a] = pick(m, lg + (size_t)a * (size_t)V, m->draft, a, &lp, -1);
        if (a == nd || pred[a] != m->draft[a]) break;
        lp_sum += lp; lp_n++;   /* an agreed draft token: its log-probability */
    }
    a = spk_ms_draft_accept(m->draft, nd, pred);
    lp_sum += lp; lp_n++;       /* the choice at the first disagreement (or after the whole draft) */
    memcpy(toks, m->draft, sizeof(int64_t) * (size_t)a);
    ntok = a;
    int64_t next = pred[a];
    api->ReleaseValue(logits);
    logits = NULL;
    if (kv_trim(m, &kv, a + 1) != 0) goto done;   /* BOS + the agreed tokens */
    int cut = cut_of(toks, ntok);
    if (cut > 0) { ntok = cut; rc = 0; goto done; }

    /* then one token at a time */
    while (next != c->eos_id && ntok < max_len) {
        toks[ntok++] = next;
        cut = cut_of(toks, ntok);
        if (cut > 0) { ntok = cut; break; }
        if (ntok >= max_len) break;
        if (decoder_run(m, &kv, cross, &next, 1, &logits) != 0) goto done;
        st = api->GetTensorMutableData(logits, (void **)&lg);
        if (st) { api->ReleaseStatus(st); goto done; }
        next = pick(m, lg, toks, ntok, &lp, -1);
        lp_sum += lp; lp_n++;
        api->ReleaseValue(logits);
        logits = NULL;
    }
    rc = 0;
done:
    if (rc == 0) {
        *ntok_out = ntok;
        m->conf = lp_n > 0 ? (float)exp(lp_sum / lp_n) : -1.0f;
    }
    if (logits) api->ReleaseValue(logits);
    kv_free(api, &kv);
    release_all(api, cross, 2);
    if (mem) api->ReleaseValue(mem);
    free(seq);
    free(pred);
    return rc;
}

/* ------------------------------------------------------------- transcribe */
/* The line opens with "1." (pieces: "▁", digits, "."): see spk_ms_list_marker. */
static int list_marker(mss *m, const int64_t *toks, int n) {
    char head[48];
    spk_vocab_decode(m->vocab, toks, n < 6 ? n : 6, head, sizeof head);
    return spk_ms_list_marker(head);
}

static int ms_transcribe(void *ctx, const float *pcm, int n, char *out, size_t cap) {
    mss *m = ctx;
    if (!out || cap == 0) return SPK_E_INVALID;
    out[0] = '\0';
    m->conf = -1.0f;
    if (!m->s[S_DECODER]) return SPK_E_NOT_READY;
    if (!pcm || n < SPK_ASR_RATE / 10) return 0;   /* under 100 ms: nothing to say */

    /* Whole 1280-sample (80 ms) chunks only, as Moonshine's transcriber.cpp
     * feeds them: the published frontend graphs (exported before 2026-08-23)
     * lose a chunk's remainder while reporting it as buffered, and a chunk
     * that is not a whole number of features (320 samples) leaves the conv
     * state wrong (garbage from then on: measured). The remainder (< 80 ms;
     * a final has 300 ms of tail) waits for the next call. At most 0.8 s per
     * run bounds the frontend's scratch. */
    int usable = n - n % MS_CHUNK;
    /* the same utterance as the last call? extended, or cut shorter (the final) */
    int common = usable < m->seen_n ? usable : m->seen_n;
    int same = m->seen_n > 0 && memcmp(pcm, m->seen, sizeof(float) * (size_t)common) == 0;
    if (!same) {
        m->draft_n = 0;
        m->ban0 = -1;
        stream_reset(m);
    } else if (usable < m->seen_n) {
        if (stream_rollback(m, usable) != 0) stream_reset(m);
    } else if (usable > m->seen_n && m->fe_stale) {
        stream_reset(m);   /* the frontend state is past seen_n: from the start */
    }
    if (usable > m->seen_n) {
        if (grow((void **)&m->seen, &m->seen_cap, usable, sizeof(float)) != 0) return SPK_E_MEMORY;
        int chunk = 10 * MS_CHUNK;
        while (m->seen_n < usable) {
            int from = m->seen_n, k = usable - from < chunk ? usable - from : chunk;
            if (frontend(m, pcm + from, k) != 0) { stream_reset(m); m->draft_n = 0; return SPK_E_ENGINE; }
            memcpy(m->seen + from, pcm + from, sizeof(float) * (size_t)k);
            m->seen_n = from + k;
            if (m->feat_n * MS_FEAT != m->seen_n) m->no_rollback = 1;   /* not the frontend we know: always start over */
        }
    }
    int mem_len = encode(m);
    if (mem_len < 0) { stream_reset(m); m->draft_n = 0; return SPK_E_ENGINE; }
    if (mem_len == 0) return 0;

    int max_len = (int)ceil((double)n / SPK_ASR_RATE * MS_TOKENS_PER_SECOND);
    if (max_len < 4) max_len = 4;
    int64_t *toks = malloc(sizeof(int64_t) * (size_t)(max_len + 1));
    if (!toks) return SPK_E_MEMORY;
    int ntok = 0;
    if (decode(m, mem_len, max_len, toks, &ntok) != 0) { free(toks); m->draft_n = 0; return SPK_E_ENGINE; }
    if (m->ban0 < 0 && list_marker(m, toks, ntok)) {
        /* "1." at the start: again without its first piece (the bare "▁" that starts a number),
         * and so for the rest of the utterance */
        m->ban0 = toks[0];
        m->draft_n = 0;
        if (decode(m, mem_len, max_len, toks, &ntok) != 0) { free(toks); m->draft_n = 0; return SPK_E_ENGINE; }
    }
    if (grow((void **)&m->draft, &m->draft_cap, ntok + 1, sizeof(int64_t)) == 0) {
        memcpy(m->draft, toks, sizeof(int64_t) * (size_t)ntok);
        m->draft_n = ntok;
    } else {
        m->draft_n = 0;
    }
    spk_vocab_decode(m->vocab, toks, ntok, out, cap);
    if (spk_bias_count(m->bias) > 0) spk_bias_snap(m->bias, m->vocab, out, cap);
    free(toks);
    return 0;
}

static void free_phrases(mss *m) {
    for (int i = 0; i < m->n_phrases; i++) free(m->phrases[i]);
    free(m->phrases);
    m->phrases = NULL;
    m->n_phrases = 0;
}

/* Kept as text: the tokenizer loads with the models (open) and re-encodes them. */
static int ms_set_vocabulary(void *ctx, const char *const *phrases, int n) {
    mss *m = ctx;
    free_phrases(m);
    m->draft_n = 0;   /* a new list may change the decode: no stale draft */
    if (n > SPK_BIAS_MAX_PHRASES) n = SPK_BIAS_MAX_PHRASES;
    if (n > 0) {
        m->phrases = calloc((size_t)n, sizeof(char *));
        if (!m->phrases) return SPK_E_MEMORY;
        for (int i = 0; i < n; i++) {
            if (!phrases[i] || !*phrases[i]) continue;
            char *d = dupstr(phrases[i]);
            if (!d) { free_phrases(m); return SPK_E_MEMORY; }
            m->phrases[m->n_phrases++] = d;
        }
    }
    if (!m->vocab) return m->n_phrases;   /* encoded at open */
    return spk_bias_set(m->bias, m->vocab, (const char *const *)m->phrases, m->n_phrases);
}

static float ms_confidence(void *ctx) { return ((mss *)ctx)->conf; }

static void ms_destroy(void *ctx) {
    mss *m = ctx;
    if (!m) return;
    ms_close(m);
    free_phrases(m);
    spk_bias_free(m->bias);
    for (int i = 0; i < P_COUNT; i++) free(m->path[i]);
    free(m);
}

int spk_moonshine_streaming_engine(const spk_asr_paths *paths, spk_asr_engine *out, char *err, size_t err_len) {
    if (out) memset(out, 0, sizeof *out);
    if (!paths || !out || !paths->encoder || !paths->decoder || !paths->tokenizer || !paths->vad ||
        !paths->frontend || !paths->adapter || !paths->cross_kv || !paths->config) {
        if (err && err_len) snprintf(err, err_len, "missing streaming ASR model paths");
        return SPK_E_INVALID;
    }
    mss *m = calloc(1, sizeof *m);
    if (!m) return SPK_E_MEMORY;
    m->conf = -1.0f;
    m->ban0 = -1;
    m->bias = spk_bias_new();
    if (!m->bias) { free(m); return SPK_E_MEMORY; }
    const char *src[P_COUNT] = { paths->frontend, paths->frontend_weights, paths->encoder, paths->adapter, paths->cross_kv,
                                 paths->decoder, paths->tokenizer, paths->config, paths->vad };
    for (int i = 0; i < P_COUNT; i++) {
        if (!src[i]) continue;   /* frontend_weights is optional */
        m->path[i] = dupstr(src[i]);
        if (!m->path[i]) { ms_destroy(m); return SPK_E_MEMORY; }
    }
    out->ctx = m;
    out->open = ms_open;
    out->close = ms_close;
    out->vad = ms_vad;
    out->vad_reset = ms_vad_reset;
    out->transcribe = ms_transcribe;
    out->destroy = ms_destroy;
    out->set_vocabulary = ms_set_vocabulary;
    out->confidence = ms_confidence;
    out->max_utterance_ms = SPK_ASR_STREAM_MAX_MS;
    out->min_confidence = SPK_ASR_STREAM_MIN_CONFIDENCE;
    return SPK_OK;
}

#else /* !SPARKS_WITH_MOONSHINE */

int spk_moonshine_streaming_engine(const spk_asr_paths *paths, spk_asr_engine *out, char *err, size_t err_len) {
    (void)paths;
    if (out) memset(out, 0, sizeof *out);
    if (err && err_len) snprintf(err, err_len, "built without Moonshine (define SPARKS_WITH_MOONSHINE)");
    return SPK_E_NOT_READY;
}

#endif
