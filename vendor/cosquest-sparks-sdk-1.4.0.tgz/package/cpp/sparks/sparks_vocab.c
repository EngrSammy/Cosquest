/* sparks_vocab.c: Moonshine's tokenizer (tokenizer.bin) without ONNX Runtime,
 * so it is unit-tested on every build:
 *
 *   - load the piece table and decode token ids to text;
 *   - encode text to ids with SentencePiece BPE (Moonshine uses the Llama
 *     tokenizer: pieces are ordered by merge priority, so repeatedly merging
 *     the adjacent pair whose concatenation has the lowest id reproduces its
 *     tokenisation; ids 3..258 are byte fallbacks);
 *   - vocabulary biasing ("contextual biasing"): a list of phrases the call is
 *     likely to contain (the people on the call, CosQuest's own words) as
 *     token sequences, and the logit boosts that steer greedy decoding
 *     towards them. Measured on Nigerian English (cpp/test/asr-eval/
 *     ACCENT.md): names heard right 27% -> 58% with 30 distractor phrases,
 *     word error rate 13.5% -> 12.3%, no change on speech without them. */
#define _POSIX_C_SOURCE 200809L
#include "sparks_core.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define SPACE_UTF8 "\xE2\x96\x81"   /* U+2581, SentencePiece's word boundary */
#define BYTE_FIRST 3                 /* <0x00> */
#define BYTE_LAST  258               /* <0xFF> */

struct spk_vocab {
    uint8_t  *blob;
    uint32_t *off;
    uint16_t *len;
    int       n;
    int32_t  *map;        /* open addressing: piece -> id + 1, 0 = empty */
    uint32_t  map_mask;
};

static uint32_t fnv(const uint8_t *s, size_t n) {
    uint32_t h = 2166136261u;
    for (size_t i = 0; i < n; i++) { h ^= s[i]; h *= 16777619u; }
    return h;
}

static int is_special(const uint8_t *b, size_t len) {
    return len > 2 && b[0] == '<' && b[len - 1] == '>';
}

/* The piece's id, or -1. Byte-fallback ids never come back from here. */
static int lookup(const spk_vocab *v, const uint8_t *s, size_t n) {
    if (n == 0 || n > 65535) return -1;
    for (uint32_t h = fnv(s, n) & v->map_mask;; h = (h + 1) & v->map_mask) {
        int32_t e = v->map[h];
        if (e == 0) return -1;
        int id = e - 1;
        if (v->len[id] == n && memcmp(v->blob + v->off[id], s, n) == 0) return id;
    }
}

spk_vocab *spk_vocab_from_bytes(const uint8_t *bytes, size_t n) {
    if (!bytes || n == 0 || n > (64u << 20)) return NULL;
    spk_vocab *v = calloc(1, sizeof *v);
    if (!v) return NULL;
    v->blob = malloc(n);
    if (!v->blob) { free(v); return NULL; }
    memcpy(v->blob, bytes, n);
    /* entries: 0 = empty; b < 128: b bytes follow; else (next*128 + b - 128) bytes follow */
    int count = 0;
    for (size_t i = 0; i < n;) {
        uint8_t b = v->blob[i++];
        size_t len = b;
        if (b >= 128) { if (i >= n) break; len = (size_t)v->blob[i++] * 128 + b - 128; }
        if (i + len > n) break;
        i += len;
        count++;
    }
    if (count < 3) { spk_vocab_free(v); return NULL; }
    v->off = malloc(sizeof(uint32_t) * (size_t)count);
    v->len = malloc(sizeof(uint16_t) * (size_t)count);
    uint32_t cap = 1;
    while (cap < (uint32_t)count * 2) cap <<= 1;
    v->map = calloc(cap, sizeof(int32_t));
    v->map_mask = cap - 1;
    if (!v->off || !v->len || !v->map) { spk_vocab_free(v); return NULL; }
    int k = 0;
    for (size_t i = 0; i < n && k < count;) {
        uint8_t b = v->blob[i++];
        size_t len = b;
        if (b >= 128) len = (size_t)v->blob[i++] * 128 + b - 128;
        v->off[k] = (uint32_t)i;
        v->len[k] = (uint16_t)(len > 65535 ? 65535 : len);
        i += len;
        k++;
    }
    v->n = k;
    /* index the mergeable pieces; the first id wins (the higher-priority merge) */
    for (int id = 0; id < v->n; id++) {
        if (id >= BYTE_FIRST && id <= BYTE_LAST) continue;
        const uint8_t *s = v->blob + v->off[id];
        size_t len = v->len[id];
        if (len == 0 || is_special(s, len)) continue;
        if (lookup(v, s, len) >= 0) continue;
        uint32_t h = fnv(s, len) & v->map_mask;
        while (v->map[h]) h = (h + 1) & v->map_mask;
        v->map[h] = id + 1;
    }
    return v;
}

spk_vocab *spk_vocab_load(const char *path) {
    FILE *f = fopen(path, "rb");
    if (!f) return NULL;
    fseek(f, 0, SEEK_END);
    long n = ftell(f);
    fseek(f, 0, SEEK_SET);
    spk_vocab *v = NULL;
    if (n > 0 && n <= (64L << 20)) {
        uint8_t *buf = malloc((size_t)n);
        if (buf && fread(buf, 1, (size_t)n, f) == (size_t)n) v = spk_vocab_from_bytes(buf, (size_t)n);
        free(buf);
    }
    fclose(f);
    return v;
}

void spk_vocab_free(spk_vocab *v) {
    if (!v) return;
    free(v->blob);
    free(v->off);
    free(v->len);
    free(v->map);
    free(v);
}

int spk_vocab_size(const spk_vocab *v) { return v ? v->n : 0; }

/* Tokens to text: skip special entries ("<...>"), U+2581 is a space, trim. */
/* Keep only whole, well-formed UTF-8 characters, in place. Byte-level pieces
 * can split a character between tokens, and decoding can stop between them
 * (the token cap, the loop guard, the output cap): such a fragment, or a
 * stray byte, is dropped. Overlong forms and surrogates are not checked. */
static void utf8_clean(char *str) {
    uint8_t *p = (uint8_t *)str;
    size_t r = 0, w = 0;
    while (p[r]) {
        uint8_t c = p[r];
        size_t need = c < 0x80 ? 1 : (c >> 5) == 6 ? 2 : (c >> 4) == 14 ? 3 : (c >> 3) == 30 ? 4 : 0;
        size_t k = 1;
        while (need > 1 && k < need && (p[r + k] & 0xC0) == 0x80) k++;
        if (need == 0 || k < need) { r += need == 0 ? 1 : k; continue; }
        memmove(p + w, p + r, need);
        w += need;
        r += need;
    }
    p[w] = '\0';
}

void spk_vocab_decode(const spk_vocab *v, const int64_t *toks, int n, char *out, size_t cap) {
    if (!out || cap == 0) return;
    size_t o = 0;
    for (int i = 0; v && i < n; i++) {
        int64_t t = toks[i];
        if (t < 0 || t >= v->n) continue;
        const uint8_t *b = v->blob + v->off[t];
        size_t len = v->len[t];
        if (len == 0 || is_special(b, len)) continue;
        for (size_t j = 0; j < len && o + 1 < cap;) {
            if (j + 2 < len && b[j] == 0xE2 && b[j + 1] == 0x96 && b[j + 2] == 0x81) { out[o++] = ' '; j += 3; }
            else out[o++] = (char)b[j++];
        }
    }
    out[o] = '\0';
    utf8_clean(out);
    size_t s = 0;
    while (out[s] == ' ' || out[s] == '\n' || out[s] == '\t') s++;
    size_t e = strlen(out);
    while (e > s && (out[e - 1] == ' ' || out[e - 1] == '\n' || out[e - 1] == '\t')) e--;
    memmove(out, out + s, e - s);
    out[e - s] = '\0';
}

static size_t utf8_len(uint8_t c) {
    return c < 0x80 ? 1 : (c >> 5) == 6 ? 2 : (c >> 4) == 14 ? 3 : (c >> 3) == 30 ? 4 : 1;
}

/* SentencePiece BPE of " " + text (spaces become U+2581). Returns the number
 * of ids written (at most cap), 0 for empty text, -1 on error. */
int spk_vocab_encode(const spk_vocab *v, const char *text, int32_t *out, int cap) {
    if (!v || !text || !out || cap <= 0) return -1;
    while (*text == ' ') text++;
    size_t tl = strlen(text);
    while (tl > 0 && text[tl - 1] == ' ') tl--;
    if (tl == 0) return 0;
    if (tl > 256) return -1;
    /* the normalised string: U+2581 + text with spaces -> U+2581 */
    uint8_t s[4 * 257];
    size_t n = 0;
    memcpy(s, SPACE_UTF8, 3);
    n = 3;
    for (size_t i = 0; i < tl; i++) {
        if (text[i] == ' ') {
            if (i > 0 && text[i - 1] == ' ') continue;
            memcpy(s + n, SPACE_UTF8, 3);
            n += 3;
        } else s[n++] = (uint8_t)text[i];
    }
    /* parts = UTF-8 characters, as (start, length) */
    size_t ps[4 * 257], pl[4 * 257];
    int np = 0;
    for (size_t i = 0; i < n;) {
        size_t l = utf8_len(s[i]);
        if (i + l > n) l = n - i;
        ps[np] = i; pl[np] = l; np++;
        i += l;
    }
    for (;;) {
        int best = -1, at = -1;
        for (int i = 0; i + 1 < np; i++) {
            int id = lookup(v, s + ps[i], pl[i] + pl[i + 1]);
            if (id >= 0 && (best < 0 || id < best)) { best = id; at = i; }
        }
        if (best < 0) break;
        pl[at] += pl[at + 1];
        memmove(ps + at + 1, ps + at + 2, sizeof(size_t) * (size_t)(np - at - 2));
        memmove(pl + at + 1, pl + at + 2, sizeof(size_t) * (size_t)(np - at - 2));
        np--;
    }
    int k = 0;
    for (int i = 0; i < np; i++) {
        int id = lookup(v, s + ps[i], pl[i]);
        if (id >= 0) {
            if (k >= cap) return k;
            out[k++] = id;
            continue;
        }
        for (size_t j = 0; j < pl[i]; j++) {          /* byte fallback */
            int b = BYTE_FIRST + s[ps[i] + j];
            if (b >= v->n) return -1;
            if (k >= cap) return k;
            out[k++] = b;
        }
    }
    return k;
}

/* ------------------------------------------------------------- biasing */
struct spk_bias {
    int      n;
    int      len[SPK_BIAS_MAX_PHRASES];
    uint8_t  short_first[SPK_BIAS_MAX_PHRASES];   /* first piece not boosted up front (first_ok) */
    int32_t  tok[SPK_BIAS_MAX_PHRASES][SPK_BIAS_MAX_TOKENS];
    float    first, next, first_short;
    int      min_chars, min_id;
    /* name snapping (spk_bias_snap): one-word phrases the tokenizer splits into 2+ pieces */
    int      n_snap;
    char     snap_text[SPK_BIAS_MAX_PHRASES][48];
    char     snap_low[SPK_BIAS_MAX_PHRASES][48];   /* ASCII letters lowercased, other bytes as they are */
};

spk_bias *spk_bias_new(void) {
    spk_bias *b = calloc(1, sizeof *b);
    if (b) {
        b->first = SPK_BIAS_FIRST; b->next = SPK_BIAS_NEXT; b->first_short = SPK_BIAS_FIRST_SHORT;
        b->min_chars = SPK_BIAS_MIN_FIRST_CHARS; b->min_id = SPK_BIAS_MIN_FIRST_ID;
    }
    return b;
}

/* Characters in a piece, not counting a leading U+2581. */
static int piece_chars(const spk_vocab *v, int id) {
    if (!v || id < 0 || id >= v->n) return 0;
    const uint8_t *b = v->blob + v->off[id];
    size_t len = v->len[id], i = 0;
    if (len >= 3 && b[0] == 0xE2 && b[1] == 0x96 && b[2] == 0x81) i = 3;
    int c = 0;
    for (; i < len; i++) c += (b[i] & 0xC0) != 0x80;
    return c;
}

void spk_bias_free(spk_bias *b) { free(b); }

void spk_bias_set_weights(spk_bias *b, float first, float next, float first_short) {
    if (b) { b->first = first; b->next = next; b->first_short = first_short; }
}

int spk_bias_count(const spk_bias *b) { return b ? b->n : 0; }

void spk_bias_set_first_rule(spk_bias *b, int min_chars, int min_id) {
    if (b) { b->min_chars = min_chars; b->min_id = min_id; }
}

/* May a phrase's first piece be boosted before the model has said it? Only
 * when it is the start of a word the tokenizer has no single piece for (one
 * piece = a word the model already knows; biasing helps the rest), it has
 * min_chars+ letters ("▁W", "▁If" start common words) and it is not one of
 * the commonest pieces (ids are in merge order: "▁For" 1152 and "▁Pro" 1019
 * start "Forge" and "Proctor" but are words themselves). Measured: boosting
 * those took Nigerian conversations from 24.9% to 29.1% WER and Pidgin from
 * 64.5% to 65.0%; with this rule neither moves. */
static int first_ok(const spk_bias *b, const spk_vocab *v, const char *phrase, const int32_t *t, int k) {
    if (k < 1 || piece_chars(v, t[0]) < b->min_chars || t[0] < b->min_id) return 0;
    char w[64];
    size_t i = 0;
    while (*phrase == ' ') phrase++;
    while (phrase[i] && phrase[i] != ' ' && i + 1 < sizeof w) { w[i] = phrase[i]; i++; }
    w[i] = '\0';
    int32_t tw[SPK_BIAS_MAX_TOKENS];
    return spk_vocab_encode(v, w, tw, SPK_BIAS_MAX_TOKENS) >= 2;
}

/* Letters of s (ASCII lowercased, non-ASCII bytes kept, everything else dropped) into out; returns the length. */
static size_t letters(const char *s, size_t n, char *out, size_t cap) {
    size_t o = 0;
    for (size_t i = 0; i < n && o + 1 < cap; i++) {
        unsigned char c = (unsigned char)s[i];
        if (c >= 'A' && c <= 'Z') out[o++] = (char)(c + 32);
        else if ((c >= 'a' && c <= 'z') || c >= 0x80) out[o++] = (char)c;
    }
    out[o] = '\0';
    return o;
}

int spk_bias_set(spk_bias *b, const spk_vocab *v, const char *const *phrases, int n) {
    if (!b) return SPK_E_INVALID;
    b->n = 0;
    b->n_snap = 0;
    if (!v || !phrases) return 0;
    for (int i = 0; i < n && b->n < SPK_BIAS_MAX_PHRASES; i++) {
        if (!phrases[i]) continue;
        int32_t t[SPK_BIAS_MAX_TOKENS];
        int k = spk_vocab_encode(v, phrases[i], t, SPK_BIAS_MAX_TOKENS);
        if (k <= 0) continue;
        /* a phrase longer than the cap is cut there: its start still helps */
        int dup = 0;
        for (int j = 0; j < b->n && !dup; j++)
            dup = b->len[j] == k && memcmp(b->tok[j], t, sizeof(int32_t) * (size_t)k) == 0;
        if (dup) continue;
        memcpy(b->tok[b->n], t, sizeof(int32_t) * (size_t)k);
        b->short_first[b->n] = !first_ok(b, v, phrases[i], t, k);
        b->len[b->n++] = k;
        /* a one-word phrase the model has no single piece for can also be snapped to */
        const char *ph = phrases[i];
        while (*ph == ' ') ph++;
        size_t pl = strlen(ph);
        while (pl > 0 && ph[pl - 1] == ' ') pl--;
        if (k >= 2 && pl > 0 && pl < sizeof b->snap_text[0] && !memchr(ph, ' ', pl) && b->n_snap < SPK_BIAS_MAX_PHRASES) {
            char low[48];
            if (letters(ph, pl, low, sizeof low) >= 4) {
                memcpy(b->snap_text[b->n_snap], ph, pl);
                b->snap_text[b->n_snap][pl] = '\0';
                memcpy(b->snap_low[b->n_snap], low, strlen(low) + 1);
                b->n_snap++;
            }
        }
    }
    return b->n;
}

/* For each phrase: if the hypothesis ends with its first k tokens (longest k,
 * k < length), its token k gets `next`; otherwise its first token gets
 * `first`, or `first_short` when first_ok said no. Boosts for the same
 * token keep the larger; zero boosts are left out. Returns the count. */
int spk_bias_boosts(const spk_bias *b, const int64_t *hyp, int nhyp, int32_t *tok, float *boost, int cap) {
    if (!b || b->n == 0 || cap <= 0) return 0;
    int m = 0;
    for (int p = 0; p < b->n; p++) {
        int len = b->len[p], k = len - 1 < nhyp ? len - 1 : nhyp;
        for (; k > 0; k--) {
            int ok = 1;
            for (int j = 0; j < k && ok; j++) ok = hyp[nhyp - k + j] == b->tok[p][j];
            if (ok) break;
        }
        int32_t t = b->tok[p][k];
        float w = k > 0 ? b->next : b->short_first[p] ? b->first_short : b->first;
        if (w <= 0) continue;
        int j = 0;
        while (j < m && tok[j] != t) j++;
        if (j < m) { if (w > boost[j]) boost[j] = w; }
        else if (m < cap) { tok[m] = t; boost[m] = w; m++; }
    }
    return m;
}

/* ------------------------------------------------------------ snapping
 * After decoding, a word that is nearly a name on the list becomes that name:
 * "Adawali" -> "Adewale", "Sheyi" -> "Seyi", "cost-quest" -> "CosQuest". The
 * logit boost cannot do this for names whose first piece may not be boosted
 * ("▁A", "▁Se"), and the model often lands one letter off. Only words the
 * tokenizer splits into 2+ pieces (not words it knows whole), with the same
 * first letter, at most 2 letters longer or shorter, within 1 edit (names up to
 * 6 letters) or 2 (longer); a lowercase word only for a long name (8+ letters,
 * 1 edit: "cosquest"), since lowercase words are mostly ordinary words; two
 * words joined only when they spell a 7+ letter name within 1 edit ("cos
 * quest"). Measured (cpp/test/asr-eval/accent/ACCENT.md): CosQuest sentences,
 * names and terms right 49 -> 60 of 90; Nigerian English 12.4% -> 12.0% WER;
 * Pidgin and conversations unchanged. */
static int lev(const char *a, size_t na, const char *b, size_t nb) {
    int d[64];
    if (na > 62 || nb > 62) return 99;
    for (size_t j = 0; j <= nb; j++) d[j] = (int)j;
    for (size_t i = 1; i <= na; i++) {
        int prev = d[0];
        d[0] = (int)i;
        for (size_t j = 1; j <= nb; j++) {
            int cur = d[j];
            int sub = prev + (a[i - 1] != b[j - 1]);
            int del = d[j] + 1, ins = d[j - 1] + 1;
            d[j] = sub < del ? (sub < ins ? sub : ins) : (del < ins ? del : ins);
            prev = cur;
        }
    }
    return d[nb];
}

static int is_letter(unsigned char c) { return (c >= 'A' && c <= 'Z') || (c >= 'a' && c <= 'z') || c >= 0x80; }

typedef struct { const char *s; size_t n; } span_t;

/* The word's letters core: [lead punctuation][core][possessive 's or s'][trail punctuation]. */
static void word_parts(span_t w, size_t *core_at, size_t *core_n, size_t *poss_n) {
    size_t a = 0, e = w.n;
    while (a < e && !is_letter((unsigned char)w.s[a])) a++;
    while (e > a && !is_letter((unsigned char)w.s[e - 1])) e--;
    size_t p = 0;
    if (e - a > 3 && w.s[e - 1] == 's' && w.s[e - 2] == '\'') p = 2;   /* possessive 's stays after the name */
    *core_at = a;
    *core_n = e - a - p;
    *poss_n = p;
}

int spk_bias_snap(const spk_bias *b, const spk_vocab *v, char *text, size_t cap) {
    if (!b || !v || !text || b->n_snap == 0) return 0;
    span_t w[512];
    int nw = 0;
    for (char *p = text; *p && nw < 512;) {
        while (*p == ' ') p++;
        if (!*p) break;
        char *q = p;
        while (*q && *q != ' ') q++;
        w[nw].s = p; w[nw].n = (size_t)(q - p); nw++;
        p = q;
    }
    char *out = malloc(cap);
    if (!out) return 0;
    size_t o = 0;
    int changed = 0;
    for (int i = 0; i < nw;) {
        int took = 0;
        for (int span = 2; span >= 1 && !took; span--) {
            if (i + span > nw) continue;
            size_t ca[2], cn[2], pn[2];
            char low[96];
            size_t ln = 0;
            int ok = 1;
            for (int k = 0; k < span; k++) {
                word_parts(w[i + k], &ca[k], &cn[k], &pn[k]);
                if (cn[k] == 0 || (k < span - 1 && pn[k])) { ok = 0; break; }
                ln += letters(w[i + k].s + ca[k], cn[k], low + ln, sizeof low - ln);
            }
            if (!ok || ln < 4) continue;
            int cap1 = (unsigned char)w[i].s[ca[0]] >= 'A' && (unsigned char)w[i].s[ca[0]] <= 'Z';
            if (span == 1) {
                char core[64];
                size_t n = cn[0] < sizeof core - 1 ? cn[0] : sizeof core - 1;
                memcpy(core, w[i].s + ca[0], n);
                core[n] = '\0';
                int32_t t[4];
                if (spk_vocab_encode(v, core, t, 4) < 2) continue;   /* a word the tokenizer has whole */
            }
            int best = -1, bd = 99;
            for (int s = 0; s < b->n_snap; s++) {
                const char *tl = b->snap_low[s];
                size_t tn = strlen(tl);
                if (tl[0] != low[0] || (tn > ln ? tn - ln : ln - tn) > 2) continue;
                int lim = cap1 ? (tn <= 6 ? 1 : 2) : (tn >= 8 ? 1 : -1);
                if (span == 2) lim = tn >= 7 ? (lim < 1 ? lim : 1) : (lim < 0 ? -1 : 0);
                if (lim < 0) continue;
                int d = lev(low, ln, tl, tn);
                if (d <= lim && d < bd) { bd = d; best = s; }
            }
            if (best < 0) continue;
            span_t first = w[i], last = w[i + span - 1];
            size_t lead = ca[0];
            size_t tail_at = ca[span - 1] + cn[span - 1];
            const char *name = b->snap_text[best];
            size_t need = lead + strlen(name) + (last.n - tail_at) + 1;
            if (o + need + 1 >= cap) { took = 0; break; }
            if (o) out[o++] = ' ';
            memcpy(out + o, first.s, lead); o += lead;
            memcpy(out + o, name, strlen(name)); o += strlen(name);
            memcpy(out + o, last.s + tail_at, last.n - tail_at); o += last.n - tail_at;
            changed += span > 1 || strncmp(first.s + lead, name, strlen(name)) != 0 || cn[0] != strlen(name);
            i += span;
            took = 1;
        }
        if (!took) {
            if (o + w[i].n + 2 >= cap) break;
            if (o) out[o++] = ' ';
            memcpy(out + o, w[i].s, w[i].n); o += w[i].n;
            i++;
        }
    }
    out[o] = '\0';
    if (changed) memcpy(text, out, o + 1);
    free(out);
    return changed;
}
