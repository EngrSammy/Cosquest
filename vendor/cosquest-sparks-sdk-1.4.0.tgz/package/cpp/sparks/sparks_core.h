/* sparks_core.h: the platform-neutral C core of the Sparks SDK.
 *
 * Everything here is plain C11 + pthreads so the iOS (Swift) and Android
 * (Kotlin/JNI) layers stay thin: they own downloads, audio capture, TTS,
 * keys and the React Native bridge; this file owns the parts that must
 * behave identically on every phone.
 *
 *   1. Engine scheduler: one model file, two mote handles (warden, sparks),
 *      one generation at a time, priority P0 Warden > P1 interactive >
 *      P2 background, preemption at token and prefill-chunk boundaries,
 *      pause masks for game state and device gates, lazy load, trim on
 *      memory pressure.
 *   2. Text: JSON extraction/repair of model output, the Warden line check,
 *      the tolerant RAM tier comparison.
 *   3. ASR: a lock-free audio ring, resampling to 16 kHz, Silero VAD
 *      framing (end of speech + 600 ms, or 15 s) and Moonshine Base over
 *      ONNX Runtime for partial and final lines, mute, all off the audio
 *      thread. The model runner needs -DSPARKS_WITH_MOONSHINE; without it
 *      the same symbols exist and report "unavailable".
 *
 * Threading: spk_engine and spk_asr callbacks run on their own worker
 * threads; the platform layer hops to its own queues.
 */
#ifndef SPARKS_CORE_H
#define SPARKS_CORE_H

#include <stddef.h>
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

/* ------------------------------------------------------------------ status */
enum {
    SPK_OK            = 0,
    SPK_E_PAUSED      = -10,  /* priority paused (game state or device gate) */
    SPK_E_CANCELLED   = -11,  /* spk_cancel or engine shutdown               */
    SPK_E_BUSY        = -12,  /* queue for this priority is full             */
    SPK_E_ENGINE      = -13,  /* model failed to load or generate            */
    SPK_E_MEMORY      = -14,  /* memory budget check refused the load        */
    SPK_E_GRAMMAR     = -15,  /* grammar would have invented the document    */
    SPK_E_NOT_READY   = -16,  /* no model attached                           */
    SPK_E_INVALID     = -17,  /* bad request                                 */
};

/* -------------------------------------------------------------- priorities */
enum { SPK_P_WARDEN = 0, SPK_P_INTERACTIVE = 1, SPK_P_BACKGROUND = 2, SPK_P_COUNT = 3 };
/* Handles: the Warden owns one; interactive and background share the other. */
enum { SPK_H_WARDEN = 0, SPK_H_SPARKS = 1, SPK_H_COUNT = 2 };
#define SPK_PAUSE_BIT(p) (1u << (p))

/* ---------------------------------------------------------------- backend
 * The engine drives a backend through this table so the scheduler can be
 * tested with a fake one. spk_mote_backend() returns the real one. */
typedef struct {
    float temperature, topp, repeat_penalty;
    int max_tokens;
    unsigned long long seed;
} spk_gen_params;

typedef struct {
    void *ctx;
    /* Open handle `which` (SPK_H_*). NULL on failure; write a reason to err. */
    void *(*open)(void *ctx, int which, char *err, size_t err_len);
    void  (*close)(void *ctx, void *h);
    /* Generate. schema may be NULL. Returns tokens generated (>= 0) or a
     * negative SPK_E_* code. on_token returns 0 to stop. */
    int   (*generate)(void *ctx, void *h, const char *prompt, const spk_gen_params *p,
                      const char *schema, int (*on_token)(const char *piece, void *user), void *user);
    /* Embed into out[cap]; returns dim or 0. */
    int   (*embed)(void *ctx, void *h, const char *text, float *out, int cap);
    /* Model width, for sizing embeddings. */
    int   (*dim)(void *ctx, void *h);
    /* Memory budget: non-zero when it is safe to open handle `which` now. */
    int   (*memory_ok)(void *ctx, int which);
    void  (*destroy)(void *ctx);
    /* Optional: model shape into out[SPK_INFO_COUNT] (dim, n_layers, vocab, seq_len, qbits). */
    void  (*info)(void *ctx, void *h, int *out);
    /* Optional: tokens in text (prompts that cannot fit the context are refused up front); <0 unknown. */
    int   (*count_tokens)(void *ctx, void *h, const char *text);
} spk_backend;

enum { SPK_INFO_DIM = 0, SPK_INFO_LAYERS, SPK_INFO_VOCAB, SPK_INFO_SEQ_LEN, SPK_INFO_QBITS, SPK_INFO_COUNT };

/* The real backend over mote. Paths are copied. memory_ok may be NULL. */
spk_backend spk_mote_backend(const char *model_path, const char *tokenizer_path,
                             int (*memory_ok)(void *user, int which), void *memory_user);

/* ----------------------------------------------------------------- engine */
typedef struct spk_engine spk_engine;

typedef struct {
    int    status;          /* SPK_OK or SPK_E_*                         */
    int    tokens_out;
    int    tokens_in_est;   /* prompt bytes / 3.6: mote does not report it */
    double first_token_ms;  /* from start of this request's run, -1 if none */
    double wall_ms;         /* submit to completion                       */
    double run_ms;          /* time on the engine                         */
    int    preemptions;     /* times it was stopped and resumed           */
} spk_stats;

typedef struct {
    int         priority;      /* SPK_P_*                                       */
    const char *prompt;        /* copied                                        */
    const char *schema;        /* copied; NULL = unconstrained                  */
    const char *stop;          /* copied; generation stops when output contains it */
    spk_gen_params params;
    int         embed;         /* non-zero: embed `prompt` instead of generating */
    /* Streaming pieces (optional). Return 0 to stop early (counts as success). */
    int  (*on_piece)(const char *piece, void *user);
    /* Always called exactly once, on the engine thread. text is the whole
     * output (NULL on error); vec/dim are set for embed requests. */
    void (*on_done)(const spk_stats *stats, const char *text, const float *vec, int dim, void *user);
    void *user;
} spk_request;

typedef struct {
    int running;            /* SPK_P_* of the running request, -1 if idle */
    int queued[SPK_P_COUNT];
    unsigned paused_mask;
    int loaded[SPK_H_COUNT];
} spk_engine_state;

/* Create an engine that owns `backend` (destroyed with the engine). */
spk_engine *spk_engine_create(spk_backend backend);
/* Swap the backend (new model version). Waits for the running request,
 * closes handles, fails queued requests with SPK_E_CANCELLED. */
void spk_engine_set_backend(spk_engine *e, spk_backend backend);
int  spk_engine_has_backend(spk_engine *e);
void spk_engine_free(spk_engine *e);
/* Close the Sparks handle after this many ms with nothing to do (its KV cache,
 * up to 440 MiB after a long job, goes back to the OS; reopening costs ~20 ms
 * and re-reads the mapped weights). Default SPK_IDLE_TRIM_MS; 0 = never. */
void spk_engine_set_idle_trim(spk_engine *e, int ms);
#define SPK_IDLE_TRIM_MS 30000

/* Compute policy for the whole process (sparks_engine.c): matmul threads are
 * capped at SPK_MAX_THREADS, and at SPK_CALL_THREADS while a call is being
 * transcribed (spk_asr_start / spk_asr_stop call this). */
#define SPK_MAX_THREADS  4
#define SPK_CALL_THREADS 2
void spk_compute_call_mode(int on);
int  spk_compute_threads(void);

/* Queue a request. Returns an id > 0, or a negative SPK_E_* code (on_done is
 * NOT called in that case). */
int64_t spk_submit(spk_engine *e, const spk_request *r);
/* Cancel by id. Returns 1 if found. on_done fires with SPK_E_CANCELLED. */
int  spk_cancel(spk_engine *e, int64_t id);
/* Priorities in mask are paused: queued and running requests of those
 * priorities fail with SPK_E_PAUSED, new ones are refused. */
void spk_set_paused(spk_engine *e, unsigned mask);
/* Load handles now (warmup). Returns SPK_OK or an error; err gets a reason. */
int  spk_preload(spk_engine *e, int which, char *err, size_t err_len);
/* Free a handle once idle (memory warning: SPK_H_SPARKS). Returns 1 if freed now. */
int  spk_unload(spk_engine *e, int which);
void spk_engine_get_state(spk_engine *e, spk_engine_state *out);
/* Shape of the model behind handle `which`, loading it if needed (subject to
 * the memory budget). Fills out[SPK_INFO_COUNT]; returns SPK_OK or an error. */
int  spk_engine_info(spk_engine *e, int which, int *out, char *err, size_t err_len);

/* This native build's version, major * 10000 + minor * 100 + patch (1.2.7 ->
 * 10207; 1.2.9 -> 10209; 1.4.0 -> 10400: Moonshine Streaming). The JS layer compares it with its own version: an app that took a
 * new SDK's JavaScript without rebuilding its native code (a stale dev client)
 * runs an old engine, and the SDK says so in the log. */
#define SPK_NATIVE_BUILD 10400

/* How this phone runs the model: out[0] the int8 dot-product kernel (0 plain
 * C, 1 SIMD without a dot-product instruction, 2 ARM SDOT), out[1] the matmul
 * threads (0 when the platform pool does not say), out[2] SPK_NATIVE_BUILD. */
enum { SPK_CPU_KERNEL = 0, SPK_CPU_THREADS, SPK_CPU_BUILD, SPK_CPU_COUNT };
void spk_cpu_info(int out[SPK_CPU_COUNT]);
/* Max queued requests per priority (default 16). */
void spk_set_queue_limit(spk_engine *e, int limit);
/* Prefill chunk size in bytes (default 640; 0 disables chunked prefill). */
void spk_set_prefill_chunk(spk_engine *e, int bytes);
/* Observer: called on the engine thread whenever running/queued changes. */
void spk_set_observer(spk_engine *e, void (*cb)(const spk_engine_state *s, void *user), void *user);

/* ------------------------------------------------------------------- text */
/* Extract the first JSON object from model output and repair what small
 * models get wrong: <think> blocks, code fences, prose around the object,
 * single quotes, unquoted keys, Python literals (None/True/False), trailing
 * commas, smart quotes, and a document cut off mid-way (closes strings and
 * brackets, drops a dangling key). Writes NUL-terminated JSON to out.
 * Returns 0 if the object needed no change, 1 if repaired, -1 if no object,
 * -2 if out is too small. */
int spk_json_repair(const char *raw, char *out, size_t cap);

/* Trim raw model output to the Warden's line (cut at <|im_end|>, newline;
 * strip surrounding quotes). Writes to out. */
void spk_warden_clean(const char *raw, char *out, size_t cap);
/* The Warden line check (port of costquest-ios WardenCheck). input is the
 * fact line the prompt carried ("moment: x | style: y | k: v ..."); place
 * may be NULL. max_words <= 0 uses the moment default (18, legend 32,
 * recap 45). Returns 0 when the line may be said, else 1 with why filled. */
int spk_warden_check(const char *text, const char *moment, const char *input,
                     const char *place, int max_words, char *why, size_t why_len);

/* Tier gate: physical RAM against a manifest floor, tolerant of the OS
 * reporting less than the marketed RAM (a 6 GB iPhone reports ~5.5-5.8 GiB).
 * Meets when ram >= SPK_RAM_TOLERANCE * min_ram. */
#define SPK_RAM_TOLERANCE 0.85
int spk_ram_meets(uint64_t ram_bytes, uint64_t min_ram_bytes);

/* Base64 (standard or url-safe alphabet, padding optional, whitespace
 * ignored) into out[cap]. Returns bytes written, or -1 on a bad character or
 * when out is too small. Used for AudioFrame.pcm16Base64 and key material. */
int spk_b64_decode(const char *in, size_t in_len, uint8_t *out, size_t cap);
/* Upper bound on the decoded size of in_len characters. */
size_t spk_b64_decoded_max(size_t in_len);

/* Little-endian PCM16 bytes to samples. Returns samples written (bytes / 2,
 * capped by cap); a trailing odd byte is ignored. */
int spk_pcm16le_to_i16(const uint8_t *bytes, size_t len, int16_t *out, int cap);

/* -------------------------------------------------------------------- ASR
 * Call transcription (API.md §8). The pipeline, all in sparks_asr.c except
 * the model runner:
 *
 *   push (audio thread: copy into a lock-free ring, never blocks)
 *     -> worker: resample to 16 kHz (spk_resampler)
 *     -> Silero VAD, one probability per 32 ms frame
 *     -> utterance framing (spk_framer): end of speech + 600 ms or 15 s
 *     -> Moonshine Base encoder/decoder on the utterance (partials every
 *        500 ms while it is open, one final when it closes)
 *     -> on_line callback (worker thread)
 *
 * The model runner sits behind spk_asr_engine so the pipeline is tested
 * with a fake one. The real one (sparks_moonshine.c) runs Moonshine Base
 * and Silero over ONNX Runtime and is compiled only with
 * -DSPARKS_WITH_MOONSHINE (the podspec sets it and links onnxruntime-c). */
#define SPK_ASR_RATE        16000   /* Moonshine and Silero input rate        */
#define SPK_ASR_HOP         512     /* VAD frame: 32 ms at 16 kHz             */
#define SPK_ASR_HOLD_MS     600     /* final = end of speech + this           */
#define SPK_ASR_MAX_MS      15000   /* longest utterance                      */
#define SPK_ASR_STREAM_MAX_MS 30000 /* ... for an engine that asks (Moonshine Streaming: max_utterance_ms) */
#define SPK_ASR_MIN_SPEECH_MS 250   /* shorter voiced runs are noise          */
#define SPK_ASR_PREROLL_MS  500     /* audio before the VAD onset given to the model (as Moonshine's own VAD) */
#define SPK_ASR_GAP_MS      1000    /* a jump this big in capture time = new run */
#define SPK_ASR_TAIL_MS     300     /* audio after the last voiced frame given to the model */
#define SPK_ASR_MIN_CONFIDENCE 0.0  /* default confidence floor for finals (see spk_asr_set_min_confidence) */
#define SPK_ASR_STREAM_MIN_CONFIDENCE 0.3 /* ... for an engine that asks (Moonshine Streaming: min_confidence) */

/* 1 when this build links the model runtime (SPARKS_WITH_MOONSHINE), else 0:
 * spk_asr_create then fails cleanly and the SDK reports transcription: false. */
int spk_asr_available(void);

/* ---- streaming resampler: any rate to 16 kHz.
 * Windowed sinc (Blackman, 16 zero crossings per side at the cutoff, cutoff
 * 0.9 x the lower Nyquist), kernel tabulated at init. Output sample k is input
 * time k / 16000 s: no delay is added to the timeline, the first outputs
 * just wait for 16 zero crossings of look-ahead. 16 kHz input is copied. */
typedef struct {
    int     in_rate;
    double  step;        /* input samples per output sample */
    double  pos;         /* next output position, in input samples from buf[0] */
    int     half;        /* kernel half width, input samples */
    float   cutoff;      /* cycles per input sample */
    float  *table;       /* kernel at 1/SPK_RS_OVERSAMPLE input-sample steps over [0, half] */
    int     table_len;
    float  *buf;         /* input history + look-ahead */
    int     len, cap;
} spk_resampler;
#define SPK_RS_OVERSAMPLE 128
/* Returns 0, or -1 (bad rate or no memory). Rates 8 kHz to 192 kHz. */
int  spk_resampler_init(spk_resampler *r, int in_rate);
void spk_resampler_free(spk_resampler *r);
/* Upper bound on outputs for n more inputs (incl. a flush). */
int  spk_resampler_max_out(const spk_resampler *r, int n);
/* Feed n inputs; writes up to cap outputs; returns outputs written. */
int  spk_resampler_process(spk_resampler *r, const float *in, int n, float *out, int cap);
/* End of input: emit the outputs still waiting for look-ahead (zeros after
 * the last sample). The resampler is then reset to empty. */
int  spk_resampler_flush(spk_resampler *r, float *out, int cap);

/* ---- utterance framing over VAD frames.
 * Speech starts at a frame with p >= SPK_FR_ON and continues while
 * p >= SPK_FR_OFF (Silero's hysteresis). The utterance closes once the audio
 * since the last voiced frame reaches SPK_ASR_HOLD_MS (so the final is due at
 * end of speech + 600 ms, at 32 ms resolution), or when it reaches
 * SPK_ASR_MAX_MS. All positions are 16 kHz samples since the run started. */
#define SPK_FR_ON  0.5f
#define SPK_FR_OFF 0.35f
typedef struct {
    int      open;
    int64_t  pos;          /* samples framed so far                  */
    int64_t  audio_start;  /* utterance audio start (with preroll)   */
    int64_t  speech_start; /* first voiced frame                     */
    int64_t  speech_end;   /* end of the last voiced frame           */
    int64_t  voiced;       /* voiced samples in this utterance       */
    int64_t  floor;        /* audio before this belongs to an earlier utterance */
    int64_t  max;          /* longest utterance, samples (0: SPK_ASR_MAX_MS); kept by reset */
} spk_framer;
enum { SPK_FR_NONE = 0, SPK_FR_START = 1, SPK_FR_CLOSE = 2 };
typedef struct {
    int64_t audio_start, speech_start, speech_end, voiced;
    int     reason;        /* SPK_FR_CLOSE: 0 silence, 1 max length, 2 flush */
} spk_utterance;
void spk_framer_reset(spk_framer *f);
/* The utterance cap: ms <= 0 is SPK_ASR_MAX_MS; at most SPK_ASR_STREAM_MAX_MS. */
void spk_framer_set_max_ms(spk_framer *f, int ms);
/* One SPK_ASR_HOP frame's speech probability. Returns SPK_FR_*; on START or
 * CLOSE, *u describes the utterance. */
int  spk_framer_step(spk_framer *f, float prob, spk_utterance *u);
/* Close the open utterance now (stop, mute, gap). Returns SPK_FR_CLOSE with
 * *u, or SPK_FR_NONE when nothing was open. */
int  spk_framer_flush(spk_framer *f, spk_utterance *u);

/* ---- the model runner */
typedef struct {
    void *ctx;
    /* Load the models (spk_asr_start). 0, or <0 with err. */
    int   (*open)(void *ctx, char *err, size_t err_len);
    /* Release model memory (spk_asr_stop). */
    void  (*close)(void *ctx);
    /* Speech probability of SPK_ASR_HOP samples at 16 kHz; stateful. <0 on error. */
    float (*vad)(void *ctx, const float *frame);
    void  (*vad_reset)(void *ctx);
    /* Transcribe n samples at 16 kHz into out (UTF-8, NUL-terminated).
     * Returns 0, or <0 on error. */
    int   (*transcribe)(void *ctx, const float *pcm, int n, char *out, size_t cap);
    void  (*destroy)(void *ctx);
    /* Optional (NULL = not supported). Phrases to steer decoding towards
     * (names, game words); copied. Returns how many were kept, or <0. */
    int   (*set_vocabulary)(void *ctx, const char *const *phrases, int n);
    /* Optional: the last transcribe's confidence, 0..1 (the geometric mean
     * of its token probabilities), or <0 when unknown. */
    float (*confidence)(void *ctx);
    /* Longest utterance before the framer closes it, ms (0: SPK_ASR_MAX_MS, 15 s,
     * which Base was built around). Moonshine Streaming: SPK_ASR_STREAM_MAX_MS,
     * because cutting a conversation's long turns every 15 s cost it more words
     * than Base (Nigerian conversations 23.4% -> 21.6% WER at 30 s; ACCENT.md). */
    int   max_utterance_ms;
    /* Default confidence floor for finals (0: SPK_ASR_MIN_CONFIDENCE, keep
     * everything; spk_asr_set_min_confidence overrides). Moonshine Streaming:
     * SPK_ASR_STREAM_MIN_CONFIDENCE, which drops the lowest babble lines (6 min
     * of noise: small 244 -> 202 words, medium 275 -> 233) and no line of the
     * speech sets, Pidgin included (ACCENT.md "1.4.0"). */
    double min_confidence;
} spk_asr_engine;

/* Model files (from the model manifest's `asr` entry). Moonshine Base sets the
 * first four; Moonshine Streaming (small, medium) also sets adapter and the
 * rest, and spk_asr_create picks the streaming runner when adapter is set. */
typedef struct {
    const char *encoder;     /* Base: encoder_model.ort;        streaming: encoder.ort    */
    const char *decoder;     /* Base: decoder_model_merged.ort; streaming: decoder_kv.ort */
    const char *tokenizer;   /* tokenizer.bin (the same file for Base and streaming)     */
    const char *vad;         /* silero_vad_16k_op15.onnx                                  */
    /* Moonshine Streaming only (NULL for Base) */
    const char *frontend;          /* frontend.model.ort                                  */
    const char *frontend_weights;  /* frontend.weights.ort (NULL: weights in the frontend) */
    const char *adapter;           /* adapter.ort                                         */
    const char *cross_kv;          /* cross_kv.ort                                        */
    const char *config;            /* streaming_config.json                               */
} spk_asr_paths;

/* The real runners. Paths are copied; nothing is loaded until open. Without
 * SPARKS_WITH_MOONSHINE every call fails. sparks_moonshine.c: Moonshine Base.
 * sparks_moonshine_streaming.c: Moonshine Streaming small / medium (the 1.4
 * default), incremental within an utterance (see that file). */
int spk_moonshine_engine(const spk_asr_paths *paths, spk_asr_engine *out, char *err, size_t err_len);
int spk_moonshine_streaming_engine(const spk_asr_paths *paths, spk_asr_engine *out, char *err, size_t err_len);

/* streaming_config.json (shipped with each streaming model). Parsed without
 * ONNX Runtime so it is unit-tested on every build. */
typedef struct {
    int encoder_dim, decoder_dim, depth, nheads, head_dim, vocab_size;
    int bos_id, eos_id, frame_len, total_lookahead, d_model_frontend, c1, c2;
    int sample_buffer;       /* frontend_state_shapes.sample_buffer[1]; frame_len - 1 when absent */
} spk_ms_stream_config;
/* 0, or -1 when a field is missing or not positive. */
int spk_ms_stream_config_parse(const char *json, spk_ms_stream_config *out);
/* Vocabulary-boost weights (spk_bias_set_weights) for a streaming model.
 * Medium (decoder_dim >= 640) keeps 1.3.6's SPK_BIAS_*; small, whose
 * names come out further from the list, gets the stronger set below
 * (accent eval, cq set: 16.9% -> 13.9% WER, the other sets measured too;
 * ACCENT.md "1.4.0"). NULL config: 1.3.6's weights. */
#define SPK_MS_SMALL_BIAS_FIRST       5.0f
#define SPK_MS_SMALL_BIAS_NEXT        7.0f
#define SPK_MS_SMALL_BIAS_FIRST_SHORT 2.0f
void spk_ms_bias_weights(const spk_ms_stream_config *c, float *first, float *next, float *first_short);
/* Decoder self-attention cache [blocks][len][head_dim] -> its first `keep`
 * positions [blocks][keep][head_dim] (a draft rejected part-way). */
void spk_ms_kv_prefix(const float *src, int blocks, int len, int keep, int head_dim, float *dst);
/* How many draft tokens the model agrees with: pred[i] is its choice after
 * draft[0..i), so the longest i with pred[j] == draft[j] for all j < i. */
int spk_ms_draft_accept(const int64_t *draft, int n, const int64_t *pred);
/* The streaming models' language-model takeover (a whole sentence said
 * twice, measured on Pidgin): the last block of min_len to n/2 tokens equal
 * to the block before it. The length that keeps one copy, or 0. */
int spk_ms_repeat_cut(const int64_t *toks, int n, int min_len);
/* The streaming models open about 3% of conversational lines with a list
 * marker ("1.", "27.") and then often stop: "1." for an 11 s sentence. 1 when
 * the decoded line starts with one: digits, ".", then a space or the end. */
int spk_ms_list_marker(const char *text);

/* ---- the session */
typedef struct spk_asr spk_asr;

typedef struct {
    uint64_t    line_id;     /* one id per utterance: its partials and its final */
    const char *text;
    double      start_s;     /* speech start, seconds since spk_asr_start (capture clock) */
    double      duration_s;  /* to the end of speech (final) or of the audio so far (partial) */
    int         final;
    double      confidence;  /* 0..1 from the decoder, <0 when the engine does not say */
} spk_asr_line;

/* A transcriber over Moonshine (Base, or Streaming when paths->adapter is set). Cheap: models load in spk_asr_start and
 * are released in spk_asr_stop. NULL with err when this build has no runtime
 * or a path is missing. */
spk_asr *spk_asr_create(const spk_asr_paths *paths, char *err, size_t err_len);
/* The same over any engine (tests). Takes ownership of engine. */
spk_asr *spk_asr_create_with_engine(spk_asr_engine engine);
/* Tests: no worker thread; the caller drives it with spk_asr_pump. Set before start. */
void spk_asr_set_manual(spk_asr *a, int manual);
/* Load the models and start a run. partial_ms: partial cadence (500), 0 = no
 * partials. Lines are delivered on the worker thread (or inside spk_asr_pump). */
int  spk_asr_start(spk_asr *a, int partial_ms,
                   void (*on_line)(const spk_asr_line *line, void *user), void *user);
/* Audio thread safe: copies into a ring and returns, never blocks or
 * allocates. Dropped while muted or stopped, or when the ring is full.
 * Mono; any rate from 8 to 192 kHz. Without _at the capture time is "now". */
void spk_asr_push_i16(spk_asr *a, const int16_t *samples, int count, int sample_rate);
void spk_asr_push_f32(spk_asr *a, const float *samples, int count, int sample_rate);
/* With the capture time of the first sample, ms since spk_asr_start. */
void spk_asr_push_i16_at(spk_asr *a, const int16_t *samples, int count, int sample_rate, double t_ms);
void spk_asr_push_f32_at(spk_asr *a, const float *samples, int count, int sample_rate, double t_ms);
/* Muting closes the open utterance (its final is delivered) and drops audio
 * until unmuted; the next audio starts a new run on the capture clock. */
void spk_asr_set_muted(spk_asr *a, int muted);
/* Process everything queued (manual mode; the worker calls it otherwise). */
void spk_asr_pump(spk_asr *a);
/* Stop: processes the audio already pushed, delivers the open utterance as
 * final, joins the worker, releases the models. */
int  spk_asr_stop(spk_asr *a);
/* Last error message (load failure), or "". */
const char *spk_asr_last_error(spk_asr *a);
/* Counters (tests, benchmarks). */
typedef struct {
    uint64_t pushed, dropped;   /* input samples                     */
    uint64_t frames;            /* VAD frames                        */
    int      utterances, partials, finals;
    double   decode_ms;         /* total time in transcribe          */
    int      rate_fixes;        /* declared sample rate overridden by the capture clock */
    int      dropped_unsure;    /* finals dropped under the confidence floor */
} spk_asr_stats;
void spk_asr_get_stats(spk_asr *a, spk_asr_stats *out);
/* One-shot: resample and transcribe a whole buffer (no VAD). The models must
 * be open: between spk_asr_start and spk_asr_stop, or after spk_asr_open.
 * Returns a malloc'd string (free()) or NULL. */
char *spk_asr_transcribe_once(spk_asr *a, const float *samples, int count, int sample_rate);
int  spk_asr_open(spk_asr *a);    /* load the models without starting a run */
void spk_asr_free(spk_asr *a);
/* Words this call is likely to contain: the people on it, the group, the
 * game's own words. Decoding leans towards them (names heard right more
 * often); a phrase that isn't said costs nothing. Up to SPK_BIAS_MAX_PHRASES,
 * any time (kept across start/stop; NULL/0 clears). Returns the number kept,
 * or <0 (no engine support: SPK_E_NOT_READY). */
int  spk_asr_set_vocabulary(spk_asr *a, const char *const *phrases, int n);
/* Finals whose confidence is below this are dropped (fluent nonsense from
 * background chatter). Default SPK_ASR_MIN_CONFIDENCE; 0 keeps everything. */
void spk_asr_set_min_confidence(spk_asr *a, double floor);

/* ---- Moonshine's tokenizer and vocabulary biasing (sparks_vocab.c, no ONNX
 * Runtime: unit-tested on every build). */
typedef struct spk_vocab spk_vocab;
spk_vocab *spk_vocab_load(const char *path);                    /* tokenizer.bin */
spk_vocab *spk_vocab_from_bytes(const uint8_t *bytes, size_t n);
void spk_vocab_free(spk_vocab *v);
int  spk_vocab_size(const spk_vocab *v);
/* ids -> text (special pieces skipped, U+2581 = space, trimmed) */
void spk_vocab_decode(const spk_vocab *v, const int64_t *toks, int n, char *out, size_t cap);
/* text -> ids, SentencePiece BPE of " " + text; count, 0 if empty, <0 error */
int  spk_vocab_encode(const spk_vocab *v, const char *text, int32_t *out, int cap);

#define SPK_BIAS_MAX_PHRASES 256
#define SPK_BIAS_MAX_TOKENS  16
#define SPK_BIAS_FIRST       3.0f   /* logit boost for a phrase's first token  */
#define SPK_BIAS_NEXT        5.0f   /* ... and for its next token once started */
#define SPK_BIAS_FIRST_SHORT 0.0f   /* ... for a first token that fails the rule below ("▁W" of Wemida, "▁For" of Forge) */
#define SPK_BIAS_MIN_FIRST_CHARS 3   /* first token boosted up front only with 3+ letters, */
#define SPK_BIAS_MIN_FIRST_ID 2000   /* not among the commonest pieces, and only if its word needs 2+ pieces */
typedef struct spk_bias spk_bias;
spk_bias *spk_bias_new(void);
void spk_bias_free(spk_bias *b);
void spk_bias_set_weights(spk_bias *b, float first, float next, float first_short);
void spk_bias_set_first_rule(spk_bias *b, int min_chars, int min_id);   /* before spk_bias_set */
int  spk_bias_set(spk_bias *b, const spk_vocab *v, const char *const *phrases, int n);
int  spk_bias_count(const spk_bias *b);
/* The boosts for the next token after hypothesis hyp[0..nhyp). Returns count. */
int  spk_bias_boosts(const spk_bias *b, const int64_t *hyp, int nhyp, int32_t *tok, float *boost, int cap);
/* After decoding: words that are nearly a listed name become that name, in
 * place ("Adawali" -> "Adewale"). Returns the number of words changed. */
int  spk_bias_snap(const spk_bias *b, const spk_vocab *v, char *text, size_t cap);

#ifdef __cplusplus
}
#endif
#endif
