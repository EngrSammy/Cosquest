/* sparks_moonshine_internal.h: what the two Moonshine runners share
 * (sparks_moonshine.c: Base; sparks_moonshine_streaming.c: Streaming small /
 * medium). ONNX Runtime session options, mapped model files, the decoder
 * loop guard and Silero VAD. Only with -DSPARKS_WITH_MOONSHINE. */
#ifndef SPARKS_MOONSHINE_INTERNAL_H
#define SPARKS_MOONSHINE_INTERNAL_H

#if defined(SPARKS_WITH_MOONSHINE)

#include "sparks_core.h"

#if defined(__has_include)
#if __has_include(<onnxruntime/onnxruntime_c_api.h>)
#include <onnxruntime/onnxruntime_c_api.h>      /* onnxruntime-c pod, frameworks */
#elif __has_include(<onnxruntime_c_api.h>)
#include <onnxruntime_c_api.h>                  /* onnxruntime-c pod, static libraries; host test */
#else
#include "onnxruntime_c_api.h"
#endif
#else
#include "onnxruntime_c_api.h"
#endif

/* Session options shared by every Moonshine session: `threads` intra-op
 * threads, no arena, no spinning; with ort_bytes the .ort file's mapped bytes
 * are used in place for the initializers (clean, file-backed pages). */
OrtSessionOptions *spk_ms_session_options(const OrtApi *api, int threads, int ort_bytes, char *err, size_t err_len);
/* mmap a file read-only. 0, or -1. */
int spk_ms_map_file(const char *path, void **out, size_t *len);
/* 1 when the bytes are an ORT-format (flatbuffers) model. */
int spk_ms_is_ort_format(const void *p, size_t len);
/* Map `path` and open a session over the mapped bytes (ORT format) or the
 * file (ONNX). The mapping is returned in *map / *map_len and must outlive
 * the session. 0, or -1 with err. */
int spk_ms_open_mapped(const OrtApi *api, OrtEnv *env, const char *path, int threads, OrtSession **out,
                       void **map, size_t *map_len, const char *what, char *err, size_t err_len);
/* A decoder stuck in a loop (the last block of 2 to 16 tokens three times in
 * a row): the length that keeps one copy, or 0. */
int spk_ms_loop_cut(const int64_t *toks, int n);
/* ORT status -> err (released); non-zero on failure. */
int spk_ms_failed(const OrtApi *api, OrtStatus *st, char *err, size_t err_len, const char *what);

/* Silero VAD (silero_vad_16k_op15.onnx), one SPK_ASR_HOP frame at a time. */
#define SPK_SILERO_CONTEXT 64
#define SPK_SILERO_STATE   (2 * 1 * 128)
typedef struct {
    const OrtApi *api;
    OrtMemoryInfo *mem;
    OrtSession *s;
    float state[SPK_SILERO_STATE];
    float in[SPK_SILERO_CONTEXT + SPK_ASR_HOP];
    int64_t sr;
} spk_silero;
int   spk_silero_open(spk_silero *v, const OrtApi *api, OrtEnv *env, OrtMemoryInfo *mem, const char *path, char *err, size_t err_len);
void  spk_silero_close(spk_silero *v);
void  spk_silero_reset(spk_silero *v);
float spk_silero_prob(spk_silero *v, const float *frame);

#endif
#endif
